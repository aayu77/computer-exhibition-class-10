# Smart RFID Attendance Management System

Premium school exhibition web application for an ESP32 + RFID RC522 attendance project.

## What is included

- Flask backend in `app.py`
- SQLite database stored in `instance/attendance.db`
- ESP32-compatible REST endpoint for RFID scans
- Device heartbeat and online/offline detection
- React frontend served by Flask
- Admin login, signup, session check, and logout flow
- Student management and manual Present/Absent/Late attendance
- Live dashboard, analytics, reports, search, and CSV export
- Real RFID validation, duplicate-safe student enrollment, and device status monitoring

## Run locally

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open:

```text
http://localhost:5001
```

The Flask server now listens on `0.0.0.0` by default, so ESP32 devices on the same Wi-Fi can call the backend using your computer's Wi-Fi IP address. When the server starts, it prints the exact Wi-Fi dashboard URL and ESP32 endpoints.

Create or configure an admin password with environment variables before running a fresh database:

```text
SMART_RFID_DEFAULT_ADMIN_PASSWORD=your-private-password
SMART_RFID_SECRET_KEY=your-long-random-session-secret
```

If the database already has an admin account, sign in with that existing account. Do not put passwords in frontend files.

To find your Mac Wi-Fi IP manually:

```bash
ipconfig getifaddr en0
```

Use that IP in the ESP32 sketch, for example:

```text
http://YOUR-COMPUTER-IP:5001/api/attendance
```

If you specifically want localhost-only mode again:

```bash
SMART_RFID_HOST=127.0.0.1 python app.py
```

## ESP32 API

Send RFID scans to your computer's Wi-Fi IP:

```http
POST http://YOUR-COMPUTER-IP:5001/api/attendance
Content-Type: application/json

{
  "uid": "04:A7:2C:91",
  "device_id": "ESP32-RFID-01",
  "firmware": "rfid-attendance-v1.0"
}
```

Send heartbeat without a scan:

```http
POST http://YOUR-COMPUTER-IP:5001/api/device/heartbeat
Content-Type: application/json

{
  "device_id": "ESP32-RFID-01",
  "firmware": "rfid-attendance-v1.0"
}
```

The dashboard shows the ESP32 as online when a scan or heartbeat was received recently. If the device stops sending data, the status safely changes to offline without crashing the website.

## Main admin pages

- Dashboard
- Students
- Attendance
- Reports
- How It Works
- Components
- What We Learned
- About Team
- Conclusion

System readiness check:

```http
GET /api/system/checks
```

This verifies the API, SQLite integrity, registered students, attendance records, and device monitor status for demo confidence.
