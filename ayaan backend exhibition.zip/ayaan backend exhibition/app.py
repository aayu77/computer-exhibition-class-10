from __future__ import annotations

import csv
import io
import logging
import os
import re
import secrets
import socket
import sqlite3
import time
from contextlib import closing
from datetime import date, datetime, timedelta, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Callable

from flask import (
    Flask,
    Response,
    jsonify,
    request,
    send_from_directory,
    session,
    stream_with_context,
)
from werkzeug.exceptions import HTTPException
from werkzeug.security import (
    check_password_hash,
    generate_password_hash,
)


# ============================================================
# SMART RFID ADMIN
# Smart Campus Command Center
#
# Hardened Flask backend
#
# Compatible with:
#   - existing frontend API
#   - existing SQLite database
#   - ESP32 + RC522
#   - browser session authentication
#
# ============================================================


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parent

INSTANCE_DIR = ROOT / "instance"

DB_PATH = INSTANCE_DIR / "attendance.db"


# ============================================================
# APPLICATION CONSTANTS
# ============================================================

APP_NAME = "Smart RFID Admin"

APP_VERSION = "3.0.0"

DEFAULT_HOST = "0.0.0.0"

DEFAULT_PORT = 5001

DEVICE_ID = "ESP32-RFID-01"

DEFAULT_FIRMWARE = "rfid-attendance-v1.0"

DEVICE_TIMEOUT_SECONDS = 45

MAX_REQUEST_SIZE = 1 * 1024 * 1024

MAX_LOGIN_ATTEMPTS_WINDOW = 300

MAX_LOGIN_ATTEMPTS = 10


# ============================================================
# DEFAULT ADMIN
# ============================================================

DEFAULT_ADMIN_USERNAME = "admin"

DEFAULT_ADMIN_PASSWORD = os.environ.get(
    "SMART_RFID_DEFAULT_ADMIN_PASSWORD",
    "",
).strip()

ALLOW_ADMIN_SIGNUP = (
    os.environ.get(
        "SMART_RFID_ALLOW_SIGNUP",
        "",
    ).strip()
    == "1"
)


# ============================================================
# VALIDATION
# ============================================================

UID_PATTERN = re.compile(
    r"^[0-9A-F]{2}(:[0-9A-F]{2}){3,9}$"
)

USERNAME_PATTERN = re.compile(
    r"^[A-Za-z0-9_.-]{3,32}$"
)


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format=(
        "%(asctime)s | "
        "%(levelname)s | "
        "%(name)s | "
        "%(message)s"
    ),
)

logger = logging.getLogger("smart-rfid")


# ============================================================
# FLASK
# ============================================================

app = Flask(
    __name__,
    static_folder="static",
    static_url_path="/static",
)


# ============================================================
# SECRET KEY
# ============================================================

app.secret_key = os.environ.get(
    "SMART_RFID_SECRET_KEY",
    "",
).strip()

if not app.secret_key:
    app.secret_key = secrets.token_hex(32)
    logger.warning(
        "SMART_RFID_SECRET_KEY is not set; using an ephemeral session key for this run."
    )


# ============================================================
# SESSION CONFIGURATION
# ============================================================

app.config.update(
    SESSION_COOKIE_NAME="smart_rfid_session",

    SESSION_COOKIE_HTTPONLY=True,

    SESSION_COOKIE_SAMESITE="Lax",

    SESSION_COOKIE_SECURE=(
        os.environ.get(
            "SMART_RFID_SECURE_COOKIE",
            "0",
        )
        == "1"
    ),

    MAX_CONTENT_LENGTH=MAX_REQUEST_SIZE,

    JSON_SORT_KEYS=False,
)


# ============================================================
# OPTIONAL CORS CONFIGURATION
#
# IMPORTANT:
# Do NOT use Access-Control-Allow-Origin: *
# with authenticated cookies.
# ============================================================

ALLOWED_ORIGINS = {
    origin.strip().rstrip("/")
    for origin in os.environ.get(
        "SMART_RFID_ALLOWED_ORIGINS",
        "",
    ).split(",")
    if origin.strip()
}


# ============================================================
# DEVICE SECRET
#
# Optional for exhibition.
#
# If SMART_RFID_DEVICE_SECRET is set, ESP32 requests must send:
#
# X-Device-Secret: <secret>
#
# If not set, device requests remain compatible with the
# current exhibition setup.
# ============================================================

DEVICE_SECRET = os.environ.get(
    "SMART_RFID_DEVICE_SECRET",
    "",
).strip()


# ============================================================
# DEMO STUDENTS
# ============================================================

DEMO_STUDENTS = [
    (
        "Ayaan Sheikh",
        "04:A7:2C:91",
        "X-A",
        "01",
    ),
    (
        "Vedant",
        "8B:14:0D:5F",
        "X-A",
        "02",
    ),
    (
        "Arshal",
        "7C:92:11:AF",
        "X-A",
        "03",
    ),
    (
        "Nisha Rao",
        "19:AE:75:42",
        "X-A",
        "04",
    ),
    (
        "Rohan Mehta",
        "31:BC:9D:80",
        "X-A",
        "05",
    ),
    (
        "Ira Kapoor",
        "54:22:CC:10",
        "X-A",
        "06",
    ),
    (
        "Zayan Khan",
        "2A:66:90:EF",
        "X-A",
        "07",
    ),
    (
        "Mira Shah",
        "77:01:4B:AA",
        "X-A",
        "08",
    ),
    (
        "Kabir Sethi",
        "12:DF:83:44",
        "X-A",
        "09",
    ),
    (
        "Anaya Iyer",
        "6E:42:B0:19",
        "X-A",
        "10",
    ),
    (
        "Dev Patel",
        "AB:22:7F:C3",
        "X-A",
        "11",
    ),
    (
        "Sara Thomas",
        "C1:5D:39:E8",
        "X-A",
        "12",
    ),
]


# ============================================================
# TIME HELPERS
# ============================================================

def utc_now() -> datetime:
    return datetime.now(
        timezone.utc
    ).replace(
        microsecond=0
    )


def iso_now() -> str:
    return (
        utc_now()
        .isoformat()
        .replace("+00:00", "Z")
    )


def local_time_string() -> str:
    return datetime.now().strftime(
        "%H:%M:%S"
    )


# ============================================================
# DATABASE
# ============================================================

def connect() -> sqlite3.Connection:
    INSTANCE_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    conn = sqlite3.connect(
        DB_PATH,
        timeout=15,
    )

    conn.row_factory = sqlite3.Row

    conn.execute(
        "PRAGMA foreign_keys = ON"
    )

    conn.execute(
        "PRAGMA busy_timeout = 10000"
    )

    conn.execute(
        "PRAGMA journal_mode = WAL"
    )

    conn.execute(
        "PRAGMA synchronous = NORMAL"
    )

    conn.execute(
        "PRAGMA temp_store = MEMORY"
    )

    return conn


# ============================================================
# DATABASE TRANSACTION HELPER
# ============================================================

def safe_commit(
    conn: sqlite3.Connection,
) -> None:
    try:
        conn.commit()
    except Exception:
        conn.rollback()
        raise


# ============================================================
# INPUT HELPERS
# ============================================================

def request_payload() -> dict[str, Any]:

    payload = request.get_json(
        silent=True
    )

    if isinstance(payload, dict):
        return payload

    if request.form:
        return request.form.to_dict()

    return {}


def clean_string(
    value: Any,
    max_length: int = 255,
) -> str:

    if value is None:
        return ""

    return str(value).strip()[:max_length]


def normalize_uid(
    uid: Any,
) -> str:

    value = clean_string(
        uid,
        64,
    ).upper()

    value = value.replace(
        "-",
        ":",
    )

    value = value.replace(
        " ",
        "",
    )

    if ":" not in value and len(value) >= 4:

        if len(value) % 2 == 0:

            value = ":".join(
                value[index:index + 2]
                for index in range(
                    0,
                    len(value),
                    2,
                )
            )

    return value


def is_valid_uid(
    uid: str,
) -> bool:

    return bool(
        UID_PATTERN.fullmatch(uid)
    )


def parse_date_strict(
    value: Any,
) -> tuple[str | None, str | None]:

    if value is None or str(value).strip() == "":
        return (
            date.today().isoformat(),
            None,
        )

    value = str(value).strip()

    try:

        parsed = datetime.strptime(
            value,
            "%Y-%m-%d",
        ).date()

        return (
            parsed.isoformat(),
            None,
        )

    except ValueError:

        return (
            None,
            "Invalid date. Expected YYYY-MM-DD.",
        )


def parse_optional_date(
    value: Any,
) -> tuple[str | None, str | None]:

    if value is None or str(value).strip() == "":
        return (
            None,
            None,
        )

    return parse_date_strict(
        value
    )


def parse_date_range(
    start_value: Any = None,
    end_value: Any = None,
    preset: str = "30d",
) -> tuple[str | None, str | None, str | None]:

    preset = clean_string(
        preset,
        24,
    ).lower()

    today = date.today()

    if preset in {
        "today",
        "1d",
    } and not start_value and not end_value:

        return (
            today.isoformat(),
            today.isoformat(),
            None,
        )

    if preset in {
        "7d",
        "7days",
        "week",
    } and not start_value and not end_value:

        return (
            (
                today
                - timedelta(days=6)
            ).isoformat(),
            today.isoformat(),
            None,
        )

    if preset in {
        "3m",
        "90d",
        "quarter",
    } and not start_value and not end_value:

        return (
            (
                today
                - timedelta(days=89)
            ).isoformat(),
            today.isoformat(),
            None,
        )

    if preset in {
        "all",
        "history",
    } and not start_value and not end_value:

        return (
            None,
            None,
            None,
        )

    if not start_value and not end_value:

        return (
            (
                today
                - timedelta(days=29)
            ).isoformat(),
            today.isoformat(),
            None,
        )

    start_date, start_error = parse_optional_date(
        start_value
    )

    if start_error:
        return (
            None,
            None,
            start_error,
        )

    end_date, end_error = parse_optional_date(
        end_value
    )

    if end_error:
        return (
            None,
            None,
            end_error,
        )

    if (
        start_date
        and end_date
        and start_date > end_date
    ):

        return (
            None,
            None,
            "Start date cannot be after end date.",
        )

    return (
        start_date,
        end_date,
        None,
    )


# ============================================================
# JSON RESPONSE HELPERS
# ============================================================

def ok_response(
    data: dict[str, Any] | None = None,
    status: int = 200,
):
    payload = {
        "ok": True,
    }

    if data:
        payload.update(data)

    return jsonify(payload), status


def error_response(
    message: str,
    status: int = 400,
    code: str = "BAD_REQUEST",
    **extra: Any,
):
    payload = {
        "ok": False,
        "error": message,
        "message": message,
        "code": code,
    }

    payload.update(extra)

    return jsonify(payload), status


def safe_csv_cell(
    value: Any,
) -> str:

    text = "" if value is None else str(value)

    if text.startswith(
        ("=", "+", "-", "@")
    ):
        return f"'{text}"

    return text


def safe_filename_part(
    value: Any,
    fallback: str = "report",
) -> str:

    text = clean_string(
        value,
        80,
    ).lower()

    text = re.sub(
        r"[^a-z0-9_-]+",
        "-",
        text,
    ).strip("-")

    return text or fallback


def verify_password_hash(
    password_hash: str,
    password: str,
) -> bool:
    try:
        return check_password_hash(
            password_hash,
            password,
        )
    except (
        AttributeError,
        ValueError,
    ) as error:
        logger.warning(
            "Unsupported password hash could not be verified: %s",
            error,
        )
        return False


def admin_signup_available(
    conn: sqlite3.Connection,
) -> bool:
    if ALLOW_ADMIN_SIGNUP:
        return True

    count = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM admins
        """
    ).fetchone()["count"]

    return int(count) == 0


# ============================================================
# DATABASE INITIALIZATION
# ============================================================

def init_db() -> None:

    with closing(connect()) as conn:

        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                name TEXT NOT NULL,

                rfid_uid TEXT NOT NULL UNIQUE,

                class_name TEXT NOT NULL,

                roll_no TEXT NOT NULL,

                created_at TEXT NOT NULL
            );


            CREATE TABLE IF NOT EXISTS attendance_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                student_id INTEGER NOT NULL,

                rfid_uid TEXT NOT NULL,

                attendance_date TEXT NOT NULL,

                check_in_time TEXT NOT NULL,

                status TEXT NOT NULL
                    DEFAULT 'Present',

                source TEXT NOT NULL
                    DEFAULT 'ESP32',

                created_at TEXT NOT NULL,

                updated_at TEXT NOT NULL,

                FOREIGN KEY(student_id)
                    REFERENCES students(id),

                UNIQUE(
                    student_id,
                    attendance_date
                )
            );


            CREATE TABLE IF NOT EXISTS scan_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                student_id INTEGER,

                rfid_uid TEXT NOT NULL,

                status TEXT NOT NULL,

                device_id TEXT NOT NULL,

                source_ip TEXT,

                message TEXT,

                created_at TEXT NOT NULL,

                FOREIGN KEY(student_id)
                    REFERENCES students(id)
            );


            CREATE TABLE IF NOT EXISTS device_status (
                id INTEGER PRIMARY KEY
                    CHECK(id = 1),

                device_id TEXT NOT NULL,

                firmware TEXT,

                last_seen TEXT,

                last_ip TEXT,

                last_uid TEXT,

                total_scans INTEGER NOT NULL
                    DEFAULT 0,

                created_at TEXT NOT NULL,

                updated_at TEXT NOT NULL
            );


            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                username TEXT NOT NULL UNIQUE,

                password_hash TEXT NOT NULL,

                created_at TEXT NOT NULL,

                updated_at TEXT NOT NULL
            );


            CREATE TABLE IF NOT EXISTS login_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                admin_id INTEGER,

                username TEXT NOT NULL,

                status TEXT NOT NULL,

                source_ip TEXT,

                user_agent TEXT,

                created_at TEXT NOT NULL,

                FOREIGN KEY(admin_id)
                    REFERENCES admins(id)
            );


            CREATE TABLE IF NOT EXISTS site_visits (
                id INTEGER PRIMARY KEY
                    CHECK(id = 1),

                total_visits INTEGER NOT NULL
                    DEFAULT 0,

                created_at TEXT NOT NULL,

                updated_at TEXT NOT NULL
            );


            CREATE TABLE IF NOT EXISTS student_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                student_id INTEGER NOT NULL UNIQUE,

                username TEXT NOT NULL UNIQUE,

                password_hash TEXT NOT NULL,

                active INTEGER NOT NULL DEFAULT 1,

                created_at TEXT NOT NULL,

                updated_at TEXT NOT NULL,

                FOREIGN KEY(student_id)
                    REFERENCES students(id)
            );


            CREATE TABLE IF NOT EXISTS student_edit_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                student_id INTEGER NOT NULL,

                field_name TEXT NOT NULL,

                current_value TEXT,

                requested_value TEXT NOT NULL,

                reason TEXT,

                status TEXT NOT NULL DEFAULT 'Pending',

                reviewer_admin_id INTEGER,

                review_note TEXT,

                created_at TEXT NOT NULL,

                reviewed_at TEXT,

                updated_at TEXT NOT NULL,

                FOREIGN KEY(student_id)
                    REFERENCES students(id),

                FOREIGN KEY(reviewer_admin_id)
                    REFERENCES admins(id)
            );


            CREATE INDEX IF NOT EXISTS
                idx_attendance_date
            ON attendance_records(
                attendance_date
            );


            CREATE INDEX IF NOT EXISTS
                idx_attendance_student
            ON attendance_records(
                student_id
            );


            CREATE INDEX IF NOT EXISTS
                idx_scan_events_created
            ON scan_events(
                created_at DESC
            );


            CREATE INDEX IF NOT EXISTS
                idx_scan_events_uid
            ON scan_events(
                rfid_uid
            );


            CREATE INDEX IF NOT EXISTS
                idx_login_events_created
            ON login_events(
                created_at DESC
            );


            CREATE INDEX IF NOT EXISTS
                idx_students_uid
            ON students(
                rfid_uid
            );


            CREATE INDEX IF NOT EXISTS
                idx_students_roll
            ON students(
                roll_no
            );


            CREATE UNIQUE INDEX IF NOT EXISTS
                idx_students_roll_ci
            ON students(
                lower(roll_no)
            );


            CREATE UNIQUE INDEX IF NOT EXISTS
                idx_students_uid_ci
            ON students(
                lower(rfid_uid)
            );


            CREATE UNIQUE INDEX IF NOT EXISTS
                idx_admins_username_ci
            ON admins(
                lower(username)
            );


            CREATE UNIQUE INDEX IF NOT EXISTS
                idx_student_accounts_username_ci
            ON student_accounts(
                lower(username)
            );


            CREATE INDEX IF NOT EXISTS
                idx_student_accounts_student
            ON student_accounts(
                student_id
            );


            CREATE INDEX IF NOT EXISTS
                idx_edit_requests_student
            ON student_edit_requests(
                student_id,
                created_at DESC
            );


            CREATE INDEX IF NOT EXISTS
                idx_edit_requests_status
            ON student_edit_requests(
                status,
                created_at DESC
            );


            CREATE UNIQUE INDEX IF NOT EXISTS
                idx_edit_requests_pending_field
            ON student_edit_requests(
                student_id,
                field_name
            )
            WHERE status = 'Pending';
            """
        )

        ensure_default_admin(
            conn
        )

        ensure_device_record(
            conn
        )

        ensure_site_visit_record(
            conn
        )

        ensure_student_active_column(
            conn
        )

        seed_students_if_empty(
            conn
        )

        conn.commit()


def ensure_student_active_column(
    conn: sqlite3.Connection,
) -> None:

    columns = {
        row["name"]
        for row in conn.execute(
            "PRAGMA table_info(students)"
        ).fetchall()
    }

    if "active" not in columns:
        conn.execute(
            """
            ALTER TABLE students
            ADD COLUMN active INTEGER NOT NULL DEFAULT 1
            """
        )


# ============================================================
# DEFAULT ADMIN
# ============================================================

def ensure_default_admin(
    conn: sqlite3.Connection,
) -> None:

    existing = conn.execute(
        """
        SELECT id
        FROM admins
        WHERE lower(username) = lower(?)
        LIMIT 1
        """,
        (
            DEFAULT_ADMIN_USERNAME,
        ),
    ).fetchone()

    if existing:
        return

    if not DEFAULT_ADMIN_PASSWORD:
        logger.warning(
            "Default admin was not created because SMART_RFID_DEFAULT_ADMIN_PASSWORD is not set."
        )
        return

    stamp = iso_now()

    password_hash = generate_password_hash(
        DEFAULT_ADMIN_PASSWORD,
        method="pbkdf2:sha256:600000",
    )

    conn.execute(
        """
        INSERT INTO admins
        (
            username,
            password_hash,
            created_at,
            updated_at
        )
        VALUES (?, ?, ?, ?)
        """,
        (
            DEFAULT_ADMIN_USERNAME,
            password_hash,
            stamp,
            stamp,
        ),
    )


# ============================================================
# DEVICE RECORD
# ============================================================

def ensure_device_record(
    conn: sqlite3.Connection,
) -> None:

    stamp = iso_now()

    conn.execute(
        """
        INSERT INTO device_status
        (
            id,
            device_id,
            firmware,
            last_seen,
            last_ip,
            last_uid,
            total_scans,
            created_at,
            updated_at
        )
        VALUES
        (
            1,
            ?,
            ?,
            NULL,
            NULL,
            NULL,
            0,
            ?,
            ?
        )
        ON CONFLICT(id)
        DO NOTHING
        """,
        (
            DEVICE_ID,
            DEFAULT_FIRMWARE,
            stamp,
            stamp,
        ),
    )


# ============================================================
# SITE VISITS
# ============================================================

def ensure_site_visit_record(
    conn: sqlite3.Connection,
) -> None:

    stamp = iso_now()

    conn.execute(
        """
        INSERT INTO site_visits
        (
            id,
            total_visits,
            created_at,
            updated_at
        )
        VALUES
        (
            1,
            0,
            ?,
            ?
        )
        ON CONFLICT(id)
        DO NOTHING
        """,
        (
            stamp,
            stamp,
        ),
    )


def record_site_visit() -> int:

    stamp = iso_now()

    with closing(connect()) as conn:

        conn.execute(
            """
            UPDATE site_visits
            SET
                total_visits =
                    total_visits + 1,
                updated_at = ?
            WHERE id = 1
            """,
            (
                stamp,
            ),
        )

        row = conn.execute(
            """
            SELECT total_visits
            FROM site_visits
            WHERE id = 1
            """
        ).fetchone()

        conn.commit()

        return int(
            row["total_visits"]
        ) if row else 0


# ============================================================
# SEED STUDENTS
# ============================================================

def seed_students_if_empty(
    conn: sqlite3.Connection,
) -> None:

    count = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM students
        """
    ).fetchone()["count"]

    if count > 0:
        return

    stamp = iso_now()

    for (
        name,
        uid,
        class_name,
        roll_no,
    ) in DEMO_STUDENTS:

        conn.execute(
            """
            INSERT INTO students
            (
                name,
                rfid_uid,
                class_name,
                roll_no,
                created_at
            )
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                name,
                normalize_uid(uid),
                class_name,
                roll_no,
                stamp,
            ),
        )


# ============================================================
# AUTHENTICATION
# ============================================================

def current_admin() -> dict[str, Any] | None:

    if session.get("role") not in {
        None,
        "admin",
    }:
        return None

    admin_id = session.get(
        "admin_id"
    )

    if not admin_id:
        return None

    try:
        admin_id = int(admin_id)
    except (
        TypeError,
        ValueError,
    ):

        session.clear()

        return None

    with closing(connect()) as conn:

        row = conn.execute(
            """
            SELECT
                id,
                username,
                created_at
            FROM admins
            WHERE id = ?
            LIMIT 1
            """,
            (
                admin_id,
            ),
        ).fetchone()

    if not row:

        session.clear()

        return None

    return dict(row)


def current_student_account() -> dict[str, Any] | None:

    if session.get("role") != "student":
        return None

    account_id = session.get(
        "student_account_id"
    )

    if not account_id:
        return None

    try:
        account_id = int(account_id)
    except (
        TypeError,
        ValueError,
    ):
        session.clear()
        return None

    with closing(connect()) as conn:

        row = conn.execute(
            """
            SELECT
                sa.id,
                sa.username,
                sa.student_id,
                sa.active,
                sa.created_at,
                sa.updated_at,
                s.name,
                s.roll_no,
                s.class_name,
                s.rfid_uid
            FROM student_accounts sa
            JOIN students s
              ON s.id = sa.student_id
            WHERE sa.id = ?
            LIMIT 1
            """,
            (
                account_id,
            ),
        ).fetchone()

    if not row or not int(row["active"]):
        session.clear()
        return None

    return {
        "id": row["id"],
        "username": row["username"],
        "role": "student",
        "studentId": row["student_id"],
        "active": bool(row["active"]),
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
        "student": {
            "id": row["student_id"],
            "name": row["name"],
            "rollNo": row["roll_no"],
            "className": row["class_name"],
            "rfidUid": row["rfid_uid"],
        },
    }


def current_identity() -> dict[str, Any] | None:

    admin = current_admin()

    if admin:
        return {
            **admin,
            "role": "admin",
        }

    return current_student_account()


def require_admin():
    admin = current_admin()

    if admin:
        return (
            admin,
            None,
        )

    return (
        None,
        error_response(
            "Authentication required",
            401,
            "AUTH_REQUIRED",
            authenticated=False,
        ),
    )


def require_student():
    student = current_student_account()

    if student:
        return (
            student,
            None,
        )

    return (
        None,
        error_response(
            "Student authentication required",
            401,
            "STUDENT_AUTH_REQUIRED",
            authenticated=False,
        ),
    )


# ============================================================
# LOGIN RATE LIMIT
# ============================================================

_login_attempts: dict[
    str,
    list[float],
] = {}


def login_rate_limited(
    key: str,
) -> bool:

    current = time.time()

    attempts = _login_attempts.get(
        key,
        [],
    )

    attempts = [
        timestamp
        for timestamp in attempts
        if current - timestamp
        < MAX_LOGIN_ATTEMPTS_WINDOW
    ]

    _login_attempts[key] = attempts

    return len(attempts) >= MAX_LOGIN_ATTEMPTS


def record_login_attempt(
    key: str,
) -> None:

    current = time.time()

    attempts = _login_attempts.setdefault(
        key,
        [],
    )

    attempts.append(
        current
    )


def cleanup_login_attempts() -> None:

    current = time.time()

    expired = []

    for key, attempts in _login_attempts.items():

        valid = [
            timestamp
            for timestamp in attempts
            if current - timestamp
            < MAX_LOGIN_ATTEMPTS_WINDOW
        ]

        if valid:
            _login_attempts[key] = valid
        else:
            expired.append(key)

    for key in expired:
        _login_attempts.pop(
            key,
            None,
        )


# ============================================================
# LOGIN EVENT
# ============================================================

def record_login_event(
    conn: sqlite3.Connection,
    username: str,
    status: str,
    admin_id: int | None = None,
) -> None:

    conn.execute(
        """
        INSERT INTO login_events
        (
            admin_id,
            username,
            status,
            source_ip,
            user_agent,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            admin_id,
            clean_string(
                username,
                80,
            ),
            status,
            request.remote_addr,
            clean_string(
                request.headers.get(
                    "User-Agent",
                    "Unknown",
                ),
                240,
            ),
            iso_now(),
        ),
    )


# ============================================================
# DEVICE AUTHENTICATION
# ============================================================

def require_device_secret():

    if not DEVICE_SECRET:
        return None

    supplied = request.headers.get(
        "X-Device-Secret",
        "",
    )

    if not secrets.compare_digest(
        supplied,
        DEVICE_SECRET,
    ):

        return error_response(
            "Invalid device authentication.",
            401,
            "DEVICE_AUTH_REQUIRED",
        )

    return None


# ============================================================
# DECORATORS
# ============================================================

def admin_required(
    function: Callable,
):

    @wraps(function)
    def wrapper(
        *args,
        **kwargs,
    ):

        admin, error = require_admin()

        if error:
            return error

        return function(
            *args,
            **kwargs,
        )

    return wrapper


def student_required(
    function: Callable,
):

    @wraps(function)
    def wrapper(
        *args,
        **kwargs,
    ):

        student, error = require_student()

        if error:
            return error

        return function(
            *args,
            **kwargs,
        )

    return wrapper


def device_required(
    function: Callable,
):

    @wraps(function)
    def wrapper(
        *args,
        **kwargs,
    ):

        error = require_device_secret()

        if error:
            return error

        return function(
            *args,
            **kwargs,
        )

    return wrapper


# ============================================================
# STUDENT SERIALIZATION
# ============================================================

def serialize_student(
    row: sqlite3.Row,
    stats: dict[str, Any] | None = None,
) -> dict[str, Any]:

    payload = {
        "id": row["id"],
        "name": row["name"],
        "rollNo": row["roll_no"],
        "className": row["class_name"],
        "rfidUid": row["rfid_uid"],
        "active": bool(
            row["active"]
            if "active" in row.keys()
            else 1
        ),
        "createdAt": row["created_at"],
    }

    if stats:
        payload.update(stats)

    return payload


def student_stats_map(
    conn: sqlite3.Connection,
    student_ids: list[int],
) -> dict[int, dict[str, Any]]:

    if not student_ids:
        return {}

    placeholders = ",".join(
        "?"
        for _ in student_ids
    )

    rows = conn.execute(
        f"""
        SELECT
            student_id,
            attendance_date,
            check_in_time,
            status,
            source,
            updated_at
        FROM attendance_records
        WHERE student_id IN ({placeholders})
        ORDER BY
            attendance_date DESC,
            check_in_time DESC,
            id DESC
        """,
        student_ids,
    ).fetchall()

    today_value = date.today().isoformat()

    stats: dict[int, dict[str, Any]] = {
        student_id: {
            "todayStatus": "Absent",
            "todayTime": None,
            "todaySource": "System",
            "records": 0,
            "activeDays": 0,
            "presentDays": 0,
            "absentDays": 0,
            "attendancePercentage": 0,
            "lastAttendance": None,
        }
        for student_id in student_ids
    }

    seen_dates: dict[int, set[str]] = {
        student_id: set()
        for student_id in student_ids
    }

    for row in rows:

        student_id = int(
            row["student_id"]
        )

        entry = stats[student_id]

        if entry["lastAttendance"] is None:
            entry["lastAttendance"] = {
                "date":
                    row["attendance_date"],
                "time":
                    row["check_in_time"],
                "status":
                    row["status"],
                "source":
                    row["source"],
                "updatedAt":
                    row["updated_at"],
            }

        entry["records"] += 1
        seen_dates[student_id].add(
            row["attendance_date"]
        )

        if row["status"] in {
            "Present",
            "Late",
        }:
            entry["presentDays"] += 1

        if row["status"] == "Absent":
            entry["absentDays"] += 1

        if row["attendance_date"] == today_value:
            entry["todayStatus"] = row["status"]
            entry["todayTime"] = row["check_in_time"]
            entry["todaySource"] = row["source"]

    for student_id, entry in stats.items():

        active_days = len(
            seen_dates[student_id]
        )

        entry["activeDays"] = active_days

        entry["attendancePercentage"] = (
            round(
                entry["presentDays"]
                / active_days
                * 100,
                1,
            )
            if active_days
            else 0
        )

    return stats


# ============================================================
# ATTENDANCE SERIALIZATION
# ============================================================

def serialize_attendance(
    row: sqlite3.Row,
) -> dict[str, Any]:

    return {
        "id": row["id"],
        "studentId": row["student_id"],
        "studentName": row["name"],
        "rollNo": row["roll_no"],
        "className": row["class_name"],
        "rfidUid": row["rfid_uid"],
        "date": row["attendance_date"],
        "time": row["check_in_time"],
        "status": row["status"],
        "source": row["source"],
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


def serialize_attendance_roster(
    row: sqlite3.Row,
    selected_date: str,
) -> dict[str, Any]:

    status = row["status"] or "Absent"

    return {
        "id": (
            row["record_id"]
            if row["record_id"]
            else (
                f"absent-"
                f"{row['student_id']}-"
                f"{selected_date}"
            )
        ),
        "recordId": row["record_id"],
        "studentId": row["student_id"],
        "studentName": row["name"],
        "rollNo": row["roll_no"],
        "className": row["class_name"],
        "rfidUid": row["rfid_uid"],
        "date": (
            row["attendance_date"]
            or selected_date
        ),
        "time": row["check_in_time"],
        "status": status,
        "source": (
            row["source"]
            if row["record_id"]
            else "System"
        ),
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
        "isVirtualAbsent": not bool(
            row["record_id"]
        ),
    }


def serialize_student_account(
    row: sqlite3.Row,
) -> dict[str, Any]:

    return {
        "id": row["id"],
        "studentId": row["student_id"],
        "username": row["username"],
        "active": bool(row["active"]),
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


def serialize_edit_request(
    row: sqlite3.Row,
) -> dict[str, Any]:

    return {
        "id": row["id"],
        "studentId": row["student_id"],
        "studentName": row["name"] if "name" in row.keys() else None,
        "rollNo": row["roll_no"] if "roll_no" in row.keys() else None,
        "fieldName": row["field_name"],
        "currentValue": row["current_value"],
        "requestedValue": row["requested_value"],
        "reason": row["reason"],
        "status": row["status"],
        "reviewerAdminId": row["reviewer_admin_id"],
        "reviewNote": row["review_note"],
        "createdAt": row["created_at"],
        "reviewedAt": row["reviewed_at"],
        "updatedAt": row["updated_at"],
    }


def student_profile_payload(
    conn: sqlite3.Connection,
    student_id: int,
) -> dict[str, Any]:

    student = conn.execute(
        """
        SELECT *
        FROM students
        WHERE id = ?
        LIMIT 1
        """,
        (
            student_id,
        ),
    ).fetchone()

    if not student:
        raise ValueError("Student not found.")

    account = conn.execute(
        """
        SELECT id, student_id, username, active, created_at, updated_at
        FROM student_accounts
        WHERE student_id = ?
        LIMIT 1
        """,
        (
            student_id,
        ),
    ).fetchone()

    history = conn.execute(
        """
        SELECT
            ar.*,
            s.name,
            s.class_name,
            s.roll_no
        FROM attendance_records ar
        JOIN students s
          ON s.id = ar.student_id
        WHERE ar.student_id = ?
        ORDER BY
            ar.attendance_date DESC,
            ar.check_in_time DESC
        LIMIT 180
        """,
        (
            student_id,
        ),
    ).fetchall()

    active_dates = {
        row["attendance_date"]
        for row in history
    }

    present_days = sum(
        1
        for row in history
        if row["status"] in {
            "Present",
            "Late",
        }
    )

    absent_days = sum(
        1
        for row in history
        if row["status"] == "Absent"
    )

    active_day_count = len(active_dates)

    summary = {
        "records": len(history),
        "activeDays": active_day_count,
        "presentDays": present_days,
        "absentDays": absent_days,
        "attendancePercentage": (
            round(present_days / active_day_count * 100, 1)
            if active_day_count
            else 0
        ),
    }

    requests = conn.execute(
        """
        SELECT er.*, s.name, s.roll_no
        FROM student_edit_requests er
        JOIN students s
          ON s.id = er.student_id
        WHERE er.student_id = ?
        ORDER BY er.created_at DESC
        LIMIT 50
        """,
        (
            student_id,
        ),
    ).fetchall()

    scans = conn.execute(
        """
        SELECT *
        FROM scan_events
        WHERE student_id = ?
        ORDER BY created_at DESC
        LIMIT 20
        """,
        (
            student_id,
        ),
    ).fetchall()

    return {
        "ok": True,
        "student": serialize_student(student),
        "account": (
            serialize_student_account(account)
            if account
            else None
        ),
        "summary": summary,
        "history": [
            serialize_attendance(row)
            for row in history
        ],
        "editRequests": [
            serialize_edit_request(row)
            for row in requests
        ],
        "recentScans": [
            {
                "id": row["id"],
                "rfidUid": row["rfid_uid"],
                "status": row["status"],
                "deviceId": row["device_id"],
                "message": row["message"],
                "createdAt": row["created_at"],
            }
            for row in scans
        ],
    }


# ============================================================
# DEVICE STATUS
# ============================================================

def device_status_payload(
    conn: sqlite3.Connection,
) -> dict[str, Any]:

    row = conn.execute(
        """
        SELECT *
        FROM device_status
        WHERE id = 1
        LIMIT 1
        """
    ).fetchone()

    if not row:

        return {
            "ok": True,
            "online": False,
            "status": "offline",
            "label": "Device Offline",
            "deviceId": DEVICE_ID,
            "lastSeen": None,
            "secondsSinceSeen": None,
            "totalScans": 0,
            "timeoutSeconds":
                DEVICE_TIMEOUT_SECONDS,
        }

    seconds_since_seen = None

    if row["last_seen"]:

        try:

            last_seen = datetime.fromisoformat(
                row["last_seen"].replace(
                    "Z",
                    "+00:00",
                )
            )

            seconds_since_seen = max(
                0,
                int(
                    (
                        utc_now()
                        - last_seen
                    ).total_seconds()
                ),
            )

        except (
            TypeError,
            ValueError,
        ):

            seconds_since_seen = (
                DEVICE_TIMEOUT_SECONDS + 1
            )

    online = (
        seconds_since_seen is not None
        and seconds_since_seen
        <= DEVICE_TIMEOUT_SECONDS
    )

    latest_scan = conn.execute(
        """
        SELECT
            created_at,
            message
        FROM scan_events
        ORDER BY created_at DESC
        LIMIT 1
        """
    ).fetchone()

    return {
        "ok": True,
        "online": online,
        "status": (
            "online"
            if online
            else "offline"
        ),
        "label": (
            "Device Online"
            if online
            else "Device Offline"
        ),
        "apiStatus": "Connected",
        "deviceId": row["device_id"],
        "firmware": row["firmware"],
        "lastSeen": row["last_seen"],
        "lastIp": row["last_ip"],
        "lastUid": row["last_uid"],
        "lastScanAt": (
            latest_scan["created_at"]
            if latest_scan
            else None
        ),
        "lastScanMessage": (
            latest_scan["message"]
            if latest_scan
            else None
        ),
        "secondsSinceSeen":
            seconds_since_seen,
        "totalScans": row["total_scans"],
        "timeoutSeconds":
            DEVICE_TIMEOUT_SECONDS,
    }


# ============================================================
# DEVICE HEARTBEAT
# ============================================================

def update_device_seen(
    conn: sqlite3.Connection,
    device_id: str,
    firmware: str,
    uid: str | None = None,
    increment_scan: bool = False,
) -> None:

    stamp = iso_now()

    conn.execute(
        """
        UPDATE device_status
        SET
            device_id = ?,
            firmware = ?,
            last_seen = ?,
            last_ip = ?,
            last_uid = COALESCE(?, last_uid),
            total_scans =
                total_scans + ?,
            updated_at = ?
        WHERE id = 1
        """,
        (
            device_id,
            firmware,
            stamp,
            request.remote_addr,
            uid,
            1 if increment_scan else 0,
            stamp,
        ),
    )


# ============================================================
# STUDENT VALIDATION
# ============================================================

def validate_student(
    payload: dict[str, Any],
) -> tuple[
    dict[str, str] | None,
    str | None,
]:

    name = clean_string(
        payload.get("name"),
        120,
    )

    roll_no = clean_string(
        payload.get(
            "rollNo",
            payload.get(
                "roll_no",
                payload.get(
                    "roll_number",
                    "",
                ),
            ),
        ),
        32,
    )

    class_name = clean_string(
        payload.get(
            "className",
            payload.get(
                "class_name",
                "X-A",
            ),
        ),
        32,
    )

    uid = normalize_uid(
        payload.get(
            "rfidUid",
            payload.get(
                "rfid_uid",
                payload.get(
                    "uid",
                    "",
                ),
            ),
        )
    )

    if not name:
        return (
            None,
            "Student name is required.",
        )

    if not roll_no:
        return (
            None,
            "Roll number is required.",
        )

    if not uid:
        return (
            None,
            "RFID UID is required.",
        )

    if not is_valid_uid(uid):
        return (
            None,
            "Invalid RFID UID format.",
        )

    return (
        {
            "name": name,
            "roll_no": roll_no,
            "class_name": (
                class_name or "X-A"
            ),
            "rfid_uid": uid,
        },
        None,
    )


# ============================================================
# MARK ATTENDANCE
# ============================================================

def mark_student_present(
    conn: sqlite3.Connection,
    student: sqlite3.Row,
    source: str,
) -> tuple[
    sqlite3.Row,
    bool,
]:

    today = date.today().isoformat()

    current_time = local_time_string()

    stamp = iso_now()

    existing = conn.execute(
        """
        SELECT
            ar.*,
            s.name,
            s.class_name,
            s.roll_no
        FROM attendance_records ar
        JOIN students s
          ON s.id = ar.student_id
        WHERE
            ar.student_id = ?
            AND ar.attendance_date = ?
        LIMIT 1
        """,
        (
            student["id"],
            today,
        ),
    ).fetchone()

    if existing:

        if existing["status"] == "Present":

            return (
                existing,
                True,
            )

        conn.execute(
            """
            UPDATE attendance_records
            SET
                rfid_uid = ?,
                check_in_time = ?,
                status = 'Present',
                source = ?,
                updated_at = ?
            WHERE id = ?
            """,
            (
                student["rfid_uid"],
                current_time,
                source,
                stamp,
                existing["id"],
            ),
        )

        record = conn.execute(
            """
            SELECT
                ar.*,
                s.name,
                s.class_name,
                s.roll_no
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE ar.id = ?
            """,
            (
                existing["id"],
            ),
        ).fetchone()

        return (
            record,
            True,
        )

    try:
        conn.execute(
            """
            INSERT INTO attendance_records
            (
                student_id,
                rfid_uid,
                attendance_date,
                check_in_time,
                status,
                source,
                created_at,
                updated_at
            )
            VALUES
            (?, ?, ?, ?, 'Present',
             ?, ?, ?)
            """,
            (
                student["id"],
                student["rfid_uid"],
                today,
                current_time,
                source,
                stamp,
                stamp,
            ),
        )
    except sqlite3.IntegrityError:
        existing = conn.execute(
            """
            SELECT
                ar.*,
                s.name,
                s.class_name,
                s.roll_no
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE
                ar.student_id = ?
                AND ar.attendance_date = ?
            LIMIT 1
            """,
            (
                student["id"],
                today,
            ),
        ).fetchone()

        if existing and existing["status"] == "Present":
            return (
                existing,
                True,
            )

        raise

    record = conn.execute(
        """
        SELECT
            ar.*,
            s.name,
            s.class_name,
            s.roll_no
        FROM attendance_records ar
        JOIN students s
          ON s.id = ar.student_id
        WHERE
            ar.student_id = ?
            AND ar.attendance_date = ?
        LIMIT 1
        """,
        (
            student["id"],
            today,
        ),
    ).fetchone()

    return (
        record,
        False,
    )


# ============================================================
# DASHBOARD
# ============================================================

def dashboard_snapshot(
    selected_date: str,
) -> dict[str, Any]:

    with closing(connect()) as conn:

        students = conn.execute(
            """
            SELECT *
            FROM students
            ORDER BY
                CASE
                    WHEN roll_no GLOB '[0-9]*'
                    THEN CAST(
                        roll_no AS INTEGER
                    )
                    ELSE 999999
                END,
                name
            """
        ).fetchall()

        records = conn.execute(
            """
            SELECT
                ar.*,
                s.name,
                s.class_name,
                s.roll_no
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE
                ar.attendance_date = ?
            ORDER BY
                ar.check_in_time DESC
            """,
            (
                selected_date,
            ),
        ).fetchall()

        record_map = {
            row["student_id"]: row
            for row in records
        }

        total_students = len(
            students
        )

        present = sum(
            1
            for row in records
            if row["status"] == "Present"
        )

        late = sum(
            1
            for row in records
            if row["status"] == "Late"
        )

        absent = max(
            0,
            total_students
            - present
            - late,
        )

        attendance_percentage = (
            round(
                (
                    (present + late)
                    / total_students
                )
                * 100,
                1,
            )
            if total_students
            else 0
        )

        student_rows = []

        for student in students:

            record = record_map.get(
                student["id"]
            )

            student_rows.append(
                {
                    "id": student["id"],
                    "name": student["name"],
                    "rollNo": student["roll_no"],
                    "className":
                        student["class_name"],
                    "rfidUid":
                        student["rfid_uid"],
                    "status": (
                        record["status"]
                        if record
                        else "Absent"
                    ),
                    "checkInTime": (
                        record["check_in_time"]
                        if record
                        else None
                    ),
                    "source": (
                        record["source"]
                        if record
                        else None
                    ),
                }
            )

        recent_scans = conn.execute(
            """
            SELECT
                se.*,
                s.name,
                s.roll_no,
                s.class_name
            FROM scan_events se
            LEFT JOIN students s
              ON s.id = se.student_id
            ORDER BY
                se.created_at DESC
            LIMIT 10
            """
        ).fetchall()

        trend_start = (
            date.today()
            - timedelta(days=9)
        ).isoformat()

        trend_rows = conn.execute(
            """
            SELECT
                attendance_date,
                COUNT(*) AS present_count
            FROM attendance_records
            WHERE
                attendance_date >= ?
                AND status IN
                    ('Present', 'Late')
            GROUP BY attendance_date
            ORDER BY attendance_date ASC
            """,
            (
                trend_start,
            ),
        ).fetchall()

        trend = [
            {
                "date":
                    row["attendance_date"],
                "present":
                    row["present_count"],
                "percentage": (
                    round(
                        (
                            row["present_count"]
                            / total_students
                        )
                        * 100,
                        1,
                    )
                    if total_students
                    else 0
                ),
            }
            for row in trend_rows
        ]

        device = device_status_payload(
            conn
        )

        visits_row = conn.execute(
            """
            SELECT total_visits
            FROM site_visits
            WHERE id = 1
            """
        ).fetchone()

        visits = (
            int(
                visits_row["total_visits"]
            )
            if visits_row
            else 0
        )

        return {
            "ok": True,

            "date": selected_date,

            "generatedAt": iso_now(),

            "visits": {
                "total": visits,
            },

            "metrics": {
                "totalStudents":
                    total_students,
                "present":
                    present,
                "late":
                    late,
                "absent":
                    absent,
                "attendancePercentage":
                    attendance_percentage,
                "recentScans":
                    len(recent_scans),
            },

            "students": student_rows,

            "recentScans": [
                {
                    "id":
                        row["id"],
                    "studentName":
                        row["name"]
                        or "Unknown Card",
                    "rollNo":
                        row["roll_no"],
                    "rfidUid":
                        row["rfid_uid"],
                    "status":
                        row["status"],
                    "message":
                        row["message"],
                    "deviceId":
                        row["device_id"],
                    "createdAt":
                        row["created_at"],
                }
                for row in recent_scans
            ],

            "trend": trend,

            "device": device,
        }


def analytics_snapshot(
    start_date: str | None,
    end_date: str | None,
    student_id: int | None = None,
) -> dict[str, Any]:

    date_filter = ""
    params: list[Any] = []

    if start_date:
        date_filter += """
            AND ar.attendance_date >= ?
        """
        params.append(start_date)

    if end_date:
        date_filter += """
            AND ar.attendance_date <= ?
        """
        params.append(end_date)

    student_filter = ""

    if student_id is not None:
        student_filter = """
            AND s.id = ?
        """
        params.append(student_id)

    today = date.today().isoformat()

    with closing(connect()) as conn:

        total_students = conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM students
            """
        ).fetchone()["count"]

        selected_student = None

        if student_id is not None:
            selected_student = conn.execute(
                """
                SELECT *
                FROM students
                WHERE id = ?
                LIMIT 1
                """,
                (
                    student_id,
                ),
            ).fetchone()

            if not selected_student:
                raise ValueError(
                    "Student not found."
                )

        total_records = conn.execute(
            f"""
            SELECT COUNT(*) AS count
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE 1 = 1
            {date_filter}
            {student_filter}
            """,
            params,
        ).fetchone()["count"]

        active_students = conn.execute(
            f"""
            SELECT COUNT(DISTINCT ar.student_id)
                   AS count
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE 1 = 1
            {date_filter}
            {student_filter}
            """,
            params,
        ).fetchone()["count"]

        present_today = conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM attendance_records
            WHERE
                attendance_date = ?
                AND status IN ('Present', 'Late')
            """,
            (
                today,
            ),
        ).fetchone()["count"]

        absent_today = max(
            0,
            total_students - present_today,
        )

        active_date_rows = conn.execute(
            f"""
            SELECT DISTINCT ar.attendance_date
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE 1 = 1
            {date_filter}
            {student_filter}
            ORDER BY ar.attendance_date ASC
            """,
            params,
        ).fetchall()

        active_dates = [
            row["attendance_date"]
            for row in active_date_rows
        ]

        if (
            start_date
            and end_date
            and start_date == end_date
            and start_date not in active_dates
        ):
            active_dates.append(start_date)

        active_dates = sorted(
            set(active_dates)
        )

        active_day_count = len(
            active_dates
        )

        status_rows = conn.execute(
            f"""
            SELECT
                ar.status,
                COUNT(*) AS count
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE 1 = 1
            {date_filter}
            {student_filter}
            GROUP BY ar.status
            """,
            params,
        ).fetchall()

        status_counts = {
            "Present": 0,
            "Late": 0,
            "Absent": 0,
        }

        for row in status_rows:
            status_counts[row["status"]] = row["count"]

        source_rows = conn.execute(
            f"""
            SELECT
                COALESCE(ar.source, 'System') AS source,
                COUNT(*) AS count
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE 1 = 1
            {date_filter}
            {student_filter}
            GROUP BY COALESCE(ar.source, 'System')
            ORDER BY count DESC,
                     source ASC
            """,
            params,
        ).fetchall()

        present_or_late = (
            status_counts.get("Present", 0)
            + status_counts.get("Late", 0)
        )

        denominator = (
            active_day_count
            * (
                1
                if student_id is not None
                else total_students
            )
        )

        calculated_absent = max(
            0,
            denominator - present_or_late,
        )

        if denominator:
            status_counts["Absent"] = max(
                status_counts.get("Absent", 0),
                calculated_absent,
            )

        attendance_percentage = (
            round(
                present_or_late / denominator * 100,
                1,
            )
            if denominator
            else 0
        )

        trend_rows = conn.execute(
            f"""
            SELECT
                ar.attendance_date,
                SUM(
                    CASE
                        WHEN ar.status IN
                             ('Present', 'Late')
                        THEN 1
                        ELSE 0
                    END
                ) AS attended_count,
                COUNT(*) AS record_count
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE 1 = 1
            {date_filter}
            {student_filter}
            GROUP BY ar.attendance_date
            ORDER BY ar.attendance_date ASC
            """,
            params,
        ).fetchall()

        trend_map = {
            row["attendance_date"]: row
            for row in trend_rows
        }

        trend = []

        for active_date in active_dates:
            row = trend_map.get(
                active_date
            )

            attended = (
                row["attended_count"]
                if row
                else 0
            )

            daily_denominator = (
                1
                if student_id is not None
                else total_students
            )

            trend.append(
                {
                    "date":
                        active_date,
                    "present":
                        attended,
                    "records":
                        (
                            row["record_count"]
                            if row
                            else 0
                        ),
                    "absent":
                        max(
                            0,
                            daily_denominator
                            - attended,
                        ),
                    "percentage": (
                        round(
                            attended
                            / daily_denominator
                            * 100,
                            1,
                        )
                        if daily_denominator
                        else 0
                    ),
                }
            )

        join_date_filter = ""
        join_params: list[Any] = []

        if start_date:
            join_date_filter += """
             AND ar.attendance_date >= ?
            """
            join_params.append(start_date)

        if end_date:
            join_date_filter += """
             AND ar.attendance_date <= ?
            """
            join_params.append(end_date)

        roster_filter = ""
        roster_params = list(join_params)

        if student_id is not None:
            roster_filter = """
            AND s.id = ?
            """
            roster_params.append(student_id)

        class_rows = conn.execute(
            f"""
            SELECT
                s.class_name,
                SUM(
                    CASE
                        WHEN ar.status IN
                             ('Present', 'Late')
                        THEN 1
                        ELSE 0
                    END
                ) AS present_count,
                COUNT(ar.id) AS record_count
            FROM students s
            LEFT JOIN attendance_records ar
              ON ar.student_id = s.id
            {join_date_filter}
            WHERE 1 = 1
            {roster_filter}
            GROUP BY s.class_name
            ORDER BY present_count DESC,
                     s.class_name ASC
            """,
            roster_params,
        ).fetchall()

        ranking_rows = conn.execute(
            f"""
            SELECT
                s.id,
                s.name,
                s.roll_no,
                s.class_name,
                s.rfid_uid,
                SUM(
                    CASE
                        WHEN ar.status IN
                             ('Present', 'Late')
                        THEN 1
                        ELSE 0
                    END
                ) AS present_days,
                SUM(
                    CASE
                        WHEN ar.status = 'Absent'
                        THEN 1
                        ELSE 0
                    END
                ) AS explicit_absent_days,
                COUNT(ar.id) AS record_count
            FROM students s
            LEFT JOIN attendance_records ar
              ON ar.student_id = s.id
            {join_date_filter}
            WHERE 1 = 1
            {roster_filter}
            GROUP BY s.id
            ORDER BY
                present_days DESC,
                CASE
                    WHEN s.roll_no GLOB '[0-9]*'
                    THEN CAST(s.roll_no AS INTEGER)
                    ELSE 999999
                END,
                s.name
            """,
            roster_params,
        ).fetchall()

        ranking = []

        for index, row in enumerate(
            ranking_rows,
            start=1,
        ):
            present_days = row["present_days"] or 0
            implicit_absent = max(
                0,
                active_day_count - present_days,
            )
            absent_days = max(
                row["explicit_absent_days"] or 0,
                implicit_absent,
            )
            student_percentage = (
                round(
                    present_days
                    / active_day_count
                    * 100,
                    1,
                )
                if active_day_count
                else 0
            )

            ranking.append(
                {
                    "rank": index,
                    "studentId": row["id"],
                    "studentName": row["name"],
                    "rollNo": row["roll_no"],
                    "className": row["class_name"],
                    "rfidUid": row["rfid_uid"],
                    "presentDays": present_days,
                    "absentDays": absent_days,
                    "records": row["record_count"] or 0,
                    "attendancePercentage":
                        student_percentage,
                }
            )

        history_rows = conn.execute(
            f"""
            SELECT
                ar.*,
                s.name,
                s.class_name,
                s.roll_no
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE 1 = 1
            {date_filter}
            {student_filter}
            ORDER BY
                ar.attendance_date DESC,
                ar.check_in_time DESC
            LIMIT 120
            """,
            params,
        ).fetchall()

        return {
            "ok": True,
            "generatedAt": iso_now(),
            "range": {
                "startDate": start_date,
                "endDate": end_date,
                "activeDays": active_day_count,
                "basis": (
                    "single selected day"
                    if active_day_count == 1
                    else "dates with real attendance activity"
                ),
            },
            "student": (
                serialize_student(
                    selected_student
                )
                if selected_student
                else None
            ),
            "metrics": {
                "totalStudents":
                    total_students,
                "presentToday":
                    present_today,
                "absentToday":
                    absent_today,
                "overallAttendancePercentage":
                    attendance_percentage,
                "totalAttendanceRecords":
                    total_records,
                "activeStudents":
                    active_students,
                "activeDays":
                    active_day_count,
            },
            "statusBreakdown": [
                {
                    "status": key,
                    "count": status_counts.get(
                        key,
                        0,
                    ),
                }
                for key in (
                    "Present",
                    "Late",
                    "Absent",
                )
            ],
            "sourceBreakdown": [
                {
                    "source":
                        row["source"],
                    "count":
                        row["count"],
                }
                for row in source_rows
            ],
            "trend": trend,
            "classSummary": [
                {
                    "className":
                        row["class_name"],
                    "present":
                        row["present_count"] or 0,
                    "records":
                        row["record_count"] or 0,
                }
                for row in class_rows
            ],
            "ranking": ranking,
            "history": [
                serialize_attendance(row)
                for row in history_rows
            ],
            "heatmap": [
                {
                    "date": row["date"],
                    "count": row["present"],
                    "percentage": row["percentage"],
                }
                for row in trend
            ],
        }


# ============================================================
# SECURITY HEADERS
# ============================================================

@app.after_request
def security_headers(
    response: Response,
):

    response.headers[
        "X-Content-Type-Options"
    ] = "nosniff"

    response.headers[
        "X-Frame-Options"
    ] = "SAMEORIGIN"

    response.headers[
        "Referrer-Policy"
    ] = "strict-origin-when-cross-origin"

    response.headers[
        "Permissions-Policy"
    ] = (
        "camera=(), "
        "microphone=(), "
        "geolocation=()"
    )

    origin = request.headers.get(
        "Origin"
    )

    if (
        origin
        and origin.rstrip("/")
        in ALLOWED_ORIGINS
    ):

        response.headers[
            "Access-Control-Allow-Origin"
        ] = origin

        response.headers[
            "Access-Control-Allow-Credentials"
        ] = "true"

        response.headers[
            "Vary"
        ] = "Origin"

    response.headers[
        "Access-Control-Allow-Headers"
    ] = (
        "Content-Type, "
        "X-Device-Secret, "
        "X-Request-ID"
    )

    response.headers[
        "Access-Control-Allow-Methods"
    ] = (
        "GET, POST, PATCH, PUT, DELETE, OPTIONS"
    )

    return response


# ============================================================
# REQUEST LOGGING
# ============================================================

@app.before_request
def before_request():

    if request.path.startswith(
        "/static/"
    ):
        return None

    cleanup_login_attempts()

    return None


@app.after_request
def request_logging(
    response: Response,
):

    if not request.path.startswith(
        "/static/"
    ):

        logger.info(
            "%s %s -> %s",
            request.method,
            request.path,
            response.status_code,
        )

    return response


# ============================================================
# ERROR HANDLING
# ============================================================

@app.errorhandler(HTTPException)
def handle_http_error(
    error: HTTPException,
):

    return error_response(
        error.description
        or "Request failed.",
        error.code or 500,
        "HTTP_ERROR",
    )


@app.errorhandler(
    sqlite3.IntegrityError
)
def handle_integrity_error(
    error: sqlite3.IntegrityError,
):

    logger.warning(
        "SQLite integrity error: %s",
        error,
    )

    return error_response(
        "The requested operation conflicts with existing data.",
        409,
        "DATABASE_CONFLICT",
    )


@app.errorhandler(
    sqlite3.OperationalError
)
def handle_database_error(
    error: sqlite3.OperationalError,
):

    logger.exception(
        "SQLite operational error"
    )

    return error_response(
        "Database is temporarily unavailable. Please try again.",
        503,
        "DATABASE_UNAVAILABLE",
    )


@app.errorhandler(Exception)
def handle_unexpected_error(
    error: Exception,
):

    logger.exception(
        "Unhandled server error"
    )

    return error_response(
        "Internal server error.",
        500,
        "INTERNAL_ERROR",
    )


# ============================================================
# BASIC ROUTES
# ============================================================

@app.route("/")
def index():

    record_site_visit()

    return send_from_directory(
        app.static_folder,
        "index.html",
    )


@app.route("/api/health")
def health():
    database_accessible = False

    try:
        with closing(connect()) as conn:
            conn.execute(
                "SELECT 1"
            ).fetchone()
            database_accessible = True
    except Exception:
        logger.exception(
            "Health check database probe failed"
        )

    return ok_response(
        {
            "service":
                APP_NAME,

            "version":
                APP_VERSION,

            "time":
                iso_now(),

            "database":
                DB_PATH.exists(),

            "databaseAccessible":
                database_accessible,
        }
    )


# ============================================================
# AUTH — SESSION
# ============================================================

@app.route(
    "/api/auth/session",
    methods=["GET"],
)
def auth_session():

    identity = current_identity()

    with closing(connect()) as conn:
        allow_signup = admin_signup_available(
            conn
        )

    return ok_response(
        {
            "authenticated":
                bool(identity),

            "admin":
                (
                    identity
                    if identity
                    and identity.get("role") == "admin"
                    else None
                ),

            "account":
                identity,

            "role":
                (
                    identity.get("role")
                    if identity
                    else None
                ),

            "allowSignup":
                allow_signup,
        }
    )


# ============================================================
# AUTH — LOGIN
# ============================================================

@app.route(
    "/api/auth/login",
    methods=[
        "POST",
        "OPTIONS",
    ],
)
def auth_login():

    if request.method == "OPTIONS":
        return ok_response()

    payload = request_payload()

    username = clean_string(
        payload.get("username"),
        80,
    )

    password = str(
        payload.get(
            "password",
            "",
        )
    )

    if not username or not password:

        return error_response(
            "Username and password are required.",
            400,
            "MISSING_CREDENTIALS",
        )

    rate_key = (
        f"{request.remote_addr or 'unknown'}:"
        f"{username.lower()}"
    )

    if login_rate_limited(
        rate_key
    ):

        return error_response(
            "Too many login attempts. Please wait and try again.",
            429,
            "LOGIN_RATE_LIMITED",
        )

    record_login_attempt(
        rate_key
    )

    with closing(connect()) as conn:

        admin = conn.execute(
            """
            SELECT *
            FROM admins
            WHERE lower(username)
                  = lower(?)
            LIMIT 1
            """,
            (
                username,
            ),
        ).fetchone()

        valid = bool(
            admin
            and verify_password_hash(
                admin["password_hash"],
                password,
            )
        )

        if valid:

            # Prevent session fixation.
            session.clear()

            session["role"] = "admin"

            session["admin_id"] = int(
                admin["id"]
            )

            session["admin_username"] = (
                admin["username"]
            )

            record_login_event(
                conn,
                admin["username"],
                "success",
                int(admin["id"]),
            )

            conn.commit()

            return ok_response(
                {
                    "authenticated":
                        True,

                    "role":
                        "admin",

                    "message":
                        "Login successful",

                    "admin": {
                        "id":
                            admin["id"],
                        "username":
                            admin["username"],
                        "role":
                            "admin",
                        "createdAt":
                            admin["created_at"],
                    },

                    "account": {
                        "id":
                            admin["id"],
                        "username":
                            admin["username"],
                        "role":
                            "admin",
                        "createdAt":
                            admin["created_at"],
                    },
                }
            )

        student_account = conn.execute(
            """
            SELECT
                sa.*,
                s.name,
                s.roll_no,
                s.class_name,
                s.rfid_uid
            FROM student_accounts sa
            JOIN students s
              ON s.id = sa.student_id
            WHERE lower(sa.username)
                  = lower(?)
            LIMIT 1
            """,
            (
                username,
            ),
        ).fetchone()

        student_valid = bool(
            student_account
            and int(student_account["active"])
            and verify_password_hash(
                student_account["password_hash"],
                password,
            )
        )

        if (
            student_account
            and not int(student_account["active"])
            and verify_password_hash(
                student_account["password_hash"],
                password,
            )
        ):
            record_login_event(
                conn,
                username,
                "disabled",
            )

            conn.commit()

            return error_response(
                "This student account is disabled.",
                403,
                "ACCOUNT_DISABLED",
                authenticated=False,
            )

        if not student_valid:

            record_login_event(
                conn,
                username,
                "failed",
            )

            conn.commit()

            return error_response(
                "Invalid username or password.",
                401,
                "INVALID_CREDENTIALS",
                authenticated=False,
            )

        session.clear()

        session["role"] = "student"

        session["student_account_id"] = int(
            student_account["id"]
        )

        session["student_id"] = int(
            student_account["student_id"]
        )

        record_login_event(
            conn,
            student_account["username"],
            "success",
        )

        conn.commit()

        return ok_response(
            {
                "authenticated":
                    True,

                "role":
                    "student",

                "message":
                    "Login successful",

                "admin":
                    None,

                "account": {
                    "id":
                        student_account["id"],
                    "username":
                        student_account["username"],
                    "role":
                        "student",
                    "studentId":
                        student_account["student_id"],
                    "createdAt":
                        student_account["created_at"],
                    "student": {
                        "id":
                            student_account["student_id"],
                        "name":
                            student_account["name"],
                        "rollNo":
                            student_account["roll_no"],
                        "className":
                            student_account["class_name"],
                        "rfidUid":
                            student_account["rfid_uid"],
                    },
                },
            }
        )


# ============================================================
# AUTH — SIGNUP
# ============================================================

@app.route(
    "/api/auth/signup",
    methods=[
        "POST",
        "OPTIONS",
    ],
)
def auth_signup():

    if request.method == "OPTIONS":
        return ok_response()

    payload = request_payload()

    username = clean_string(
        payload.get("username"),
        32,
    )

    password = str(
        payload.get(
            "password",
            "",
        )
    )

    if not USERNAME_PATTERN.fullmatch(
        username
    ):

        return error_response(
            "Username must contain 3–32 letters, numbers, dots, underscores, or hyphens.",
            400,
            "INVALID_USERNAME",
        )

    if len(password) < 5:

        return error_response(
            "Password must be at least 5 characters.",
            400,
            "WEAK_PASSWORD",
        )

    stamp = iso_now()

    with closing(connect()) as conn:

        if not admin_signup_available(
            conn
        ):

            return error_response(
                "Admin signup is disabled because this system already has an admin account.",
                403,
                "SIGNUP_DISABLED",
                allowSignup=False,
            )

        existing = conn.execute(
            """
            SELECT id
            FROM admins
            WHERE lower(username)
                  = lower(?)
            LIMIT 1
            """,
            (
                username,
            ),
        ).fetchone()

        if existing:

            return error_response(
                "This username already exists.",
                409,
                "USERNAME_EXISTS",
            )

        try:

            cursor = conn.execute(
                """
                INSERT INTO admins
                (
                    username,
                    password_hash,
                    created_at,
                    updated_at
                )
                VALUES (?, ?, ?, ?)
                """,
                (
                    username,
                    generate_password_hash(
                        password,
                        method=(
                            "pbkdf2:"
                            "sha256:"
                            "600000"
                        ),
                    ),
                    stamp,
                    stamp,
                ),
            )

            admin_id = cursor.lastrowid

            record_login_event(
                conn,
                username,
                "signup",
                admin_id,
            )

            conn.commit()

        except sqlite3.IntegrityError:

            conn.rollback()

            return error_response(
                "This username already exists.",
                409,
                "USERNAME_EXISTS",
            )

        session.clear()

        session["admin_id"] = int(
            admin_id
        )

        session["admin_username"] = (
            username
        )

        return ok_response(
            {
                "authenticated":
                    True,

                "message":
                    "Account created",

                "admin": {
                    "id":
                        admin_id,
                    "username":
                        username,
                },
            }
        )


# ============================================================
# AUTH — LOGOUT
# ============================================================

@app.route(
    "/api/auth/logout",
    methods=[
        "POST",
        "OPTIONS",
    ],
)
def auth_logout():

    if request.method == "OPTIONS":
        return ok_response()

    session.clear()

    return ok_response(
        {
            "authenticated":
                False,

            "message":
                "Logged out",
        }
    )


# ============================================================
# DASHBOARD
# ============================================================

@app.route(
    "/api/dashboard",
    methods=["GET"],
)
@admin_required
def api_dashboard():

    selected_date, error = (
        parse_date_strict(
            request.args.get(
                "date"
            )
        )
    )

    if error:

        return error_response(
            error,
            400,
            "INVALID_DATE",
        )

    return jsonify(
        dashboard_snapshot(
            selected_date
        )
    )


# ============================================================
# PROFILE
# ============================================================

@app.route(
    "/api/profile",
    methods=["GET"],
)
@admin_required
def api_profile():

    admin = current_admin()

    with closing(connect()) as conn:

        login_history = conn.execute(
            """
            SELECT
                username,
                status,
                source_ip,
                user_agent,
                created_at
            FROM login_events
            WHERE
                admin_id = ?
                OR lower(username)
                   = lower(?)
            ORDER BY
                created_at DESC
            LIMIT 25
            """,
            (
                admin["id"],
                admin["username"],
            ),
        ).fetchall()

        successful_logins = conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM login_events
            WHERE
                admin_id = ?
                AND status IN
                    ('success', 'signup')
            """,
            (
                admin["id"],
            ),
        ).fetchone()["count"]

        failed_logins = conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM login_events
            WHERE
                lower(username)
                    = lower(?)
                AND status = 'failed'
            """,
            (
                admin["username"],
            ),
        ).fetchone()["count"]

        visits = conn.execute(
            """
            SELECT total_visits
            FROM site_visits
            WHERE id = 1
            """
        ).fetchone()

        return ok_response(
            {
                "admin":
                    admin,

                "stats": {
                    "totalLogins":
                        successful_logins,
                    "failedAttempts":
                        failed_logins,
                    "historyCount":
                        len(login_history),
                },

                "visits": {
                    "total":
                        (
                            int(
                                visits[
                                    "total_visits"
                                ]
                            )
                            if visits
                            else 0
                        ),
                },

                "loginHistory": [
                    {
                        "username":
                            row["username"],
                        "status":
                            row["status"],
                        "sourceIp":
                            row["source_ip"],
                        "userAgent":
                            row["user_agent"],
                        "createdAt":
                            row["created_at"],
                    }
                    for row in login_history
                ],
            }
        )


# ============================================================
# STUDENTS — GET / POST
# ============================================================

@app.route(
    "/api/students",
    methods=[
        "GET",
        "POST",
        "OPTIONS",
    ],
)
@admin_required
def api_students():

    if request.method == "OPTIONS":
        return ok_response()

    if request.method == "GET":

        search = clean_string(
            request.args.get(
                "search"
            ),
            100,
        ).lower()

        query = """
            SELECT *
            FROM students
            WHERE 1 = 1
        """

        params: list[Any] = []

        if search:
            query += """
                AND (
                    lower(name) LIKE ?
                    OR lower(roll_no) LIKE ?
                    OR lower(rfid_uid) LIKE ?
                    OR lower(class_name) LIKE ?
                )
            """

            search_term = f"%{search}%"

            params.extend(
                [
                    search_term,
                    search_term,
                    search_term,
                    search_term,
                ]
            )

        query += """
            ORDER BY
                CASE
                    WHEN roll_no
                         GLOB '[0-9]*'
                    THEN CAST(
                        roll_no AS INTEGER
                    )
                    ELSE 999999
                END,
                name
        """

        with closing(connect()) as conn:

            rows = conn.execute(
                query,
                params,
            ).fetchall()

            stats = student_stats_map(
                conn,
                [
                    int(row["id"])
                    for row in rows
                ],
            )

            return ok_response(
                {
                    "search": search,
                    "students": [
                        serialize_student(
                            row,
                            stats.get(
                                int(row["id"])
                            ),
                        )
                        for row in rows
                    ]
                }
            )

    payload = request_payload()

    student, validation_error = (
        validate_student(
            payload
        )
    )

    if validation_error:

        return error_response(
            validation_error,
            400,
            "INVALID_STUDENT",
        )

    with closing(connect()) as conn:

        duplicate_uid = conn.execute(
            """
            SELECT
                id,
                name,
                roll_no,
                class_name
            FROM students
            WHERE lower(rfid_uid)
                  = lower(?)
            LIMIT 1
            """,
            (
                student["rfid_uid"],
            ),
        ).fetchone()

        if duplicate_uid:

            return error_response(
                "This RFID UID is already registered.",
                409,
                "DUPLICATE_RFID",
                student={
                    "id":
                        duplicate_uid["id"],
                    "name":
                        duplicate_uid["name"],
                    "rollNo":
                        duplicate_uid["roll_no"],
                    "className":
                        duplicate_uid["class_name"],
                },
            )

        duplicate_roll = conn.execute(
            """
            SELECT
                id,
                name,
                roll_no,
                class_name
            FROM students
            WHERE lower(roll_no)
                  = lower(?)
            LIMIT 1
            """,
            (
                student["roll_no"],
            ),
        ).fetchone()

        if duplicate_roll:

            return error_response(
                "This roll number is already registered.",
                409,
                "DUPLICATE_ROLL",
                student={
                    "id":
                        duplicate_roll["id"],
                    "name":
                        duplicate_roll["name"],
                    "rollNo":
                        duplicate_roll["roll_no"],
                    "className":
                        duplicate_roll["class_name"],
                },
            )

        stamp = iso_now()

        try:

            cursor = conn.execute(
                """
                INSERT INTO students
                (
                    name,
                    rfid_uid,
                    class_name,
                    roll_no,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    student["name"],
                    student["rfid_uid"],
                    student["class_name"],
                    student["roll_no"],
                    stamp,
                ),
            )

            conn.commit()

        except sqlite3.IntegrityError:

            conn.rollback()

            return error_response(
                "Student could not be added because one of the values already exists.",
                409,
                "DUPLICATE_STUDENT",
            )

        row = conn.execute(
            """
            SELECT *
            FROM students
            WHERE id = ?
            """,
            (
                cursor.lastrowid,
            ),
        ).fetchone()

        return ok_response(
            {
                "message":
                    "Student added",

                "student":
                    serialize_student(
                        row
                    ),
            },
            201,
        )


# ============================================================
# RFID ENROLLMENT VALIDATION
# ============================================================

@app.route(
    "/api/rfid/enrollment/validate",
    methods=[
        "POST",
        "OPTIONS",
    ],
)
@admin_required
def api_rfid_enrollment_validate():

    if request.method == "OPTIONS":
        return ok_response()

    payload = request_payload()

    raw_uid = (
        payload.get(
            "uid"
        )
        or payload.get(
            "rfid_uid"
        )
    )

    if raw_uid is None:

        return error_response(
            "Missing RFID UID.",
            400,
            "MISSING_UID",
        )

    uid = normalize_uid(
        raw_uid
    )

    if not is_valid_uid(uid):

        return error_response(
            "Invalid RFID UID format.",
            422,
            "INVALID_UID",
            uid=uid,
        )

    with closing(connect()) as conn:

        existing = conn.execute(
            """
            SELECT
                id,
                name,
                roll_no,
                class_name
            FROM students
            WHERE lower(rfid_uid)
                  = lower(?)
            LIMIT 1
            """,
            (
                uid,
            ),
        ).fetchone()

        if existing:

            return error_response(
                "This RFID UID is already registered.",
                409,
                "DUPLICATE_RFID",
                uid=uid,
                student={
                    "id":
                        existing["id"],
                    "name":
                        existing["name"],
                    "rollNo":
                        existing["roll_no"],
                    "className":
                        existing["class_name"],
                },
            )

        return ok_response(
            {
                "uid":
                    uid,
                "valid":
                    True,
                "duplicate":
                    False,
                "message":
                    "RFID card is ready to be assigned.",
            }
        )


# ============================================================
# STUDENT DELETE
# ============================================================

@app.route(
    "/api/students/<int:student_id>",
    methods=[
        "GET",
        "PUT",
        "PATCH",
        "DELETE",
        "OPTIONS",
    ],
)
@admin_required
def api_student_detail(
    student_id: int,
):

    if request.method == "OPTIONS":
        return ok_response()

    with closing(connect()) as conn:

        conn.execute(
            "BEGIN IMMEDIATE"
        )

        student = conn.execute(
            """
            SELECT *
            FROM students
            WHERE id = ?
            LIMIT 1
            """,
            (
                student_id,
            ),
        ).fetchone()

        if not student:
            conn.rollback()

            return error_response(
                "Student not found.",
                404,
                "STUDENT_NOT_FOUND",
            )

        if request.method == "GET":
            return jsonify(
                student_profile_payload(
                    conn,
                    student_id,
                )
            )

        if request.method in {
            "PUT",
            "PATCH",
        }:

            payload = request_payload()

            candidate, validation_error = validate_student(
                {
                    "name":
                        payload.get(
                            "name",
                            student["name"],
                        ),
                    "rollNo":
                        payload.get(
                            "rollNo",
                            payload.get(
                                "roll_no",
                                student["roll_no"],
                            ),
                        ),
                    "className":
                        payload.get(
                            "className",
                            payload.get(
                                "class_name",
                                student["class_name"],
                            ),
                        ),
                    "rfidUid":
                        payload.get(
                            "rfidUid",
                            payload.get(
                                "rfid_uid",
                                student["rfid_uid"],
                            ),
                        ),
                }
            )

            if validation_error:
                conn.rollback()

                return error_response(
                    validation_error,
                    400,
                    "INVALID_STUDENT",
                )

            duplicate_uid = conn.execute(
                """
                SELECT id, name, roll_no, class_name
                FROM students
                WHERE
                    lower(rfid_uid) = lower(?)
                    AND id != ?
                LIMIT 1
                """,
                (
                    candidate["rfid_uid"],
                    student_id,
                ),
            ).fetchone()

            if duplicate_uid:
                conn.rollback()

                return error_response(
                    "This RFID UID is already registered.",
                    409,
                    "DUPLICATE_RFID",
                    student={
                        "id": duplicate_uid["id"],
                        "name": duplicate_uid["name"],
                        "rollNo": duplicate_uid["roll_no"],
                        "className": duplicate_uid["class_name"],
                    },
                )

            duplicate_roll = conn.execute(
                """
                SELECT id, name, roll_no, class_name
                FROM students
                WHERE
                    lower(roll_no) = lower(?)
                    AND id != ?
                LIMIT 1
                """,
                (
                    candidate["roll_no"],
                    student_id,
                ),
            ).fetchone()

            if duplicate_roll:
                conn.rollback()

                return error_response(
                    "This roll number is already registered.",
                    409,
                    "DUPLICATE_ROLL",
                    student={
                        "id": duplicate_roll["id"],
                        "name": duplicate_roll["name"],
                        "rollNo": duplicate_roll["roll_no"],
                        "className": duplicate_roll["class_name"],
                    },
                )

            conn.execute(
                """
                UPDATE students
                SET
                    name = ?,
                    roll_no = ?,
                    class_name = ?,
                    rfid_uid = ?,
                    active = ?
                WHERE id = ?
                """,
                (
                    candidate["name"],
                    candidate["roll_no"],
                    candidate["class_name"],
                    candidate["rfid_uid"],
                    (
                        1
                        if bool(
                            payload.get(
                                "active",
                                student[
                                    "active"
                                ]
                                if "active" in student.keys()
                                else 1,
                            )
                        )
                        else 0
                    ),
                    student_id,
                ),
            )

            conn.execute(
                """
                UPDATE attendance_records
                SET rfid_uid = ?
                WHERE student_id = ?
                """,
                (
                    candidate["rfid_uid"],
                    student_id,
                ),
            )

            updated = conn.execute(
                """
                SELECT *
                FROM students
                WHERE id = ?
                LIMIT 1
                """,
                (
                    student_id,
                ),
            ).fetchone()

            conn.commit()

            return ok_response(
                {
                    "message":
                        f"{updated['name']} updated.",
                    "student":
                        serialize_student(
                            updated
                        ),
                }
            )

        attendance_count = conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM attendance_records
            WHERE student_id = ?
            """,
            (
                student_id,
            ),
        ).fetchone()["count"]

        if attendance_count:
            conn.execute(
                """
                UPDATE students
                SET active = 0
                WHERE id = ?
                """,
                (
                    student_id,
                ),
            )

            conn.execute(
                """
                UPDATE student_accounts
                SET
                    active = 0,
                    updated_at = ?
                WHERE student_id = ?
                """,
                (
                    iso_now(),
                    student_id,
                ),
            )

            conn.commit()

            return ok_response(
                {
                    "message":
                        f"{student['name']} disabled to preserve attendance history.",
                    "disabled":
                        True,
                    "attendanceRecords":
                        int(attendance_count),
                }
            )

        conn.execute(
            """
            UPDATE scan_events
            SET student_id = NULL
            WHERE student_id = ?
            """,
            (
                student_id,
            ),
        )

        conn.execute(
            """
            DELETE FROM students
            WHERE id = ?
            """,
            (
                student_id,
            ),
        )

        conn.commit()

        return ok_response(
            {
                "message":
                    f"{student['name']} deleted.",
            }
        )


# ============================================================
# STUDENT ACCOUNTS — ADMIN MANAGEMENT
# ============================================================

@app.route(
    "/api/student-accounts",
    methods=[
        "GET",
        "POST",
        "OPTIONS",
    ],
)
@admin_required
def api_student_accounts():

    if request.method == "OPTIONS":
        return ok_response()

    with closing(connect()) as conn:

        if request.method == "GET":

            rows = conn.execute(
                """
                SELECT
                    sa.id,
                    sa.student_id,
                    sa.username,
                    sa.active,
                    sa.created_at,
                    sa.updated_at,
                    s.name,
                    s.roll_no,
                    s.class_name
                FROM student_accounts sa
                JOIN students s
                  ON s.id = sa.student_id
                ORDER BY
                    CASE
                        WHEN s.roll_no GLOB '[0-9]*'
                        THEN CAST(s.roll_no AS INTEGER)
                        ELSE 999999
                    END,
                    s.name
                """
            ).fetchall()

            return ok_response(
                {
                    "accounts": [
                        {
                            **serialize_student_account(row),
                            "studentName": row["name"],
                            "rollNo": row["roll_no"],
                            "className": row["class_name"],
                        }
                        for row in rows
                    ]
                }
            )

        payload = request_payload()

        student_id = payload.get(
            "studentId",
            payload.get("student_id"),
        )

        try:
            student_id = int(student_id)
        except (
            TypeError,
            ValueError,
        ):
            return error_response(
                "Invalid student ID.",
                400,
                "INVALID_STUDENT_ID",
            )

        username = clean_string(
            payload.get("username"),
            32,
        )

        password = str(
            payload.get("password", "")
        )

        if not USERNAME_PATTERN.fullmatch(username):
            return error_response(
                "Username must contain 3-32 letters, numbers, dots, underscores, or hyphens.",
                400,
                "INVALID_USERNAME",
            )

        if len(password) < 5:
            return error_response(
                "Password must be at least 5 characters.",
                400,
                "WEAK_PASSWORD",
            )

        conn.execute("BEGIN IMMEDIATE")

        student = conn.execute(
            """
            SELECT id
            FROM students
            WHERE id = ?
            LIMIT 1
            """,
            (
                student_id,
            ),
        ).fetchone()

        if not student:
            conn.rollback()
            return error_response(
                "Student not found.",
                404,
                "STUDENT_NOT_FOUND",
            )

        existing_student_account = conn.execute(
            """
            SELECT id
            FROM student_accounts
            WHERE student_id = ?
            LIMIT 1
            """,
            (
                student_id,
            ),
        ).fetchone()

        if existing_student_account:
            conn.rollback()
            return error_response(
                "This student already has an account.",
                409,
                "STUDENT_ACCOUNT_EXISTS",
            )

        existing_username = conn.execute(
            """
            SELECT id
            FROM student_accounts
            WHERE lower(username) = lower(?)
            LIMIT 1
            """,
            (
                username,
            ),
        ).fetchone()

        existing_admin_username = conn.execute(
            """
            SELECT id
            FROM admins
            WHERE lower(username) = lower(?)
            LIMIT 1
            """,
            (
                username,
            ),
        ).fetchone()

        if existing_username or existing_admin_username:
            conn.rollback()
            return error_response(
                "This username already exists.",
                409,
                "USERNAME_EXISTS",
            )

        stamp = iso_now()

        cursor = conn.execute(
            """
            INSERT INTO student_accounts
            (
                student_id,
                username,
                password_hash,
                active,
                created_at,
                updated_at
            )
            VALUES (?, ?, ?, 1, ?, ?)
            """,
            (
                student_id,
                username,
                generate_password_hash(
                    password,
                    method="pbkdf2:sha256:600000",
                ),
                stamp,
                stamp,
            ),
        )

        account = conn.execute(
            """
            SELECT id, student_id, username, active, created_at, updated_at
            FROM student_accounts
            WHERE id = ?
            """,
            (
                cursor.lastrowid,
            ),
        ).fetchone()

        conn.commit()

        return ok_response(
            {
                "message":
                    "Student account created.",
                "account":
                    serialize_student_account(account),
            },
            201,
        )


@app.route(
    "/api/student-accounts/<int:account_id>",
    methods=[
        "PATCH",
        "OPTIONS",
    ],
)
@admin_required
def api_student_account_detail(
    account_id: int,
):

    if request.method == "OPTIONS":
        return ok_response()

    payload = request_payload()

    with closing(connect()) as conn:

        conn.execute("BEGIN IMMEDIATE")

        account = conn.execute(
            """
            SELECT id, student_id, username, active, created_at, updated_at
            FROM student_accounts
            WHERE id = ?
            LIMIT 1
            """,
            (
                account_id,
            ),
        ).fetchone()

        if not account:
            conn.rollback()
            return error_response(
                "Student account not found.",
                404,
                "STUDENT_ACCOUNT_NOT_FOUND",
            )

        active = account["active"]
        username = account["username"]
        password_hash = None

        if "active" in payload:
            active = 1 if bool(payload.get("active")) else 0

        if "username" in payload:
            username = clean_string(
                payload.get("username"),
                32,
            )
            if not USERNAME_PATTERN.fullmatch(username):
                conn.rollback()
                return error_response(
                    "Invalid username.",
                    400,
                    "INVALID_USERNAME",
                )

            duplicate = conn.execute(
                """
                SELECT id
                FROM student_accounts
                WHERE lower(username) = lower(?)
                  AND id != ?
                LIMIT 1
                """,
                (
                    username,
                    account_id,
                ),
            ).fetchone()

            duplicate_admin = conn.execute(
                """
                SELECT id
                FROM admins
                WHERE lower(username) = lower(?)
                LIMIT 1
                """,
                (
                    username,
                ),
            ).fetchone()

            if duplicate or duplicate_admin:
                conn.rollback()
                return error_response(
                    "This username already exists.",
                    409,
                    "USERNAME_EXISTS",
                )

        if payload.get("password"):
            password = str(payload.get("password"))
            if len(password) < 5:
                conn.rollback()
                return error_response(
                    "Password must be at least 5 characters.",
                    400,
                    "WEAK_PASSWORD",
                )
            password_hash = generate_password_hash(
                password,
                method="pbkdf2:sha256:600000",
            )

        stamp = iso_now()

        if password_hash:
            conn.execute(
                """
                UPDATE student_accounts
                SET
                    username = ?,
                    active = ?,
                    password_hash = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (
                    username,
                    active,
                    password_hash,
                    stamp,
                    account_id,
                ),
            )
        else:
            conn.execute(
                """
                UPDATE student_accounts
                SET
                    username = ?,
                    active = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (
                    username,
                    active,
                    stamp,
                    account_id,
                ),
            )

        updated = conn.execute(
            """
            SELECT id, student_id, username, active, created_at, updated_at
            FROM student_accounts
            WHERE id = ?
            """,
            (
                account_id,
            ),
        ).fetchone()

        conn.commit()

        return ok_response(
            {
                "message":
                    "Student account updated.",
                "account":
                    serialize_student_account(updated),
            }
        )


# ============================================================
# STUDENT PORTAL + EDIT REQUESTS
# ============================================================

@app.route(
    "/api/student/me",
    methods=["GET"],
)
@student_required
def api_student_me():

    account = current_student_account()

    with closing(connect()) as conn:
        return jsonify(
            student_profile_payload(
                conn,
                int(account["studentId"]),
            )
        )


@app.route(
    "/api/student/edit-requests",
    methods=[
        "GET",
        "POST",
        "OPTIONS",
    ],
)
@student_required
def api_student_edit_requests():

    if request.method == "OPTIONS":
        return ok_response()

    account = current_student_account()
    student_id = int(account["studentId"])

    with closing(connect()) as conn:

        if request.method == "GET":
            rows = conn.execute(
                """
                SELECT er.*, s.name, s.roll_no
                FROM student_edit_requests er
                JOIN students s
                  ON s.id = er.student_id
                WHERE er.student_id = ?
                ORDER BY er.created_at DESC
                """,
                (
                    student_id,
                ),
            ).fetchall()

            return ok_response(
                {
                    "requests": [
                        serialize_edit_request(row)
                        for row in rows
                    ]
                }
            )

        payload = request_payload()
        allowed_fields = {
            "name": "name",
            "rollNo": "roll_no",
            "className": "class_name",
            "rfidUid": "rfid_uid",
        }

        field_name = clean_string(
            payload.get("fieldName"),
            40,
        )

        if field_name not in allowed_fields:
            return error_response(
                "Invalid requested field.",
                400,
                "INVALID_EDIT_FIELD",
            )

        requested_value = clean_string(
            payload.get("requestedValue"),
            160,
        )

        reason = clean_string(
            payload.get("reason"),
            500,
        )

        if not requested_value:
            return error_response(
                "Requested value is required.",
                400,
                "REQUESTED_VALUE_REQUIRED",
            )

        if field_name == "rfidUid":
            requested_value = normalize_uid(
                requested_value
            )
            if not is_valid_uid(requested_value):
                return error_response(
                    "Invalid RFID UID format.",
                    400,
                    "INVALID_UID",
                )

        student = conn.execute(
            """
            SELECT *
            FROM students
            WHERE id = ?
            LIMIT 1
            """,
            (
                student_id,
            ),
        ).fetchone()

        current_value = student[
            allowed_fields[field_name]
        ]

        if str(current_value) == requested_value:
            return error_response(
                "Requested value matches the current value.",
                409,
                "NO_CHANGE_REQUESTED",
            )

        stamp = iso_now()

        try:
            cursor = conn.execute(
                """
                INSERT INTO student_edit_requests
                (
                    student_id,
                    field_name,
                    current_value,
                    requested_value,
                    reason,
                    status,
                    created_at,
                    updated_at
                )
                VALUES (?, ?, ?, ?, ?, 'Pending', ?, ?)
                """,
                (
                    student_id,
                    field_name,
                    str(current_value),
                    requested_value,
                    reason,
                    stamp,
                    stamp,
                ),
            )
            conn.commit()
        except sqlite3.IntegrityError:
            conn.rollback()
            return error_response(
                "A pending request for this field already exists.",
                409,
                "PENDING_REQUEST_EXISTS",
            )

        row = conn.execute(
            """
            SELECT er.*, s.name, s.roll_no
            FROM student_edit_requests er
            JOIN students s
              ON s.id = er.student_id
            WHERE er.id = ?
            """,
            (
                cursor.lastrowid,
            ),
        ).fetchone()

        return ok_response(
            {
                "message":
                    "Edit request submitted.",
                "request":
                    serialize_edit_request(row),
            },
            201,
        )


@app.route(
    "/api/edit-requests",
    methods=["GET"],
)
@admin_required
def api_admin_edit_requests():

    status = clean_string(
        request.args.get("status"),
        30,
    ).title()

    if status and status not in {
        "Pending",
        "Approved",
        "Rejected",
    }:
        return error_response(
            "Invalid request status.",
            400,
            "INVALID_REQUEST_STATUS",
        )

    query = """
        SELECT er.*, s.name, s.roll_no
        FROM student_edit_requests er
        JOIN students s
          ON s.id = er.student_id
        WHERE 1 = 1
    """
    params: list[Any] = []

    if status:
        query += """
            AND er.status = ?
        """
        params.append(status)

    query += """
        ORDER BY er.created_at DESC
    """

    with closing(connect()) as conn:
        rows = conn.execute(
            query,
            params,
        ).fetchall()

    return ok_response(
        {
            "requests": [
                serialize_edit_request(row)
                for row in rows
            ]
        }
    )


@app.route(
    "/api/edit-requests/<int:request_id>/review",
    methods=[
        "POST",
        "OPTIONS",
    ],
)
@admin_required
def api_review_edit_request(
    request_id: int,
):

    if request.method == "OPTIONS":
        return ok_response()

    admin = current_admin()
    payload = request_payload()
    decision = clean_string(
        payload.get("decision"),
        20,
    ).lower()
    note = clean_string(
        payload.get("note"),
        500,
    )

    if decision not in {
        "approve",
        "reject",
    }:
        return error_response(
            "Decision must be approve or reject.",
            400,
            "INVALID_REVIEW_DECISION",
        )

    allowed_columns = {
        "name": "name",
        "rollNo": "roll_no",
        "className": "class_name",
        "rfidUid": "rfid_uid",
    }

    with closing(connect()) as conn:

        conn.execute("BEGIN IMMEDIATE")

        row = conn.execute(
            """
            SELECT *
            FROM student_edit_requests
            WHERE id = ?
            LIMIT 1
            """,
            (
                request_id,
            ),
        ).fetchone()

        if not row:
            conn.rollback()
            return error_response(
                "Edit request not found.",
                404,
                "EDIT_REQUEST_NOT_FOUND",
            )

        if row["status"] != "Pending":
            conn.rollback()
            return error_response(
                "This edit request has already been reviewed.",
                409,
                "EDIT_REQUEST_ALREADY_REVIEWED",
            )

        stamp = iso_now()
        next_status = (
            "Approved"
            if decision == "approve"
            else "Rejected"
        )

        if decision == "approve":
            column = allowed_columns.get(
                row["field_name"]
            )
            if not column:
                conn.rollback()
                return error_response(
                    "Unsupported edit field.",
                    400,
                    "INVALID_EDIT_FIELD",
                )

            if row["field_name"] == "rfidUid":
                duplicate = conn.execute(
                    """
                    SELECT id
                    FROM students
                    WHERE lower(rfid_uid) = lower(?)
                      AND id != ?
                    LIMIT 1
                    """,
                    (
                        row["requested_value"],
                        row["student_id"],
                    ),
                ).fetchone()
                if duplicate:
                    conn.rollback()
                    return error_response(
                        "Requested RFID UID is already assigned to another student.",
                        409,
                        "DUPLICATE_RFID",
                    )

            if row["field_name"] == "rollNo":
                duplicate = conn.execute(
                    """
                    SELECT id
                    FROM students
                    WHERE lower(roll_no) = lower(?)
                      AND id != ?
                    LIMIT 1
                    """,
                    (
                        row["requested_value"],
                        row["student_id"],
                    ),
                ).fetchone()
                if duplicate:
                    conn.rollback()
                    return error_response(
                        "Requested roll number is already registered.",
                        409,
                        "DUPLICATE_ROLL",
                    )

            conn.execute(
                f"""
                UPDATE students
                SET {column} = ?
                WHERE id = ?
                """,
                (
                    row["requested_value"],
                    row["student_id"],
                ),
            )

            if row["field_name"] == "rfidUid":
                conn.execute(
                    """
                    UPDATE attendance_records
                    SET rfid_uid = ?
                    WHERE student_id = ?
                    """,
                    (
                        row["requested_value"],
                        row["student_id"],
                    ),
                )

        conn.execute(
            """
            UPDATE student_edit_requests
            SET
                status = ?,
                reviewer_admin_id = ?,
                review_note = ?,
                reviewed_at = ?,
                updated_at = ?
            WHERE id = ?
            """,
            (
                next_status,
                admin["id"],
                note,
                stamp,
                stamp,
                request_id,
            ),
        )

        reviewed = conn.execute(
            """
            SELECT er.*, s.name, s.roll_no
            FROM student_edit_requests er
            JOIN students s
              ON s.id = er.student_id
            WHERE er.id = ?
            """,
            (
                request_id,
            ),
        ).fetchone()

        conn.commit()

        return ok_response(
            {
                "message":
                    f"Edit request {next_status.lower()}.",
                "request":
                    serialize_edit_request(reviewed),
            }
        )


# ============================================================
# ATTENDANCE RECORDS
# ============================================================

@app.route(
    "/api/attendance/records",
    methods=["GET"],
)
@admin_required
def api_attendance_records():

    requested_date = request.args.get(
        "date"
    )

    start_value = request.args.get(
        "startDate",
        request.args.get(
            "start_date",
        ),
    )

    end_value = request.args.get(
        "endDate",
        request.args.get(
            "end_date",
        ),
    )

    selected_date, date_error = (
        parse_optional_date(
            requested_date
        )
    )

    if date_error:

        return error_response(
            date_error,
            400,
            "INVALID_DATE",
        )

    start_date, end_date, range_error = (
        parse_date_range(
            start_value,
            end_value,
            "custom",
        )
        if start_value or end_value
        else (
            None,
            None,
            None,
        )
    )

    if range_error:

        return error_response(
            range_error,
            400,
            "INVALID_DATE_RANGE",
        )

    status = clean_string(
        request.args.get(
            "status"
        ),
        30,
    ).title()

    if status and status not in {
        "Present",
        "Absent",
        "Late",
    }:

        return error_response(
            "Status must be Present, Absent, or Late.",
            400,
            "INVALID_STATUS",
        )

    search = clean_string(
        request.args.get(
            "search"
        ),
        100,
    ).lower()

    source = clean_string(
        request.args.get(
            "source"
        ),
        40,
    )

    if source and source not in {
        "RFID",
        "Manual",
        "System",
        "ESP32",
    }:
        return error_response(
            "Invalid attendance source.",
            400,
            "INVALID_SOURCE",
        )

    include_roster = (
        clean_string(
            request.args.get(
                "includeRoster",
                request.args.get(
                    "include_roster",
                    "1",
                ),
            ),
            8,
        )
        != "0"
    )

    if selected_date is None and not (start_date or end_date):
        selected_date = date.today().isoformat()

    if selected_date is None and (start_date or end_date):
        include_roster = False

    if include_roster:

        query = """
            SELECT
                ar.id AS record_id,
                s.id AS student_id,
                s.name,
                s.class_name,
                s.roll_no,
                s.rfid_uid,
                ar.attendance_date,
                ar.check_in_time,
                COALESCE(ar.status, 'Absent')
                    AS status,
                ar.source,
                ar.created_at,
                ar.updated_at
            FROM students s
            LEFT JOIN attendance_records ar
              ON ar.student_id = s.id
             AND ar.attendance_date = ?
            WHERE 1 = 1
        """

        params: list[Any] = [
            selected_date
        ]

        if status:

            query += """
                AND COALESCE(ar.status, 'Absent') = ?
            """

            params.append(
                status
            )

        if search:

            query += """
                AND (
                    lower(s.name)
                        LIKE ?
                    OR lower(s.roll_no)
                        LIKE ?
                    OR lower(s.rfid_uid)
                        LIKE ?
                    OR lower(s.class_name)
                        LIKE ?
                )
            """

            search_term = (
                f"%{search}%"
            )

            params.extend(
                [
                    search_term,
                    search_term,
                    search_term,
                    search_term,
                ]
            )

        if source:

            query += """
                AND COALESCE(ar.source, 'System') = ?
            """

            params.append(
                source
            )

        query += """
            ORDER BY
                CASE
                    WHEN s.roll_no GLOB '[0-9]*'
                    THEN CAST(s.roll_no AS INTEGER)
                    ELSE 999999
                END,
                s.name
        """

        with closing(connect()) as conn:

            rows = conn.execute(
                query,
                params,
            ).fetchall()

            return ok_response(
                {
                    "date":
                        selected_date,
                    "includeRoster":
                        True,
                    "records": [
                        serialize_attendance_roster(
                            row,
                            selected_date,
                        )
                        for row in rows
                    ],
                }
            )

    query = """
        SELECT
            ar.*,
            s.name,
            s.class_name,
            s.roll_no
        FROM attendance_records ar
        JOIN students s
          ON s.id = ar.student_id
        WHERE 1 = 1
    """

    params: list[Any] = []

    if selected_date:

        query += """
            AND ar.attendance_date = ?
        """

        params.append(
            selected_date
        )

    if start_date:

        query += """
            AND ar.attendance_date >= ?
        """

        params.append(
            start_date
        )

    if end_date:

        query += """
            AND ar.attendance_date <= ?
        """

        params.append(
            end_date
        )

    if status:

        query += """
            AND ar.status = ?
        """

        params.append(
            status
        )

    if search:

        query += """
            AND (
                lower(s.name)
                    LIKE ?
                OR lower(s.roll_no)
                    LIKE ?
                OR lower(s.rfid_uid)
                    LIKE ?
            )
        """

        search_term = (
            f"%{search}%"
        )

        params.extend(
            [
                search_term,
                search_term,
                search_term,
            ]
        )

    if source:

        query += """
            AND ar.source = ?
        """

        params.append(
            source
        )

    query += """
        ORDER BY
            ar.check_in_time DESC
    """

    with closing(connect()) as conn:

        rows = conn.execute(
            query,
            params,
        ).fetchall()

        return ok_response(
            {
                "date":
                    selected_date,
                "startDate":
                    start_date,
                "endDate":
                    end_date,

                "records": [
                    serialize_attendance(
                        row
                    )
                    for row in rows
                ],
            }
        )


# ============================================================
# MANUAL ATTENDANCE
# ============================================================

@app.route(
    "/api/attendance/manual",
    methods=[
        "POST",
        "OPTIONS",
    ],
)
@admin_required
def api_manual_attendance():

    if request.method == "OPTIONS":
        return ok_response()

    payload = request_payload()

    student_id = (
        payload.get(
            "studentId"
        )
        or payload.get(
            "student_id"
        )
    )

    if not student_id:

        return error_response(
            "Student is required.",
            400,
            "STUDENT_REQUIRED",
        )

    try:
        student_id = int(
            student_id
        )
    except (
        TypeError,
        ValueError,
    ):

        return error_response(
            "Invalid student ID.",
            400,
            "INVALID_STUDENT_ID",
        )

    status = clean_string(
        payload.get(
            "status"
        ),
        30,
    ).title()

    if status not in {
        "Present",
        "Absent",
        "Late",
    }:

        return error_response(
            "Status must be Present, Absent, or Late.",
            400,
            "INVALID_STATUS",
        )

    selected_date, date_error = (
        parse_date_strict(
            payload.get(
                "date"
            )
        )
    )

    if date_error:

        return error_response(
            date_error,
            400,
            "INVALID_DATE",
        )

    with closing(connect()) as conn:

        student = conn.execute(
            """
            SELECT *
            FROM students
            WHERE id = ?
            LIMIT 1
            """,
            (
                student_id,
            ),
        ).fetchone()

        if not student:

            return error_response(
                "Student not found.",
                404,
                "STUDENT_NOT_FOUND",
            )

        existing = conn.execute(
            """
            SELECT *
            FROM attendance_records
            WHERE
                student_id = ?
                AND attendance_date = ?
            LIMIT 1
            """,
            (
                student_id,
                selected_date,
            ),
        ).fetchone()

        stamp = iso_now()
        mark_time = local_time_string()
        previous_status = (
            existing["status"]
            if existing
            else None
        )

        if existing:

            if existing["status"] == status:

                updated = conn.execute(
                    """
                    SELECT
                        ar.*,
                        s.name,
                        s.class_name,
                        s.roll_no
                    FROM attendance_records ar
                    JOIN students s
                      ON s.id = ar.student_id
                    WHERE ar.id = ?
                    LIMIT 1
                    """,
                    (
                        existing["id"],
                    ),
                ).fetchone()

                conn.commit()

                return ok_response(
                    {
                        "message":
                            f"{student['name']} was already marked {status}.",

                        "alreadyMarked":
                            True,

                        "updated":
                            False,

                        "previousStatus":
                            previous_status,

                        "record":
                            serialize_attendance(
                                updated
                            ),

                        "dashboard":
                            dashboard_snapshot(
                                selected_date
                            ),
                    }
                )

            conn.execute(
                """
                UPDATE attendance_records
                SET
                    rfid_uid = ?,
                    check_in_time = ?,
                    status = ?,
                    source = 'Manual',
                    updated_at = ?
                WHERE id = ?
                """,
                (
                    student["rfid_uid"],
                    mark_time,
                    status,
                    stamp,
                    existing["id"],
                ),
            )
            changed = True

        else:

            try:
                conn.execute(
                    """
                    INSERT INTO attendance_records
                    (
                        student_id,
                        rfid_uid,
                        attendance_date,
                        check_in_time,
                        status,
                        source,
                        created_at,
                        updated_at
                    )
                    VALUES
                    (?, ?, ?, ?, ?, 'Manual',
                     ?, ?)
                    """,
                    (
                        student["id"],
                        student["rfid_uid"],
                        selected_date,
                        mark_time,
                        status,
                        stamp,
                        stamp,
                    ),
                )
            except sqlite3.IntegrityError:
                conn.rollback()

                return error_response(
                    "Attendance for this student and date already exists. Refresh and try again.",
                    409,
                    "ATTENDANCE_ALREADY_EXISTS",
                )

            changed = True

        if changed:
            conn.execute(
                """
                INSERT INTO scan_events
                (
                    student_id,
                    rfid_uid,
                    status,
                    device_id,
                    source_ip,
                    message,
                    created_at
                )
                VALUES
                (?, ?, ?, 'Manual-Control',
                 ?, ?, ?)
                """,
                (
                    student["id"],
                    student["rfid_uid"],
                    status.lower(),
                    request.remote_addr,
                    (
                        f"Manual {previous_status} to {status} update"
                        if previous_status
                        else f"Manual {status} mark"
                    ),
                    stamp,
                ),
            )

        conn.commit()

        updated = conn.execute(
            """
            SELECT
                ar.*,
                s.name,
                s.class_name,
                s.roll_no
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE
                ar.student_id = ?
                AND ar.attendance_date = ?
            LIMIT 1
            """,
            (
                student_id,
                selected_date,
            ),
        ).fetchone()

        return ok_response(
            {
                "message":
                    f"{student['name']} marked {status}.",

                "previousStatus":
                    previous_status,

                "alreadyMarked":
                    False,

                "updated":
                    previous_status is not None,

                "record":
                    serialize_attendance(
                        updated
                    ),

                "dashboard":
                    dashboard_snapshot(
                        selected_date
                    ),
            }
        )


# ============================================================
# RFID ATTENDANCE
# ============================================================

@app.route(
    "/api/attendance",
    methods=[
        "POST",
        "OPTIONS",
    ],
)
@device_required
def api_rfid_attendance():

    if request.method == "OPTIONS":
        return ok_response()

    payload = request_payload()

    raw_uid = (
        payload.get(
            "uid"
        )
        or payload.get(
            "rfid_uid"
        )
    )

    if raw_uid is None:

        return error_response(
            "Missing RFID UID.",
            400,
            "MISSING_UID",
        )

    uid = normalize_uid(
        raw_uid
    )

    device_id = clean_string(
        payload.get(
            "device_id",
            DEVICE_ID,
        ),
        80,
    ) or DEVICE_ID

    firmware = clean_string(
        payload.get(
            "firmware",
            DEFAULT_FIRMWARE,
        ),
        120,
    ) or DEFAULT_FIRMWARE

    if not is_valid_uid(uid):

        with closing(connect()) as conn:

            update_device_seen(
                conn,
                device_id,
                firmware,
            )

            conn.execute(
                """
                INSERT INTO scan_events
                (
                    student_id,
                    rfid_uid,
                    status,
                    device_id,
                    source_ip,
                    message,
                    created_at
                )
                VALUES
                (
                    NULL,
                    ?,
                    'rejected',
                    ?,
                    ?,
                    'Invalid RFID UID format',
                    ?
                )
                """,
                (
                    uid or "INVALID",
                    device_id,
                    request.remote_addr,
                    iso_now(),
                ),
            )

            conn.commit()

        return error_response(
            "Invalid RFID UID format.",
            422,
            "INVALID_UID",
        )

    with closing(connect()) as conn:

        # Update device heartbeat and scan count
        # atomically with the scan operation.
        update_device_seen(
            conn,
            device_id,
            firmware,
            uid,
            increment_scan=True,
        )

        student = conn.execute(
            """
            SELECT *
            FROM students
            WHERE lower(rfid_uid)
                  = lower(?)
            LIMIT 1
            """,
            (
                uid,
            ),
        ).fetchone()

        stamp = iso_now()

        # ----------------------------------------------------
        # UNKNOWN CARD
        # ----------------------------------------------------

        if not student:

            conn.execute(
                """
                INSERT INTO scan_events
                (
                    student_id,
                    rfid_uid,
                    status,
                    device_id,
                    source_ip,
                    message,
                    created_at
                )
                VALUES
                (
                    NULL,
                    ?,
                    'rejected',
                    ?,
                    ?,
                    'Unknown RFID card',
                    ?
                )
                """,
                (
                    uid,
                    device_id,
                    request.remote_addr,
                    stamp,
                ),
            )

            conn.commit()

            return jsonify(
                {
                    "ok": True,
                    "matched": False,
                    "duplicate": False,
                    "uid": uid,
                    "message":
                        "Unknown RFID tag.",
                    "device":
                        device_status_payload(
                            conn
                        ),
                }
            )

        # ----------------------------------------------------
        # CHECK TODAY'S ATTENDANCE
        # ----------------------------------------------------

        today = date.today().isoformat()

        existing = conn.execute(
            """
            SELECT
                ar.*,
                s.name,
                s.class_name,
                s.roll_no
            FROM attendance_records ar
            JOIN students s
              ON s.id = ar.student_id
            WHERE
                ar.student_id = ?
                AND ar.attendance_date = ?
            LIMIT 1
            """,
            (
                student["id"],
                today,
            ),
        ).fetchone()

        # ----------------------------------------------------
        # DUPLICATE PRESENT
        # ----------------------------------------------------

        if (
            existing
            and existing["status"]
            == "Present"
        ):

            conn.execute(
                """
                INSERT INTO scan_events
                (
                    student_id,
                    rfid_uid,
                    status,
                    device_id,
                    source_ip,
                    message,
                    created_at
                )
                VALUES
                (
                    ?,
                    ?,
                    'duplicate',
                    ?,
                    ?,
                    'Already present today',
                    ?
                )
                """,
                (
                    student["id"],
                    uid,
                    device_id,
                    request.remote_addr,
                    stamp,
                ),
            )

            conn.commit()

            return jsonify(
                {
                    "ok": True,
                    "matched": True,
                    "duplicate": True,
                    "message":
                        f"{student['name']} is already present.",
                    "student":
                        serialize_student(
                            student
                        ),
                    "attendance":
                        serialize_attendance(
                            existing
                        ),
                    "device":
                        device_status_payload(
                            conn
                        ),
                }
            )

        # ----------------------------------------------------
        # NEW OR UPDATE ATTENDANCE
        # ----------------------------------------------------

        record, was_existing = (
            mark_student_present(
                conn,
                student,
                "RFID",
            )
        )

        conn.execute(
            """
            INSERT INTO scan_events
            (
                student_id,
                rfid_uid,
                status,
                device_id,
                source_ip,
                message,
                created_at
            )
            VALUES
            (
                ?,
                ?,
                'accepted',
                ?,
                ?,
                ?,
                ?
            )
            """,
            (
                student["id"],
                uid,
                device_id,
                request.remote_addr,
                (
                    "Attendance updated"
                    if was_existing
                    else "Attendance recorded"
                ),
                stamp,
            ),
        )

        conn.commit()

        return jsonify(
            {
                "ok": True,

                "matched": True,

                "duplicate": False,

                "updated":
                    was_existing,

                "message": (
                    f"{student['name']} "
                    "is present."
                ),

                "student":
                    serialize_student(
                        student
                    ),

                "attendance":
                    serialize_attendance(
                        record
                    ),

                "device":
                    device_status_payload(
                        conn
                    ),
            }
        )


# ============================================================
# LATEST SCAN
# ============================================================

@app.route(
    "/api/scans/latest",
    methods=["GET"],
)
@admin_required
def api_latest_scan():

    with closing(connect()) as conn:

        row = conn.execute(
            """
            SELECT
                se.*,
                s.name,
                s.roll_no,
                s.class_name
            FROM scan_events se
            LEFT JOIN students s
              ON s.id = se.student_id
            ORDER BY
                se.created_at DESC
            LIMIT 1
            """
        ).fetchone()

        if not row:

            return ok_response(
                {
                    "scan":
                        None,
                }
            )

        return ok_response(
            {
                "scan": {
                    "id":
                        row["id"],
                    "studentName":
                        row["name"]
                        or "Unknown RFID Tag",
                    "rollNo":
                        row["roll_no"],
                    "className":
                        row["class_name"],
                    "rfidUid":
                        row["rfid_uid"],
                    "status":
                        row["status"],
                    "message":
                        row["message"],
                    "deviceId":
                        row["device_id"],
                    "createdAt":
                        row["created_at"],
                }
            }
        )


# ============================================================
# DEVICE STATUS
# ============================================================

@app.route(
    "/api/device/status",
    methods=["GET"],
)
def api_device_status():

    with closing(connect()) as conn:

        return jsonify(
            device_status_payload(
                conn
            )
        )


# ============================================================
# DEVICE INTEGRATION INFORMATION
# ============================================================

@app.route(
    "/api/device/integration",
    methods=["GET"],
)
def api_device_integration():

    base_url = (
        request.host_url
        .rstrip("/")
    )

    return ok_response(
        {
            "deviceId":
                DEVICE_ID,

            "timeoutSeconds":
                DEVICE_TIMEOUT_SECONDS,

            "routes": {

                "attendance": {
                    "method":
                        "POST",

                    "url":
                        (
                            f"{base_url}"
                            "/api/attendance"
                        ),

                    "json": {
                        "uid":
                            "04:A7:2C:91",
                        "device_id":
                            DEVICE_ID,
                        "firmware":
                            DEFAULT_FIRMWARE,
                    },
                },

                "heartbeat": {
                    "method":
                        "POST",

                    "url":
                        (
                            f"{base_url}"
                            "/api/device/heartbeat"
                        ),

                    "json": {
                        "device_id":
                            DEVICE_ID,
                        "firmware":
                            DEFAULT_FIRMWARE,
                    },
                },
            },
        }
    )


# ============================================================
# DEVICE HEARTBEAT
# ============================================================

@app.route(
    "/api/device/heartbeat",
    methods=[
        "POST",
        "OPTIONS",
    ],
)
@device_required
def api_device_heartbeat():

    if request.method == "OPTIONS":
        return ok_response()

    payload = request_payload()

    device_id = clean_string(
        payload.get(
            "device_id",
            DEVICE_ID,
        ),
        80,
    ) or DEVICE_ID

    firmware = clean_string(
        payload.get(
            "firmware",
            DEFAULT_FIRMWARE,
        ),
        120,
    ) or DEFAULT_FIRMWARE

    uid = None

    if payload.get("uid"):

        uid = normalize_uid(
            payload.get("uid")
        )

        if not is_valid_uid(uid):

            return error_response(
                "Invalid heartbeat UID.",
                422,
                "INVALID_UID",
            )

    with closing(connect()) as conn:

        update_device_seen(
            conn,
            device_id,
            firmware,
            uid,
            increment_scan=False,
        )

        conn.commit()

        return ok_response(
            {
                "device":
                    device_status_payload(
                        conn
                    )
            }
        )


# ============================================================
# ANALYTICS
# ============================================================

@app.route(
    "/api/analytics",
    methods=["GET"],
)
@admin_required
def api_analytics():

    start_date, end_date, range_error = (
        parse_date_range(
            request.args.get(
                "startDate",
                request.args.get(
                    "start_date",
                ),
            ),
            request.args.get(
                "endDate",
                request.args.get(
                    "end_date",
                ),
            ),
            request.args.get(
                "preset",
                "30d",
            ),
        )
    )

    if range_error:

        return error_response(
            range_error,
            400,
            "INVALID_DATE_RANGE",
        )

    student_id = request.args.get(
        "studentId",
        request.args.get(
            "student_id",
        ),
    )

    parsed_student_id = None

    if student_id:

        try:
            parsed_student_id = int(
                student_id
            )
        except (
            TypeError,
            ValueError,
        ):

            return error_response(
                "Invalid student ID.",
                400,
                "INVALID_STUDENT_ID",
            )

    try:
        return jsonify(
            analytics_snapshot(
                start_date,
                end_date,
                parsed_student_id,
            )
        )
    except ValueError as error:
        return error_response(
            str(error),
            404,
            "STUDENT_NOT_FOUND",
        )


# ============================================================
# SYSTEM CHECKS
# ============================================================

@app.route(
    "/api/system/checks",
    methods=["GET"],
)
def api_system_checks():

    checks = []

    database_ok = False

    student_count = 0

    attendance_count = 0

    scan_count = 0

    try:

        with closing(connect()) as conn:

            integrity = conn.execute(
                "PRAGMA integrity_check"
            ).fetchone()[0]

            database_ok = (
                integrity == "ok"
            )

            student_count = conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM students
                """
            ).fetchone()["count"]

            attendance_count = conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM attendance_records
                """
            ).fetchone()["count"]

            scan_count = conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM scan_events
                """
            ).fetchone()["count"]

            device = device_status_payload(
                conn
            )

        checks.append(
            {
                "name":
                    "API",
                "ok":
                    True,
                "detail":
                    "Flask API responding",
            }
        )

        checks.append(
            {
                "name":
                    "SQLite",
                "ok":
                    database_ok,
                "detail":
                    (
                        "Database integrity OK"
                        if database_ok
                        else
                        "Database integrity check failed"
                    ),
            }
        )

        checks.append(
            {
                "name":
                    "Students",
                "ok":
                    student_count > 0,
                "detail":
                    f"{student_count} registered students",
            }
        )

        checks.append(
            {
                "name":
                    "Attendance",
                "ok":
                    True,
                "detail":
                    (
                        f"{attendance_count} attendance records"
                    ),
            }
        )

        checks.append(
            {
                "name":
                    "ESP32",
                "ok":
                    bool(
                        device["online"]
                    ),
                "detail":
                    device["label"],
            }
        )

        return ok_response(
            {
                "healthy":
                    all(
                        item["ok"]
                        for item in checks
                    ),

                "checks":
                    checks,

                "counts": {
                    "students":
                        student_count,
                    "attendanceRecords":
                        attendance_count,
                    "scanEvents":
                        scan_count,
                },

                "device":
                    device,
            }
        )

    except Exception:

        logger.exception(
            "System check failed"
        )

        return error_response(
            "System diagnostics failed.",
            503,
            "SYSTEM_CHECK_FAILED",
        )


# ============================================================
# DEMO SCAN
# ============================================================

@app.route(
    "/api/demo/scan",
    methods=["POST"],
)
@admin_required
def api_demo_scan():

    with closing(connect()) as conn:

        today = date.today().isoformat()

        student = conn.execute(
            """
            SELECT s.*
            FROM students s
            LEFT JOIN attendance_records ar
              ON ar.student_id = s.id
             AND ar.attendance_date = ?
            WHERE ar.id IS NULL
            ORDER BY
                CASE
                    WHEN s.roll_no
                         GLOB '[0-9]*'
                    THEN CAST(
                        s.roll_no AS INTEGER
                    )
                    ELSE 999999
                END
            LIMIT 1
            """,
            (
                today,
            ),
        ).fetchone()

        if not student:

            student = conn.execute(
                """
                SELECT *
                FROM students
                ORDER BY RANDOM()
                LIMIT 1
                """
            ).fetchone()

    if not student:

        return error_response(
            "No students are registered.",
            404,
            "NO_STUDENTS",
        )

    # Perform the same logical operation as
    # a real RFID scan without duplicating
    # attendance logic.

    with app.test_request_context(
        "/api/attendance",
        method="POST",
        json={
            "uid":
                student["rfid_uid"],
            "device_id":
                DEVICE_ID,
            "firmware":
                "demo-mode",
        },
    ):

        return api_rfid_attendance()


# ============================================================
# CSV REPORT
# ============================================================

@app.route(
    "/api/reports/csv",
    methods=["GET"],
)
@admin_required
def api_reports_csv():

    selected_date = request.args.get(
        "date"
    )

    month = request.args.get(
        "month"
    )

    student_id = request.args.get(
        "student_id",
        request.args.get(
            "studentId",
        ),
    )

    start_value = request.args.get(
        "startDate",
        request.args.get(
            "start_date",
        ),
    )

    end_value = request.args.get(
        "endDate",
        request.args.get(
            "end_date",
        ),
    )

    status = clean_string(
        request.args.get(
            "status",
        ),
        30,
    ).title()

    search = clean_string(
        request.args.get(
            "search",
        ),
        100,
    ).lower()

    source = clean_string(
        request.args.get(
            "source",
        ),
        40,
    )

    if source and source not in {
        "RFID",
        "Manual",
        "System",
        "ESP32",
    }:
        return error_response(
            "Invalid attendance source.",
            400,
            "INVALID_SOURCE",
        )

    if status and status not in {
        "Present",
        "Absent",
        "Late",
    }:

        return error_response(
            "Status must be Present, Absent, or Late.",
            400,
            "INVALID_STATUS",
        )

    parsed_student_id = None

    if student_id:

        try:
            parsed_student_id = int(
                student_id
            )
        except (
            TypeError,
            ValueError,
        ):

            return error_response(
                "Invalid student ID.",
                400,
                "INVALID_STUDENT_ID",
            )

    start_date = None
    end_date = None

    if start_value or end_value:

        start_date, end_date, range_error = (
            parse_date_range(
                start_value,
                end_value,
                "custom",
            )
        )

        if range_error:

            return error_response(
                range_error,
                400,
                "INVALID_DATE_RANGE",
            )

    params: list[Any] = []

    if selected_date:

        parsed_date, date_error = (
            parse_date_strict(
                selected_date
            )
        )

        if date_error:

            return error_response(
                date_error,
                400,
                "INVALID_DATE",
            )

        query = """
            SELECT
                s.id AS student_id,
                s.roll_no,
                s.name,
                s.class_name,
                s.rfid_uid,
                COALESCE(
                    ar.attendance_date,
                    ?
                ) AS attendance_date,
                ar.check_in_time,
                COALESCE(
                    ar.status,
                    'Absent'
                ) AS status,
                COALESCE(
                    ar.source,
                    'System'
                ) AS source
            FROM students s
            LEFT JOIN attendance_records ar
              ON ar.student_id = s.id
             AND ar.attendance_date = ?
            WHERE 1 = 1
        """

        params.extend(
            [
                parsed_date,
                parsed_date,
            ]
        )

        report_name = (
            f"date-{parsed_date}"
        )

    elif month:

        month = clean_string(
            month,
            7,
        )[:7]

        if not re.fullmatch(
            r"\d{4}-\d{2}",
            month,
        ):

            return error_response(
                "Invalid month. Expected YYYY-MM.",
                400,
                "INVALID_MONTH",
            )

        query = """
            SELECT
                s.id AS student_id,
                s.roll_no,
                s.name,
                s.class_name,
                s.rfid_uid,
                ar.attendance_date,
                ar.check_in_time,
                ar.status AS status,
                ar.source AS source
            FROM students s
            JOIN attendance_records ar
              ON ar.student_id = s.id
             AND substr(
                    ar.attendance_date,
                    1,
                    7
                 ) = ?
            WHERE 1 = 1
        """

        params.append(
            month
        )

        report_name = (
            f"month-{month}"
        )

    elif start_date or end_date:

        query = """
            SELECT
                s.id AS student_id,
                s.roll_no,
                s.name,
                s.class_name,
                s.rfid_uid,
                ar.attendance_date,
                ar.check_in_time,
                ar.status AS status,
                ar.source AS source
            FROM attendance_records ar
            JOIN students s
              ON ar.student_id = s.id
            WHERE 1 = 1
        """

        if start_date:
            query += """
                AND ar.attendance_date >= ?
            """

            params.append(
                start_date
            )

        if end_date:
            query += """
                AND ar.attendance_date <= ?
            """

            params.append(
                end_date
            )

        report_name = (
            "range-"
            f"{start_date or 'start'}-"
            f"{end_date or 'end'}"
        )

    else:

        query = """
            SELECT
                s.id AS student_id,
                s.roll_no,
                s.name,
                s.class_name,
                s.rfid_uid,
                ar.attendance_date,
                ar.check_in_time,
                ar.status AS status,
                ar.source AS source
            FROM students s
            JOIN attendance_records ar
              ON ar.student_id = s.id
            WHERE 1 = 1
        """

        report_name = "history"

    if parsed_student_id:

        query += """
            AND s.id = ?
        """

        params.append(
            parsed_student_id
        )

    if status:

        query += """
            AND COALESCE(ar.status, 'Absent') = ?
        """

        params.append(
            status
        )

    if search:

        query += """
            AND (
                lower(s.name) LIKE ?
                OR lower(s.roll_no) LIKE ?
                OR lower(s.rfid_uid) LIKE ?
                OR lower(s.class_name) LIKE ?
            )
        """

        search_term = f"%{search}%"

        params.extend(
            [
                search_term,
                search_term,
                search_term,
                search_term,
            ]
        )

    if source:

        query += """
            AND COALESCE(ar.source, 'System') = ?
        """

        params.append(
            source
        )

    query += """
        ORDER BY
            ar.attendance_date DESC,
            CASE
                WHEN s.roll_no
                     GLOB '[0-9]*'
                THEN CAST(
                    s.roll_no AS INTEGER
                )
                ELSE 999999
            END
    """

    with closing(connect()) as conn:

        rows = conn.execute(
            query,
            params,
        ).fetchall()

    output = io.StringIO()

    writer = csv.writer(
        output
    )

    writer.writerow(
        [
            "Student ID",
            "Roll No",
            "Student Name",
            "Class",
            "RFID UID",
            "Date",
            "Check-in Time",
            "Status",
            "Source",
        ]
    )

    for row in rows:

        writer.writerow(
            [
                safe_csv_cell(
                    row["student_id"]
                ),
                safe_csv_cell(
                    row["roll_no"]
                ),
                safe_csv_cell(
                    row["name"]
                ),
                safe_csv_cell(
                    row["class_name"]
                ),
                safe_csv_cell(
                    row["rfid_uid"]
                ),
                safe_csv_cell(
                    row["attendance_date"]
                    or ""
                ),
                safe_csv_cell(
                    row["check_in_time"]
                    or ""
                ),
                safe_csv_cell(
                    row["status"]
                ),
                safe_csv_cell(
                    row["source"]
                ),
            ]
        )

    if parsed_student_id:
        report_name = (
            f"student-{parsed_student_id}-"
            f"{report_name}"
        )

    if status:
        report_name = (
            f"{report_name}-{status.lower()}"
        )

    if source:
        report_name = (
            f"{report_name}-{safe_filename_part(source, 'source')}"
        )

    response = Response(
        output.getvalue(),
        mimetype="text/csv",
    )

    response.headers[
        "Content-Disposition"
    ] = (
        "attachment; "
        "filename="
        f"smart-rfid-attendance-"
        f"{safe_filename_part(report_name)}.csv"
    )

    return response


# ============================================================
# SPA / STATIC FALLBACK
# ============================================================

@app.route(
    "/<path:path>"
)
def spa_fallback(
    path: str,
):

    candidate = (
        ROOT
        / "static"
        / path
    )

    if (
        candidate.exists()
        and candidate.is_file()
    ):

        return send_from_directory(
            app.static_folder,
            path,
        )

    return send_from_directory(
        app.static_folder,
        "index.html",
    )


# ============================================================
# DATABASE INITIALIZATION
# ============================================================

init_db()


# ============================================================
# START SERVER
# ============================================================

def main():

    host = os.environ.get(
        "SMART_RFID_HOST",
        DEFAULT_HOST,
    )

    try:

        port = int(
            os.environ.get(
                "SMART_RFID_PORT",
                DEFAULT_PORT,
            )
        )

    except ValueError:

        port = DEFAULT_PORT

    print()
    print("=" * 64)
    print("SMART RFID ADMIN")
    print("SMART CAMPUS COMMAND CENTER")
    print("=" * 64)

    print(
        f"Version: {APP_VERSION}"
    )

    print(
        f"Database: {DB_PATH}"
    )

    print(
        f"Local dashboard:"
        f" http://127.0.0.1:{port}"
    )

    print(
        f"API health:"
        f" http://127.0.0.1:{port}"
        f"/api/health"
    )

    print(
        f"ESP32 attendance:"
        f" /api/attendance"
    )

    print(
        f"ESP32 heartbeat:"
        f" /api/device/heartbeat"
    )

    print(
        "Authentication:"
        " browser session cookies"
    )

    print("=" * 64)
    print()

    app.run(
        host=host,
        port=port,
        debug=False,
        threaded=True,
    )


if __name__ == "__main__":
    main()
