
import os
import smtplib
from email.message import EmailMessage
from pathlib import Path


def load_local_env() -> None:
    env_path = Path(__file__).resolve().parent / ".env"

    if not env_path.exists():
        return

    for line in env_path.read_text().splitlines():
        line = line.strip()

        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


def require_env(name: str) -> str:
    value = os.environ.get(name, "").strip()

    if not value:
        raise RuntimeError(f"{name} is required.")

    return value


load_local_env()

EMAIL_ADDRESS = require_env("EMAIL_ADDRESS")
EMAIL_APP_PASSWORD = require_env("EMAIL_APP_PASSWORD")
RECIPIENT_EMAIL = require_env("RECIPIENT_EMAIL")

msg = EmailMessage()
msg["Subject"] = os.environ.get("EMAIL_SUBJECT", "Ayaan")
msg["From"] = EMAIL_ADDRESS
msg["To"] = RECIPIENT_EMAIL
msg.set_content(os.environ.get("EMAIL_BODY", "Hi from Ayaan"))

try:
    print("Connecting to Gmail...")

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
        print("Connected.")

        smtp.login(EMAIL_ADDRESS, EMAIL_APP_PASSWORD)
        print("Login successful.")

        smtp.send_message(msg)
        print("Email sent successfully!")

except smtplib.SMTPAuthenticationError:
    print("Gmail login failed. Check your email and app password.")

except smtplib.SMTPException as e:
    print(f"Gmail SMTP error: {e}")

except Exception as e:
    print(f"Error: {e}")
