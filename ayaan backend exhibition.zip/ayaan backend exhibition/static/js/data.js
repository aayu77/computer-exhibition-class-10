export const workflowSteps = [
  [
    "01",
    "Card Tap",
    "Student taps an RFID card on the RC522 scanner.",
  ],

  [
    "02",
    "UID Capture",
    "The RC522 reads the card's unique identifier using contactless radio-frequency communication.",
  ],

  [
    "03",
    "ESP32 Processing",
    "The ESP32 receives the UID, validates the scan format, and prepares a compact JSON payload.",
  ],

  [
    "04",
    "Wi-Fi API Call",
    "The ESP32 sends the attendance event to the Flask REST API over the local Wi-Fi network.",
  ],

  [
    "05",
    "Backend Validation",
    "Flask checks the UID against registered students, records the timestamp, and safely handles unknown cards.",
  ],

  [
    "06",
    "SQLite Storage",
    "Verified attendance events are stored in a structured local SQLite database.",
  ],

  [
    "07",
    "Live Dashboard",
    "The dashboard refreshes attendance counters, recent scans, student data, and device status.",
  ],

  [
    "08",
    "Instant Reports",
    "Attendance summaries and CSV reports become available immediately for review or export.",
  ],
];

export const featureCards = [
  [
    "Contactless Attendance",
    "Students mark attendance instantly by presenting an RFID card to the RC522 reader.",
    "tap",
  ],

  [
    "Real-Time Dashboard",
    "Attendance counters, recent scans, analytics, and device information update automatically.",
    "pulse",
  ],

  [
    "ESP32 Wi-Fi Communication",
    "The ESP32 communicates wirelessly with the Flask backend using structured JSON requests.",
    "wifi",
  ],

  [
    "REST API Integration",
    "Dedicated API endpoints connect the RFID hardware with the web application and database.",
    "api",
  ],

  [
    "SQLite Database Storage",
    "Student records, attendance events, scans, and system data are organized in a lightweight local database.",
    "db",
  ],

  [
    "CSV Report Export",
    "Teachers and judges can generate clean attendance reports for analysis and record keeping.",
    "csv",
  ],

  [
    "Mobile Responsive UI",
    "The interface adapts across phones, tablets, laptops, and large exhibition displays.",
    "mobile",
  ],

  [
    "Device Monitoring",
    "Live indicators show whether the connected ESP32 RFID device is currently online or offline.",
    "device",
  ],

  [
    "Attendance Analytics",
    "Attendance percentages and daily trends make student participation easier to understand.",
    "chart",
  ],

  [
    "Automated Workflow",
    "The system replaces repetitive manual attendance steps with a connected IoT workflow.",
    "automation",
  ],
];

export const explainerCards = [
  [
    "What is RFID?",
    "RFID uses radio waves to identify compatible tags and cards without physical contact. The RC522 reads the card's unique identifier when it is brought within scanning range.",
  ],

  [
    "How ESP32 Works",
    "The ESP32 acts as the hardware bridge. It receives the RFID data from the RC522, connects to Wi-Fi, and sends attendance events to the backend API.",
  ],

  [
    "How APIs Connect Hardware",
    "The REST API provides a defined communication layer between the ESP32 and the software system. Each scan is transmitted as structured data that the backend can validate and process.",
  ],

  [
    "Why Automation Matters",
    "Automated attendance reduces repetitive manual work, speeds up recording, minimizes common entry mistakes, and gives teachers immediate visibility into attendance activity.",
  ],

  [
    "What We Learned",
    "The project combines RFID, embedded systems, Wi-Fi networking, REST APIs, database design, frontend development, data reporting, and collaborative software engineering.",
  ],
];

export const learningBlocks = [
  "RFID technology",
  "RC522 integration",
  "ESP32 networking",
  "REST API design",
  "JSON communication",
  "SQLite data modeling",
  "Frontend dashboards",
  "Real-time polling",
  "CSV reporting",
  "IoT automation",
  "Hardware-software integration",
  "Team collaboration",
];

export const team = [
  {
    name: "Ayaan",
    role: "Co-Leader and Lead developer. API, Python/Flask, HTML, CSS, JavaScript",
    badge: "",
    lead: true,
  },

  {
    name: "Ayush",
    role: "Awareness program Developer, Spokesperson.",
    badge: "",
    lead: false,
  },

  {
    name: "Vedant",
    role: "Leader & Co-Developer, ESP 32 model",
    badge: "",
    lead: true,
  },

  {
    name: "Arshal Tudu",
    role: "Chart Paper & Spokesperson",
    badge: "",
    lead: false,
  },

  {
    name: "Arnab Mumu",
    role: "Chart Paper and Awareness program.",
    badge: "",
    lead: false,
  },
];
