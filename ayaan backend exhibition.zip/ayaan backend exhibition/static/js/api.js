const API_CONFIG = {
  timeout: 8000,
  retryAttempts: 2,
  retryDelay: 350,
  credentials: "same-origin",
};

const JSON_HEADERS = {
  Accept: "application/json",
  "Content-Type": "application/json",
};

class ApiError extends Error {
  constructor(message, options = {}) {
    super(message);

    this.name = "ApiError";
    this.status = options.status ?? 0;
    this.code = options.code ?? "API_ERROR";
    this.detail = options.detail ?? null;
    this.requestId = options.requestId ?? null;
    this.retryable = options.retryable ?? false;
  }
}

function sleep(ms) {
  return new Promise((resolve) => {
    window.setTimeout(resolve, ms);
  });
}

function isRetryableMethod(method) {
  return ["GET", "HEAD", "OPTIONS"].includes(method);
}

function isRetryableStatus(status) {
  return (
    status === 408 ||
    status === 425 ||
    status === 429 ||
    status >= 500
  );
}

function createRequestId() {
  if (window.crypto?.randomUUID) {
    return window.crypto.randomUUID();
  }

  return `${Date.now()}-${Math.random()
    .toString(16)
    .slice(2)}`;
}

async function parseResponse(response) {
  const contentType =
    response.headers.get("content-type") || "";

  if (contentType.includes("application/json")) {
    try {
      return await response.json();
    } catch {
      return {};
    }
  }

  const text = await response.text();

  return text ? { error: text } : {};
}

async function request(path, options = {}) {
  const {
    timeout = API_CONFIG.timeout,
    retries = API_CONFIG.retryAttempts,
    ...fetchOptions
  } = options;

  const method = (
    fetchOptions.method || "GET"
  ).toUpperCase();

  const requestId = createRequestId();

  let attempt = 0;

  while (true) {
    const controller = new AbortController();

    const timer = window.setTimeout(() => {
      controller.abort();
    }, timeout);

    try {
      const headers = {
        Accept: "application/json",
        ...(fetchOptions.body
          ? JSON_HEADERS
          : {}),
        ...(fetchOptions.headers || {}),
        "X-Request-ID": requestId,
      };

      const response = await fetch(path, {
        ...fetchOptions,
        method,
        credentials: API_CONFIG.credentials,
        headers,
        signal: controller.signal,
      });

      const detail = await parseResponse(response);

      if (response.ok) {
        return detail;
      }

      const serverRequestId =
        response.headers.get("X-Request-ID") ||
        requestId;

      const message =
        detail?.error ||
        detail?.message ||
        getStatusMessage(response.status);

      const retryable =
        isRetryableStatus(response.status) &&
        isRetryableMethod(method) &&
        attempt < retries;

      if (retryable) {
        attempt += 1;

        await sleep(
          API_CONFIG.retryDelay * attempt,
        );

        continue;
      }

      throw new ApiError(message, {
        status: response.status,
        code: getErrorCode(response.status),
        detail,
        requestId: serverRequestId,
        retryable:
          isRetryableStatus(response.status),
      });
    } catch (error) {
      if (error instanceof ApiError) {
        throw error;
      }

      const aborted =
        error?.name === "AbortError";

      const retryable =
        isRetryableMethod(method) &&
        attempt < retries;

      if (retryable) {
        attempt += 1;

        await sleep(
          API_CONFIG.retryDelay * attempt,
        );

        continue;
      }

      throw new ApiError(
        aborted
          ? "The API request timed out."
          : "The API is not reachable.",
        {
          code: aborted
            ? "TIMEOUT"
            : "NETWORK_ERROR",
          retryable: true,
          requestId,
        },
      );
    } finally {
      window.clearTimeout(timer);
    }
  }
}

function getStatusMessage(status) {
  switch (status) {
    case 400:
      return "The request was invalid.";

    case 401:
      return "Authentication required.";

    case 403:
      return "You do not have permission to perform this action.";

    case 404:
      return "The requested API resource was not found.";

    case 409:
      return "The request conflicts with existing data.";

    case 422:
      return "The submitted data could not be processed.";

    case 429:
      return "Too many requests. Please try again shortly.";

    case 500:
      return "The server encountered an internal error.";

    case 502:
      return "The API gateway returned an invalid response.";

    case 503:
      return "The API service is temporarily unavailable.";

    case 504:
      return "The API server timed out.";

    default:
      return `Request failed with status ${status}.`;
  }
}

function getErrorCode(status) {
  switch (status) {
    case 400:
      return "BAD_REQUEST";

    case 401:
      return "UNAUTHORIZED";

    case 403:
      return "FORBIDDEN";

    case 404:
      return "NOT_FOUND";

    case 409:
      return "CONFLICT";

    case 422:
      return "VALIDATION_ERROR";

    case 429:
      return "RATE_LIMITED";

    case 500:
      return "SERVER_ERROR";

    case 503:
      return "SERVICE_UNAVAILABLE";

    default:
      return "HTTP_ERROR";
  }
}

function buildQuery(params = {}) {
  const search = new URLSearchParams();

  Object.entries(params).forEach(
    ([key, value]) => {
      if (
        value !== undefined &&
        value !== null &&
        value !== ""
      ) {
        search.set(key, String(value));
      }
    },
  );

  const query = search.toString();

  return query ? `?${query}` : "";
}

export const Api = {
  /* =======================================================
     AUTHENTICATION
  ======================================================= */

  session() {
    return request("/api/auth/session");
  },

  login(credentials) {
    return request("/api/auth/login", {
      method: "POST",
      body: JSON.stringify(credentials),
      retries: 0,
    });
  },

  signup(credentials) {
    return request("/api/auth/signup", {
      method: "POST",
      body: JSON.stringify(credentials),
      retries: 0,
    });
  },

  logout() {
    return request("/api/auth/logout", {
      method: "POST",
      body: JSON.stringify({}),
      retries: 0,
    });
  },

  /* =======================================================
     DASHBOARD
  ======================================================= */

  dashboard(date) {
    return request(
      `/api/dashboard${buildQuery({ date })}`,
    );
  },

  /* =======================================================
     DEVICE
  ======================================================= */

  deviceStatus() {
    return request("/api/device/status");
  },

  heartbeat(payload = {}) {
    return request("/api/device/heartbeat", {
      method: "POST",
      body: JSON.stringify({
        device_id:
          payload.device_id ||
          "ESP32-RFID-01",

        firmware:
          payload.firmware ||
          "dashboard",

        ...payload,
      }),
      retries: 0,
    });
  },

  deviceIntegration() {
    return request("/api/device/integration");
  },

  /* =======================================================
     SYSTEM
  ======================================================= */

  health() {
    return request("/api/health");
  },

  systemChecks() {
    return request("/api/system/checks");
  },

  /* =======================================================
     STUDENTS
  ======================================================= */

  students(params = {}) {
    return request(
      `/api/students${buildQuery(params)}`,
    );
  },

  student(studentId, params = {}) {
    if (!studentId) {
      throw new ApiError(
        "A student ID is required.",
        {
          code: "INVALID_STUDENT_ID",
        },
      );
    }

    return request(
      `/api/students/${encodeURIComponent(
        studentId,
      )}${buildQuery(params)}`,
    );
  },

  addStudent(student) {
    return request("/api/students", {
      method: "POST",
      body: JSON.stringify(student),
      retries: 0,
    });
  },

  updateStudent(studentId, student) {
    if (!studentId) {
      throw new ApiError(
        "A student ID is required.",
        {
          code: "INVALID_STUDENT_ID",
        },
      );
    }

    return request(
      `/api/students/${encodeURIComponent(
        studentId,
      )}`,
      {
        method: "PATCH",
        body: JSON.stringify(student),
        retries: 0,
      },
    );
  },

  deleteStudent(studentId) {
    if (!studentId) {
      throw new ApiError(
        "A student ID is required.",
        {
          code: "INVALID_STUDENT_ID",
        },
      );
    }

    return request(
      `/api/students/${encodeURIComponent(
        studentId,
      )}`,
      {
        method: "DELETE",
        retries: 0,
      },
    );
  },

  studentAccounts(params = {}) {
    return request(
      `/api/student-accounts${buildQuery(params)}`,
    );
  },

  createStudentAccount(payload) {
    return request("/api/student-accounts", {
      method: "POST",
      body: JSON.stringify(payload),
      retries: 0,
    });
  },

  updateStudentAccount(accountId, payload) {
    return request(
      `/api/student-accounts/${encodeURIComponent(accountId)}`,
      {
        method: "PATCH",
        body: JSON.stringify(payload),
        retries: 0,
      },
    );
  },

  validateRfidUid(uid) {
    return request("/api/rfid/enrollment/validate", {
      method: "POST",
      body: JSON.stringify({ uid }),
      retries: 0,
    });
  },

  /* =======================================================
     ATTENDANCE
  ======================================================= */

  markAttendance(payload) {
    return request("/api/attendance/manual", {
      method: "POST",
      body: JSON.stringify(payload),
      retries: 0,
    });
  },

  rfidAttendance(uid, deviceId = "Dashboard-RFID-Input") {
    return request("/api/attendance", {
      method: "POST",
      body: JSON.stringify({
        uid,
        device_id: deviceId,
      }),
      retries: 0,
    });
  },

  attendanceRecords(params = {}) {
    return request(
      `/api/attendance/records${buildQuery(
        params,
      )}`,
    );
  },

  analytics(params = {}) {
    return request(
      `/api/analytics${buildQuery(params)}`,
    );
  },

  latestScan() {
    return request("/api/scans/latest");
  },

  studentMe() {
    return request("/api/student/me");
  },

  studentEditRequests() {
    return request("/api/student/edit-requests");
  },

  createStudentEditRequest(payload) {
    return request("/api/student/edit-requests", {
      method: "POST",
      body: JSON.stringify(payload),
      retries: 0,
    });
  },

  adminEditRequests(params = {}) {
    return request(
      `/api/edit-requests${buildQuery(params)}`,
    );
  },

  reviewEditRequest(requestId, payload) {
    return request(
      `/api/edit-requests/${encodeURIComponent(requestId)}/review`,
      {
        method: "POST",
        body: JSON.stringify(payload),
        retries: 0,
      },
    );
  },

  demoScan() {
    return request("/api/demo/scan", {
      method: "POST",
      body: JSON.stringify({}),
      retries: 0,
    });
  },

  /* =======================================================
     PROFILE
  ======================================================= */

  profile() {
    return request("/api/profile");
  },

  /* =======================================================
     REPORTS
  ======================================================= */

  csvUrl(params = {}) {
    return `/api/reports/csv${buildQuery(
      params,
    )}`;
  },

  /* =======================================================
     UTILITIES
  ======================================================= */

  isAuthError(error) {
    return error?.status === 401;
  },

  isPermissionError(error) {
    return error?.status === 403;
  },

  isNetworkError(error) {
    return (
      error?.code === "NETWORK_ERROR" ||
      error?.code === "TIMEOUT"
    );
  },
};

export { ApiError };
