import { Api } from "./api.js";
import {
  AdminOverview,
  AnalyticsPage,
  AttendancePage,
  AboutPage,
  ProfilePage,
  ReportsPage,
  SettingsPage,
  StudentPortalPage,
  StudentsPage,
} from "./components/AdminPages.js";
import { AuthGate } from "./components/Auth.js";
import { Dashboard } from "./components/Dashboard.js";

const { createElement: h, useCallback, useEffect, useRef, useState } = window.React;
const root = window.ReactDOM.createRoot(document.getElementById("root"));

const navItems = [
  ["dashboard", "Dashboard", "primary"],
  ["students", "Students", "primary"],
  ["attendance", "Attendance", "primary"],
  ["analytics", "Analytics", "primary"],
  ["reports", "Reports", "primary"],
  ["about", "About", "secondary"],
  ["profile", "Profile/Team", "secondary"],
  ["settings", "Settings", "secondary"],
];

const navIcons = {
  dashboard: "⌁",
  students: "◎",
  attendance: "✓",
  analytics: "↗",
  reports: "⇩",
  about: "◇",
  profile: "●",
  settings: "▦",
};

function App() {
  const [admin, setAdmin] = useState(null);
  const [allowSignup, setAllowSignup] = useState(false);
  const [authChecking, setAuthChecking] = useState(true);
  const [activePage, setActivePage] = useState("dashboard");
  const [dashboard, setDashboard] = useState(null);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [apiOnline, setApiOnline] = useState(false);
  const [showTop, setShowTop] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [clock, setClock] = useState(new Date());
  const [transitionState, setTransitionState] = useState("idle");

  const apiWasDown = useRef(false);
  const transitionTimer = useRef(0);
  const enterTimer = useRef(0);

  /* ---------------------------------------------------------
     TOASTS
  --------------------------------------------------------- */

  const addToast = useCallback((message, tone = "info") => {
    const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;

    setToasts((items) => [
      ...items.slice(-2),
      {
        id,
        message,
        tone,
      },
    ]);

    window.setTimeout(() => {
      setToasts((items) => items.filter((item) => item.id !== id));
    }, 4200);
  }, []);

  const removeToast = useCallback((id) => {
    setToasts((items) => items.filter((item) => item.id !== id));
  }, []);

  /* ---------------------------------------------------------
     PAGE NAVIGATION
  --------------------------------------------------------- */

  const navigatePage = useCallback(
    (nextPage) => {
      if (nextPage === activePage) return;

      window.clearTimeout(transitionTimer.current);
      window.clearTimeout(enterTimer.current);

      const reduceMotion = window.matchMedia(
        "(prefers-reduced-motion: reduce)",
      ).matches;

      if (reduceMotion) {
        setActivePage(nextPage);
        setTransitionState("idle");
        window.scrollTo({
          top: 0,
          behavior: "auto",
        });
        return;
      }

      setTransitionState("page-exit");

      transitionTimer.current = window.setTimeout(() => {
        setActivePage(nextPage);

        window.scrollTo({
          top: 0,
          behavior: "auto",
        });

        setTransitionState("page-enter");

        enterTimer.current = window.setTimeout(() => {
          setTransitionState("idle");
        }, 40);
      }, 180);
    },
    [activePage],
  );

  /* ---------------------------------------------------------
     LOAD DASHBOARD DATA
  --------------------------------------------------------- */

  const loadAll = useCallback(async () => {
    setError("");

    if (admin?.role === "student") {
      setDashboard(null);
      setStudents([]);
      setApiOnline(true);
      setLoading(false);
      return;
    }

    try {
      const [dashboardData, studentData] = await Promise.all([
        Api.dashboard(),
        admin
          ? Api.students()
          : Promise.resolve({
              students: [],
            }),
      ]);

      setDashboard(dashboardData);
      setStudents(studentData.students || []);
      setApiOnline(true);

      if (apiWasDown.current) {
        addToast("API connection restored", "success");
      }

      apiWasDown.current = false;
    } catch (error) {
      if (error?.status === 401) {
        setAdmin(null);
        setDashboard(null);
        setStudents([]);

        addToast("Please sign in to continue", "error");
        return;
      }

      setApiOnline(false);

      setError(
        "The local API is not responding yet. Start Flask and refresh the page.",
      );

      if (!apiWasDown.current) {
        addToast("API connection is unavailable", "error");
      }

      apiWasDown.current = true;
    } finally {
      setLoading(false);
    }
  }, [addToast, admin]);

  /* ---------------------------------------------------------
     RESTORE AUTHENTICATION SESSION
  --------------------------------------------------------- */

  useEffect(() => {
    let mounted = true;

    Api.session()
      .then((result) => {
        if (!mounted) return;

        if (result?.authenticated) {
          setAdmin(result.account || result.admin);
        }

        setAllowSignup(Boolean(result?.allowSignup));
      })
      .catch(() => {
        if (mounted) {
          setAdmin(null);
        }
      })
      .finally(() => {
        if (mounted) {
          setAuthChecking(false);
        }
      });

    return () => {
      mounted = false;
    };
  }, []);

  /* ---------------------------------------------------------
     DASHBOARD POLLING
  --------------------------------------------------------- */

  useEffect(() => {
    if (!admin) return undefined;

    loadAll();

    const timer = window.setInterval(() => {
      loadAll();
    }, 2800);

    return () => {
      window.clearInterval(timer);
    };
  }, [admin, loadAll]);

  /* ---------------------------------------------------------
     CLOCK
  --------------------------------------------------------- */

  useEffect(() => {
    const timer = window.setInterval(() => {
      setClock(new Date());
    }, 1000);

    return () => {
      window.clearInterval(timer);
    };
  }, []);

  /* ---------------------------------------------------------
     LOADING SCREEN
  --------------------------------------------------------- */

  useEffect(() => {
    const loadingScreen = document.getElementById("loading-screen");

    const timer = window.setTimeout(() => {
      loadingScreen?.classList.add("hidden");
    }, 650);

    return () => {
      window.clearTimeout(timer);
    };
  }, []);

  /* ---------------------------------------------------------
     SCROLL REVEAL
  --------------------------------------------------------- */

  useEffect(() => {
    const revealItems = Array.from(
      document.querySelectorAll("[data-reveal]"),
    );

    if (!revealItems.length) return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.14,
        rootMargin: "0px 0px -40px 0px",
      },
    );

    revealItems.forEach((item) => {
      observer.observe(item);
    });

    return () => {
      observer.disconnect();
    };
  }, [dashboard, activePage, admin]);

  /* ---------------------------------------------------------
     DESKTOP CARD TILT
  --------------------------------------------------------- */

  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches) {
      return undefined;
    }

    let raf = 0;
    let activeCard = null;
    let pending = null;

    function onMove(event) {
      const card = event.target.closest("[data-tilt]");

      if (!card) return;

      activeCard = card;

      pending = {
        x: event.clientX,
        y: event.clientY,
      };

      if (raf) return;

      raf = requestAnimationFrame(() => {
        raf = 0;

        if (!activeCard || !pending) return;

        const rect = activeCard.getBoundingClientRect();

        if (!rect.width || !rect.height) return;

        const x = pending.x - rect.left;
        const y = pending.y - rect.top;

        const rotateX =
          ((y / rect.height) - 0.5) * -5;

        const rotateY =
          ((x / rect.width) - 0.5) * 5;

        activeCard.style.setProperty(
          "--rx",
          `${rotateX}deg`,
        );

        activeCard.style.setProperty(
          "--ry",
          `${rotateY}deg`,
        );
      });
    }

    function onLeave(event) {
      const card = event.target.closest("[data-tilt]");

      if (!card) return;

      card.style.setProperty("--rx", "0deg");
      card.style.setProperty("--ry", "0deg");

      if (activeCard === card) {
        activeCard = null;
      }
    }

    document.addEventListener("pointermove", onMove);
    document.addEventListener("pointerout", onLeave);

    return () => {
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerout", onLeave);

      if (raf) {
        cancelAnimationFrame(raf);
      }
    };
  }, []);

  /* ---------------------------------------------------------
     BACK TO TOP
  --------------------------------------------------------- */

  useEffect(() => {
    function onScroll() {
      setShowTop(window.scrollY > 760);
    }

    onScroll();

    window.addEventListener("scroll", onScroll, {
      passive: true,
    });

    return () => {
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  /* ---------------------------------------------------------
     CLEANUP PAGE TRANSITIONS
  --------------------------------------------------------- */

  useEffect(() => {
    return () => {
      window.clearTimeout(transitionTimer.current);
      window.clearTimeout(enterTimer.current);
    };
  }, []);

  /* ---------------------------------------------------------
     LOGOUT
  --------------------------------------------------------- */

  async function logout() {
    try {
      await Api.logout();
    } catch {
      // Logout should still clear the local UI session.
    } finally {
      window.localStorage.removeItem("smartRfidLastAdmin");

      setAdmin(null);
      setDashboard(null);
      setStudents([]);
      setApiOnline(false);
      setError("");
      setActivePage("dashboard");

      addToast("Logged out", "info");
    }
  }

  /* ---------------------------------------------------------
     AUTHENTICATED CALLBACK
  --------------------------------------------------------- */

  function handleAuthenticated(nextAdmin) {
    setAdmin(nextAdmin);
    setActivePage(nextAdmin?.role === "student" ? "portal" : "dashboard");
    setLoading(true);
    setError("");
  }

  /* ---------------------------------------------------------
     AUTH CHECK SCREEN
  --------------------------------------------------------- */

  if (authChecking) {
    return h(
      "main",
      {
        className: "auth-page",
      },
      h("div", {
        className: "loader-mark",
      }),
    );
  }

  /* ---------------------------------------------------------
     LOGIN SCREEN
  --------------------------------------------------------- */

  if (!admin) {
    return h(
      window.React.Fragment,
      null,
      h(AuthGate, {
        onAuthenticated: handleAuthenticated,
        onToast: addToast,
        allowSignup,
      }),
      h(ToastViewport, {
        toasts,
        onDismiss: removeToast,
      }),
    );
  }

  if (admin?.role === "student") {
    return h(
      "main",
      {
        className: "admin-app",
      },
      h(
        "div",
        {
          className: "ambient-field",
          "aria-hidden": true,
        },
        h("span", null),
        h("span", null),
        h("span", null),
      ),
      h(
        "header",
        {
          className: "site-header",
        },
        h(
          "nav",
          {
            className: "nav shell",
          },
          h(
            "div",
            {
              className: "brand",
            },
            h("span", { className: "brand-mark" }, "S"),
            h("span", null, "Smart RFID"),
          ),
          h(
            "div",
            {
              className: "nav-status-group",
            },
            h("span", { className: "api-status online" }, h("span", null), "Student Portal"),
            h("button", { className: "btn btn-compact", type: "button", onClick: logout }, "Logout"),
          ),
        ),
      ),
      h(
        "div",
        {
          className: "admin-shell shell",
        },
        h(StudentPortalPage, {
          account: admin,
          onToast: addToast,
        }),
      ),
      h(ToastViewport, {
        toasts,
        onDismiss: removeToast,
      }),
    );
  }

  /* ---------------------------------------------------------
     ADMIN APPLICATION
  --------------------------------------------------------- */

  return h(
    "main",
    {
      className: "admin-app",
    },

    /* Ambient background */
    h(
      "div",
      {
        className: "ambient-field",
        "aria-hidden": true,
      },
      h("span", null),
      h("span", null),
      h("span", null),
    ),

    /* Header */
    h(AdminHeader, {
      activePage,
      setActivePage: navigatePage,
      admin,
      apiOnline,
      device: dashboard?.device,
      visits: dashboard?.visits,
      clock,
      logout,
    }),

    /* API error */
    error
      ? h(
          "div",
          {
            className: "api-error shell",
            role: "alert",
          },
          error,
        )
      : null,

    h(QuickSearch, {
      students,
      setActivePage: navigatePage,
      onToast: addToast,
    }),

    /* Main content */
    h(
      "div",
      {
        className: "admin-shell shell",
      },
      h(
        "div",
        {
          className: `page-stage ${transitionState}`,
        },
        h(PageContent, {
          activePage,
          dashboard,
          students,
          clock,
          loading,
          apiOnline,
          loadAll,
          addToast,
        }),
      ),
    ),

    /* Back to top */
    h(
      "button",
      {
        className: `back-to-top ${showTop ? "visible" : ""}`,
        onClick: () =>
          window.scrollTo({
            top: 0,
            behavior: "smooth",
          }),
        "aria-label": "Back to top",
        type: "button",
      },
      "↑",
    ),

    /* Toasts */
    h(ToastViewport, {
      toasts,
      onDismiss: removeToast,
    }),
  );
}

function QuickSearch({ students, setActivePage, onToast }) {
  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState(false);

  const term = query.trim().toLowerCase();
  const results = term
    ? students
        .filter((student) =>
          [
            student.name,
            student.rollNo,
            student.rfidUid,
            student.className,
            student.todayStatus,
          ].some((value) =>
            String(value || "")
              .toLowerCase()
              .includes(term),
          ),
        )
        .slice(0, 5)
    : [];

  function go(page, student) {
    setActivePage(page);
    setQuery("");
    setFocused(false);
    onToast?.(
      student
        ? `${student.name} opened in ${page}`
        : `${page} opened`,
      "info",
    );
  }

  function onKeyDown(event) {
    if (event.key === "Escape") {
      setQuery("");
      setFocused(false);
      event.currentTarget.blur();
    }

    if (event.key === "Enter" && results[0]) {
      event.preventDefault();
      go("students", results[0]);
    }
  }

  return h(
    "section",
    {
      className: "quick-search shell",
      onFocus: () => setFocused(true),
      onBlur: () => window.setTimeout(() => setFocused(false), 120),
    },
    h(
      "label",
      null,
      h("span", null, "Quick search"),
      h("input", {
        value: query,
        onInput: (event) => setQuery(event.target.value),
        onKeyDown,
        placeholder: "Search student, roll, UID, or status",
        "aria-label": "Search students and quick actions",
      }),
      query
        ? h("button", {
            type: "button",
            className: "quick-clear",
            onClick: () => setQuery(""),
            "aria-label": "Clear quick search",
          }, "×")
        : null,
    ),
    focused && term
      ? h(
          "div",
          { className: "quick-results" },
          results.length
            ? results.map((student) =>
                h(
                  "article",
                  { key: student.id },
                  h(
                    "button",
                    {
                      type: "button",
                      onClick: () => go("students", student),
                    },
                    h("strong", null, student.name),
                    h(
                      "small",
                      null,
                      `Roll ${student.rollNo} · ${student.className} · ${student.attendancePercentage ?? 0}%`,
                    ),
                  ),
                  h(
                    "div",
                    { className: "quick-actions" },
                    h(
                      "button",
                      {
                        type: "button",
                        onMouseDown: (event) => event.preventDefault(),
                        onClick: () => go("attendance", student),
                      },
                      "Attendance",
                    ),
                    h(
                      "button",
                      {
                        type: "button",
                        onMouseDown: (event) => event.preventDefault(),
                        onClick: () => go("analytics", student),
                      },
                      "Analytics",
                    ),
                  ),
                ),
              )
            : h(
                "div",
                { className: "quick-empty" },
                "No students found",
              ),
        )
      : null,
  );
}

/* =========================================================
   PAGE CONTENT
========================================================= */

function PageContent({
  activePage,
  dashboard,
  students,
  clock,
  loading,
  apiOnline,
  loadAll,
  addToast,
}) {
  const commonProps = {
    data: dashboard,
    dashboard,
    students,
    clock,
    loading,
    apiOnline,
    device: dashboard?.device,
    onRefresh: loadAll,
    onChanged: loadAll,
    onToast: addToast,
    loadAll,
    addToast,
  };

  switch (activePage) {
    case "dashboard":
      return h(Dashboard, commonProps);

    case "students":
      return h(StudentsPage, commonProps);

    case "attendance":
      return h(AttendancePage, commonProps);

    case "analytics":
      return h(AnalyticsPage, commonProps);

    case "reports":
      return h(ReportsPage, commonProps);

    case "about":
      return h(AboutPage, commonProps);

    case "profile":
      return h(ProfilePage, commonProps);

    case "settings":
      return h(SettingsPage, commonProps);

    default:
      return h(Dashboard, commonProps);
  }
}

/* =========================================================
   ADMIN HEADER
========================================================= */

function AdminHeader({
  activePage,
  setActivePage,
  admin,
  apiOnline,
  device,
  visits,
  clock,
  logout,
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  const navRef = useRef(null);

  const activeLabel =
    navItems.find(([id]) => id === activePage)?.[1] ||
    "Menu";

  function choosePage(id) {
    setActivePage(id);
    setMenuOpen(false);
  }

  /* -------------------------------------------------------
     CLOSE MOBILE MENU
  ------------------------------------------------------- */

  useEffect(() => {
    if (!menuOpen) return undefined;

    function closeOnEscape(event) {
      if (event.key === "Escape") {
        setMenuOpen(false);
      }
    }

    function closeOnOutsideClick(event) {
      if (
        navRef.current &&
        !navRef.current.contains(event.target)
      ) {
        setMenuOpen(false);
      }
    }

    document.addEventListener(
      "keydown",
      closeOnEscape,
    );

    document.addEventListener(
      "pointerdown",
      closeOnOutsideClick,
    );

    return () => {
      document.removeEventListener(
        "keydown",
        closeOnEscape,
      );

      document.removeEventListener(
        "pointerdown",
        closeOnOutsideClick,
      );
    };
  }, [menuOpen]);

  /* -------------------------------------------------------
     HEADER
  ------------------------------------------------------- */

  return h(
    "header",
    {
      className: "site-header admin-header",
    },

    h(
      "nav",
      {
        className: "nav shell",
        "aria-label": "Admin navigation",
        ref: navRef,
      },

      /* Brand */
      h(
        "button",
        {
          className: "brand brand-button",
          onClick: () => choosePage("dashboard"),
          type: "button",
          "aria-label": "Go to dashboard",
        },

        h(
          "span",
          {
            className: "brand-mark",
          },
          "S",
        ),

        h(
          "span",
          null,
          "Smart RFID Admin",
        ),
      ),

      /* Mobile menu toggle */
      h(
        "button",
        {
          className: `menu-toggle ${
            menuOpen ? "open" : ""
          }`,
          onClick: () =>
            setMenuOpen((value) => !value),
          "aria-expanded": menuOpen,
          "aria-label":
            "Toggle admin navigation",
          type: "button",
        },

        h(
          "span",
          {
            className: "menu-lines",
            "aria-hidden": true,
          },
          h("i", null),
          h("i", null),
          h("i", null),
        ),

        h(
          "em",
          null,
          menuOpen ? "Close" : activeLabel,
        ),
      ),

      /* Navigation */
      h(
        "div",
        {
          className: `admin-tabs ${
            menuOpen ? "is-open" : ""
          }`,
          role: "menu",
        },

        navItems.map(([id, label]) =>
          h(
            "button",
            {
              className:
                activePage === id
                  ? "active"
                  : "",
              key: id,
              onClick: () =>
                choosePage(id),
              role: "menuitem",
              "aria-current":
                activePage === id
                  ? "page"
                  : undefined,
              type: "button",
            },
            h("span", { "aria-hidden": true }, navIcons[id] || "•"),
            h("em", null, label),
          ),
        ),
      ),

      /* Header actions */
      h(
        "div",
        {
          className: "admin-top-actions",
        },

        /* Clock */
        h(
          "div",
          {
            className: "clock-chip",
          },

          h(
            "strong",
            null,
            clock.toLocaleTimeString(
              [],
              {
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
              },
            ),
          ),

          h(
            "span",
            null,
            clock.toLocaleDateString(),
          ),
        ),

        /* Visits */
        h(
          "div",
          {
            className: "visit-chip",
          },

          h(
            "span",
            null,
            "Visits",
          ),

          h(
            "strong",
            null,
            visits?.total ?? 0,
          ),
        ),

        /* API status */
        h(
          "span",
          {
            className: `api-status ${
              apiOnline
                ? "online"
                : "offline"
            }`,
          },

          h("span", null),

          apiOnline
            ? "API Live"
            : "API Waiting",
        ),

        /* Device status */
        h(
          "button",
          {
            className: `nav-status ${
              device?.online
                ? "online"
                : "offline"
            }`,
            type: "button",
            title: device?.online
              ? "RFID device is online"
              : "RFID device is offline",
          },

          h("span", null),

          device?.online
            ? "Device Online"
            : "Device Offline",
        ),

        /* Logout */
        h(
          "button",
          {
            className: "logout-btn",
            onClick: logout,
            type: "button",
          },
          `Logout ${admin.username}`,
        ),
      ),
    ),
  );
}

/* =========================================================
   TOAST VIEWPORT
========================================================= */

function ToastViewport({
  toasts,
  onDismiss,
}) {
  const toneLabels = {
    success: "Success",
    error: "Attention",
    info: "Update",
  };

  return h(
    "div",
    {
      className: "toast-viewport",
      "aria-live": "polite",
      "aria-relevant": "additions",
    },

    toasts.map((toast) =>
      h(
        "div",
        {
          className: `toast toast-${toast.tone}`,
          key: toast.id,
          role:
            toast.tone === "error"
              ? "alert"
              : "status",
        },

        h(
          "span",
          {
            className: "toast-dot",
            "aria-hidden": true,
          },
        ),

        h(
          "div",
          null,

          h(
            "strong",
            null,
            toneLabels[toast.tone] ||
              "Update",
          ),

          h(
            "p",
            null,
            toast.message,
          ),
        ),

        h(
          "button",
          {
            type: "button",
            onClick: () =>
              onDismiss?.(toast.id),
            "aria-label":
              "Dismiss notification",
          },
          "×",
        ),

        h(
          "i",
          {
            "aria-hidden": true,
          },
        ),
      ),
    ),
  );
}

/* =========================================================
   MOUNT APPLICATION
========================================================= */

root.render(h(App));
