const { createElement: h, useEffect, useState } = window.React;

export function Badge({ children, tone = "cyan" }) {
  return h("span", { className: `badge badge-${tone}` }, children);
}

export function SectionTitle({ eyebrow, title, copy, align = "center" }) {
  return h(
    "div",
    { className: `section-title ${align === "left" ? "section-title-left" : ""}`, "data-reveal": true },
    eyebrow ? h("span", { className: "eyebrow" }, eyebrow) : null,
    h("h2", null, title),
    copy ? h("p", null, copy) : null,
  );
}

export function MetricCard({ label, value, detail, tone = "cyan" }) {
  const parsed = typeof value === "string" && value.endsWith("%")
    ? { number: Number(value.replace("%", "")), suffix: "%" }
    : { number: Number(value), suffix: "" };
  const canAnimate = Number.isFinite(parsed.number);

  return h(
    "article",
    { className: `metric-card metric-${tone}`, "data-tilt": true },
    h("span", { className: "metric-label" }, label),
    h("strong", null, canAnimate ? h(AnimatedNumber, { value: parsed.number, suffix: parsed.suffix }) : value),
    h("small", null, detail),
  );
}

export function AnimatedNumber({ value, suffix = "" }) {
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setDisplay(value);
      return undefined;
    }

    let frame = 0;
    const start = performance.now();
    const from = display;
    const duration = 520;

    function tick(now) {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(from + (value - from) * eased);
      if (progress < 1) frame = requestAnimationFrame(tick);
    }

    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [value]);

  const formatted = Number.isInteger(value) ? Math.round(display) : display.toFixed(1);
  return `${formatted}${suffix}`;
}

export function IconGlyph({ type }) {
  const glyphs = {
    tap: "⟡",
    pulse: "≈",
    wifi: "⌁",
    api: "{}",
    db: "▦",
    csv: "⇩",
    mobile: "▯",
    device: "●",
    chart: "↗",
    automation: "✦",
  };
  return h("span", { className: `icon-glyph icon-${type}`, "aria-hidden": true }, glyphs[type] || "✦");
}

export function StatusPill({ online, label }) {
  return h(
    "span",
    { className: `status-pill ${online ? "is-online" : "is-offline"}` },
    h("span", { className: "status-dot", "aria-hidden": true }),
    label || (online ? "Device Online" : "Device Offline"),
  );
}

export function ApiPill({ online = true }) {
  return h(
    "span",
    { className: `status-pill api-pill ${online ? "is-online" : "is-offline"}` },
    h("span", { className: "status-dot", "aria-hidden": true }),
    online ? "API Connected" : "API Waiting",
  );
}

export function ProgressBar({ value }) {
  const safeValue = Math.max(0, Math.min(100, Number(value) || 0));
  return h(
    "div",
    { className: "progress-track", role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": safeValue },
    h("span", { style: { width: `${safeValue}%` } }),
  );
}

export function EmptyState({ title, copy }) {
  return h(
    "div",
    { className: "empty-state" },
    h("strong", null, title),
    h("p", null, copy),
  );
}

export function SkeletonCard({ lines = 3 }) {
  return h(
    "div",
    { className: "skeleton-card", "aria-hidden": true },
    Array.from({ length: lines }).map((_, index) => h("span", { key: index })),
  );
}
