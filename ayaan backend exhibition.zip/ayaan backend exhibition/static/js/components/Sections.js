import { Api } from "../api.js";
import { explainerCards, featureCards, learningBlocks, team, workflowSteps } from "../data.js";
import { IconGlyph, ProgressBar, SectionTitle } from "./ui.js";

const { createElement: h, useMemo, useState } = window.React;

export function ProjectExplanation() {
  const cards = [
    ["RFID Input", "Every student card carries a unique UID that is read instantly by the RC522 scanner."],
    ["ESP32 Bridge", "The microcontroller connects the hardware scan to the school network using Wi-Fi."],
    ["Flask API", "A REST endpoint receives the UID, validates it, and returns a stable response to the device."],
    ["SQLite Record", "Attendance is written into a lightweight database and reflected on the dashboard."],
  ];

  return h(
    "section",
    { className: "section-band explanation", id: "technology" },
    h("div", { className: "shell" },
      h(SectionTitle, {
        eyebrow: "Project Intelligence",
        title: "A complete IoT attendance pipeline",
        copy: "When a student taps an RFID card, the ESP32 reads the UID and sends it to the Flask REST API through Wi-Fi. The backend verifies the student, stores attendance in SQLite, and instantly updates the dashboard.",
      }),
      h("div", { className: "process-grid" },
        cards.map((card, index) =>
          h("article", { className: "process-card", key: card[0], "data-reveal": true, style: { "--delay": `${index * 80}ms` } },
            h("span", { className: "process-index" }, `0${index + 1}`),
            h("h3", null, card[0]),
            h("p", null, card[1]),
          ),
        ),
      ),
    ),
  );
}

export function WorkflowTimeline() {
  return h(
    "section",
    { className: "section-band workflow" },
    h("div", { className: "shell" },
      h(SectionTitle, {
        eyebrow: "System Flow",
        title: "From card tap to live insight",
        copy: "The complete hardware-to-software workflow is built like a real IoT product: fast input, clear validation, reliable storage, and instant visibility.",
      }),
      h("div", { className: "timeline", "data-reveal": true },
        workflowSteps.map((step, index) =>
          h("article", { className: "timeline-card", key: step[0], style: { "--i": index } },
            h("span", { className: "timeline-step" }, step[0]),
            h("h3", null, step[1]),
            h("p", null, step[2]),
          ),
        ),
      ),
    ),
  );
}

export function Features() {
  return h(
    "section",
    { className: "section-band features" },
    h("div", { className: "shell" },
      h(SectionTitle, {
        eyebrow: "Premium Feature Set",
        title: "Built like smart-campus software",
        copy: "The interface combines useful real-world controls with an exhibition-ready product presentation.",
      }),
      h("div", { className: "feature-grid" },
        featureCards.map((feature, index) =>
          h("article", { className: "feature-card", key: feature[0], "data-tilt": true, "data-reveal": true, style: { "--delay": `${index * 45}ms` } },
            h(IconGlyph, { type: feature[2] }),
            h("h3", null, feature[0]),
            h("p", null, feature[1]),
          ),
        ),
      ),
    ),
  );
}

export function Reports({ data, onToast }) {
  const [query, setQuery] = useState("");
  const monthly = data?.monthly || [];
  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return monthly;
    return monthly.filter((item) =>
      [item.name, item.rollNo, item.rfidUid].some((value) => String(value || "").toLowerCase().includes(term)),
    );
  }, [monthly, query]);
  const topStudent = [...monthly].sort((a, b) => b.attendanceRate - a.attendanceRate)[0];
  const metrics = data?.metrics || {};

  return h(
    "section",
    { className: "section-band reports", id: "reports" },
    h("div", { className: "shell" },
      h("div", { className: "reports-layout" },
        h("div", { "data-reveal": true },
          h("span", { className: "eyebrow" }, "Reports"),
          h("h2", null, "Download-ready attendance intelligence"),
          h("p", null, "Generate clean CSV files for daily attendance, monthly summaries, or a filtered student history."),
          h("div", { className: "report-actions" },
            h("a", { className: "btn btn-primary", href: Api.csvUrl({ date: data?.date }), onClick: () => onToast?.("Today CSV export started", "success") }, "Download Today CSV"),
            h("a", { className: "btn btn-secondary", href: Api.csvUrl({ month: data?.date?.slice(0, 7) }), onClick: () => onToast?.("Monthly CSV export started", "info") }, "Monthly CSV"),
          ),
        ),
        h("aside", { className: "report-profile", "data-reveal": true },
          h("span", { className: "eyebrow mini" }, "Top Performer"),
          h("h3", null, topStudent?.name || "Awaiting data"),
          h(ProgressBar, { value: topStudent?.attendanceRate || 0 }),
          h("p", null, topStudent ? `${topStudent.attendanceRate}% monthly attendance across recorded school days.` : "Student performance appears here once attendance data is available."),
        ),
      ),
      h("div", { className: "report-stat-grid", "data-reveal": true },
        h("article", null, h("span", null, "Daily present"), h("strong", null, metrics.present ?? 0), h("small", null, "Verified students")),
        h("article", null, h("span", null, "Daily absent"), h("strong", null, metrics.absent ?? 0), h("small", null, "Awaiting RFID scan")),
        h("article", null, h("span", null, "Attendance rate"), h("strong", null, `${metrics.attendancePercentage || 0}%`), h("small", null, "Current class average")),
      ),
      h("div", { className: "monthly-panel", "data-reveal": true },
        h("div", { className: "panel-heading table-heading" },
          h("div", null,
            h("span", { className: "eyebrow mini" }, "Monthly Summary"),
            h("h3", null, "Student Report Generator"),
          ),
          h("label", { className: "search-box" },
            h("span", null, "Filter"),
            h("input", {
              value: query,
              onInput: (event) => setQuery(event.target.value),
              placeholder: "Search student or UID",
            }),
          ),
        ),
        filtered.length
          ? h("div", { className: "student-report-grid" },
              filtered.map((student) =>
                h("article", { className: "student-report", key: student.id },
                  h("div", null,
                    h("strong", null, student.name),
                    h("small", null, `UID ${student.rfidUid}`),
                  ),
                  h("span", null, `${student.attendanceRate}%`),
                  h(ProgressBar, { value: student.attendanceRate }),
                  h("a", { href: Api.csvUrl({ student_id: student.id }), className: "mini-link", onClick: () => onToast?.(`${student.name} report export started`, "info") }, "Download history"),
                ),
              ),
            )
          : h("div", { className: "student-report-empty" }, "No student report matches this search."),
      ),
    ),
  );
}

export function Explainers() {
  return h(
    "section",
    { className: "section-band explainers" },
    h("div", { className: "shell" },
      h(SectionTitle, {
        eyebrow: "Learning Outcomes",
        title: "Technology explained for judges",
        copy: "The project is presented as both a working product and a clear educational demonstration of IoT engineering.",
      }),
      h("div", { className: "explainer-grid" },
        explainerCards.map((card, index) =>
          h("article", { className: "explainer-card", key: card[0], "data-reveal": true, style: { "--delay": `${index * 70}ms` } },
            h("span", null, `0${index + 1}`),
            h("h3", null, card[0]),
            h("p", null, card[1]),
          ),
        ),
      ),
      h("div", { className: "learning-strip", "data-reveal": true },
        learningBlocks.map((item) => h("span", { key: item }, item)),
      ),
      h("div", { className: "learning-lab", "data-reveal": true },
        h("article", null,
          h("span", null, "01"),
          h("h3", null, "Frontend Engineering"),
          h("p", null, "Responsive React components, polling, loading states, animated counters, and polished dashboard interactions."),
        ),
        h("article", null,
          h("span", null, "02"),
          h("h3", null, "Backend Engineering"),
          h("p", null, "Flask APIs validate RFID scans, protect duplicate attendance, monitor device heartbeats, and export CSV reports."),
        ),
        h("article", null,
          h("span", null, "03"),
          h("h3", null, "IoT Integration"),
          h("p", null, "ESP32 sends Wi-Fi requests from the RC522 scanner into the software layer for real-time automation."),
        ),
      ),
    ),
  );
}

export function Team() {
  return h(
    "section",
    { className: "section-band team-section" },
    h("div", { className: "shell" },
      h(SectionTitle, {
        eyebrow: "Team",
        title: "Built by a focused exhibition team",
        copy: "Each member owns a key layer of the full smart-attendance system.",
      }),
      h("div", { className: "team-grid" },
        team.map((member) =>
          h("article", { className: `team-card ${member.lead ? "lead" : ""}`, key: member.name, "data-tilt": true, "data-reveal": true },
            member.badge ? h("span", { className: "team-badge" }, member.badge) : null,
            h("h3", null, member.name),
            h("p", null, member.role),
          ),
        ),
      ),
    ),
  );
}

export function Conclusion() {
  return h(
    "section",
    { className: "section-band conclusion" },
    h("div", { className: "shell" },
      h("article", { className: "conclusion-card", "data-reveal": true },
        h("span", { className: "eyebrow" }, "Conclusion"),
        h("h2", null, "Intelligent attendance, built for the real world"),
        h("p", null, "This project demonstrates how IoT devices, APIs, databases, and automation technologies can transform traditional attendance systems into intelligent real-time solutions."),
        h("a", { className: "btn btn-primary", href: "#dashboard" }, "View Live Dashboard"),
      ),
    ),
  );
}
