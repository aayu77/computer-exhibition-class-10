import { Api } from "../api.js";
import { ApiPill, EmptyState, MetricCard, ProgressBar, SkeletonCard, StatusPill } from "./ui.js";

const { createElement: h, useMemo, useState } = window.React;

function formatScanTime(value) {
  if (!value) return "Waiting";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function formatDateTime(value) {
  if (!value) return "No signal yet";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatFullDate(value) {
  if (!value) return "Today";
  const parsed = new Date(`${value}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleDateString([], {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function formatAgo(seconds) {
  if (seconds === null || seconds === undefined) return "Waiting for ESP32";
  if (seconds < 5) return "just now";
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  return `${minutes}m ago`;
}

function TodayTable({ students, query }) {
  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return students;
    return students.filter((student) =>
      [student.name, student.rollNo, student.rfidUid, student.status].some((item) =>
        String(item || "").toLowerCase().includes(term),
      ),
    );
  }, [students, query]);

  return h(
    "div",
    { className: "table-content" },
    h("p", { className: "table-count" }, `${filtered.length} student${filtered.length === 1 ? "" : "s"} shown`),
    filtered.length
      ? h("div", { className: "table-wrap" },
          h("table", { className: "attendance-table" },
            h("thead", null,
              h("tr", null,
                h("th", null, "Roll"),
                h("th", null, "Student"),
                h("th", null, "RFID UID"),
                h("th", null, "Status"),
                h("th", null, "Check-in"),
              ),
            ),
            h("tbody", null,
              filtered.map((student) =>
                h("tr", { key: student.id },
                  h("td", { "data-label": "Roll" }, student.rollNo),
                  h("td", { "data-label": "Student" },
                    h("div", { className: "student-cell" },
                      h("span", null, student.name),
                      h("small", null, student.className),
                    ),
                  ),
                  h("td", { "data-label": "RFID UID" }, h("code", null, student.rfidUid)),
                  h("td", { "data-label": "Status" }, h("span", { className: `row-status ${student.status === "Present" ? "present" : student.status === "Late" ? "late" : "absent"}` }, student.status)),
                  h("td", { "data-label": "Check-in" }, student.checkInTime || "Not scanned"),
                ),
              ),
            ),
          ),
        )
      : h(EmptyState, { title: "No matching students", copy: "Try searching by name, roll number, RFID UID, or status." }),
  );
}

function AttendanceChart({ trend, total }) {
  const max = Math.max(1, total || 1);
  return h(
    "div",
    { className: "chart-panel" },
    h("div", { className: "panel-heading" },
      h("div", null,
        h("span", { className: "eyebrow mini" }, "Daily Analytics"),
        h("h3", null, "Attendance Trend"),
      ),
      h("small", null, "Last active school days"),
    ),
    trend.length
      ? h("div", { className: "bar-chart", role: "img", "aria-label": "Attendance trend chart" },
          trend.map((item) => {
            const height = Math.max(12, Math.round((item.present / max) * 100));
            return h(
              "div",
              { className: "bar-item", key: item.date },
              h("span", { className: "bar-value" }, `${item.percentage}%`),
              h("div", { className: "bar-track" },
                h("span", { style: { height: `${height}%` } }),
              ),
              h("small", null, item.date.slice(5)),
            );
          }),
        )
      : h(EmptyState, { title: "No trend yet", copy: "Attendance analytics will appear after records are available." }),
  );
}

function ReadinessPanel({ data, apiOnline }) {
  const metrics = data?.metrics || {};
  const device = data?.device || {};
  const attendanceReady = (metrics.attendancePercentage || 0) >= 60;
  const checks = [
    ["API Layer", apiOnline, apiOnline ? "REST endpoints responding" : "Waiting for Flask API"],
    ["Database", Boolean(data), data ? "SQLite snapshot loaded" : "No dashboard snapshot yet"],
    ["Attendance", attendanceReady, `${metrics.present || 0}/${metrics.totalStudents || 0} marked present`],
    ["ESP32 Monitor", Boolean(device?.apiStatus), device?.online ? "Device heartbeat online" : "Offline-safe monitoring active"],
  ];

  return h(
    "div",
    { className: "readiness-panel", "data-reveal": true },
    h("div", { className: "panel-heading" },
      h("div", null,
        h("span", { className: "eyebrow mini" }, "System Readiness"),
        h("h3", null, "Live Demo Checklist"),
      ),
      h("strong", null, `${checks.filter((item) => item[1]).length}/${checks.length}`),
    ),
    h("div", { className: "readiness-grid" },
      checks.map((item) =>
        h("div", { className: `readiness-item ${item[1] ? "ok" : "watch"}`, key: item[0] },
          h("span", null),
          h("div", null,
            h("strong", null, item[0]),
            h("small", null, item[2]),
          ),
        ),
      ),
    ),
  );
}

function RecentScans({ scans }) {
  return h(
    "div",
    { className: "scan-panel" },
    h("div", { className: "panel-heading" },
      h("div", null,
        h("span", { className: "eyebrow mini" }, "Live Feed"),
        h("h3", null, "Recent RFID Scans"),
      ),
      h("span", { className: "live-chip" }, "Updating"),
    ),
    scans.length
      ? h("div", { className: "scan-list" },
          scans.map((scan) =>
            h("article", { className: `scan-item ${scan.status}`, key: scan.id },
              h("span", { className: "scan-dot" }),
              h("div", null,
                h("strong", null, scan.studentName),
                h("small", null, scan.message || scan.rfidUid),
                h("span", { className: "scan-meta" }, `${scan.status || "waiting"} · ${scan.deviceId || "Unknown source"}`),
              ),
              h("time", null, formatScanTime(scan.createdAt)),
            ),
          ),
        )
      : h(EmptyState, { title: "No scans yet", copy: "The feed will update as soon as an RFID UID reaches the API." }),
  );
}

function StatusDistribution({ metrics }) {
  const total = Math.max(1, Number(metrics.totalStudents || 0));
  const items = [
    ["Present", metrics.present || 0, "present"],
    ["Late", metrics.late || 0, "late"],
    ["Absent", metrics.absent || 0, "absent"],
  ];

  return h(
    "div",
    { className: "status-distribution" },
    h("div", { className: "panel-heading" },
      h("div", null,
        h("span", { className: "eyebrow mini" }, "Distribution"),
        h("h3", null, "Today status mix"),
      ),
    ),
    h("div", { className: "distribution-stack", role: "img", "aria-label": "Today attendance distribution" },
      items.map(([label, value, tone]) =>
        h("span", {
          key: label,
          className: tone,
          style: { width: `${Math.max(value ? 8 : 0, (value / total) * 100)}%` },
          title: `${label}: ${value}`,
        }),
      ),
    ),
    h("div", { className: "distribution-legend" },
      items.map(([label, value, tone]) =>
        h("span", { key: label, className: tone }, h("i", null), `${label}: ${value}`),
      ),
    ),
  );
}

function StudentSignals({ students }) {
  const ranked = [...(students || [])]
    .sort((a, b) => Number(b.attendancePercentage || 0) - Number(a.attendancePercentage || 0))
    .slice(0, 5);

  return h(
    "div",
    { className: "student-signals" },
    h("div", { className: "panel-heading" },
      h("div", null,
        h("span", { className: "eyebrow mini" }, "Student Signals"),
        h("h3", null, "Attendance ranking"),
      ),
      h("strong", null, ranked.length),
    ),
    ranked.length
      ? h("div", { className: "signal-list" },
          ranked.map((student) =>
            h("article", { key: student.id },
              h("span", null, student.rollNo),
              h("div", null,
                h("strong", null, student.name),
                h("small", null, student.lastAttendance ? `${student.lastAttendance.status} · ${student.lastAttendance.date}` : "No attendance history"),
              ),
              h("em", null, `${student.attendancePercentage ?? 0}%`),
            ),
          ),
        )
      : h(EmptyState, { title: "No student signals", copy: "Student ranking appears after the directory loads." }),
  );
}

function DevicePanel({ device, apiOnline, onHeartbeat, heartbeatLoading }) {
  return h(
    "div",
    { className: "device-panel" },
    h("div", { className: "panel-heading" },
      h("div", null,
        h("span", { className: "eyebrow mini" }, "ESP32 Link"),
        h("h3", null, "Device Connection"),
      ),
      h(StatusPill, { online: device?.online, label: device?.label }),
    ),
    h("div", { className: "device-core" },
      h("div", { className: `device-radar ${device?.online ? "online" : "offline"}` },
        h("span", null),
        h("span", null),
        h("span", null),
      ),
      h("div", null,
        h("strong", null, device?.deviceId || "ESP32-RFID-01"),
        h("p", null, device?.online ? "Heartbeat stable. RFID scans can be received now." : "Waiting for a heartbeat or scan from the ESP32."),
      ),
    ),
    h("div", { className: "sync-strip" },
      h("div", null,
        h("span", null, "Last sync"),
        h("strong", null, formatDateTime(device?.lastSeen)),
        h("small", null, formatAgo(device?.secondsSinceSeen)),
      ),
      h("div", null,
        h("span", null, "Last RFID scan"),
        h("strong", null, formatDateTime(device?.lastScanAt)),
        h("small", null, device?.lastScanMessage || "No card scan yet"),
      ),
    ),
    h("dl", { className: "device-meta" },
      h("div", null, h("dt", null, "Last UID"), h("dd", null, device?.lastUid || "None yet")),
      h("div", null, h("dt", null, "Total scans"), h("dd", null, device?.totalScans ?? 0)),
      h("div", null, h("dt", null, "API status"), h("dd", null, h(ApiPill, { online: apiOnline }))),
    ),
    h("button", { className: "btn btn-compact", type: "button", onClick: onHeartbeat, disabled: heartbeatLoading }, heartbeatLoading ? "Sending" : "Send Heartbeat"),
  );
}

export function Dashboard({ data, students: directoryStudents, loading, apiOnline, onRefresh, onToast }) {
  const [query, setQuery] = useState("");
  const [scanLoading, setScanLoading] = useState(false);
  const [heartbeatLoading, setHeartbeatLoading] = useState(false);
  const metrics = data?.metrics || {};
  const device = data?.device || {};
  const students = data?.students || [];
  const trend = data?.trend || [];
  const percentage = metrics.attendancePercentage || 0;

  if (loading && !data) {
    return h(
      "section",
      { className: "dashboard-section section-band", id: "dashboard" },
      h("div", { className: "shell" },
        h("div", { className: "dashboard-header is-loading" },
          h("div", null,
            h("span", { className: "eyebrow" }, "Live Dashboard"),
            h("h2", null, "Smart Campus Command Center"),
            h("p", null, "Preparing the attendance command center."),
          ),
        ),
        h("div", { className: "metric-grid" },
          h(SkeletonCard),
          h(SkeletonCard),
          h(SkeletonCard),
          h(SkeletonCard),
        ),
      ),
    );
  }

  async function simulateScan() {
    setScanLoading(true);
    try {
      const result = await Api.demoScan();
      await onRefresh();
      onToast?.(
        result.duplicate
          ? `${result.student.name} is already present`
          : result.updated
            ? `${result.student.name} is now marked present`
            : `${result.student.name} marked present`,
        result.duplicate ? "info" : "success",
      );
    } catch (error) {
      onToast?.(error.message || "RFID demo scan failed", "error");
    } finally {
      setScanLoading(false);
    }
  }

  async function heartbeat() {
    setHeartbeatLoading(true);
    try {
      await Api.heartbeat();
      await onRefresh();
      onToast?.("ESP32 heartbeat received", "success");
    } catch (error) {
      onToast?.(error.message || "Heartbeat failed", "error");
    } finally {
      setHeartbeatLoading(false);
    }
  }

  return h(
    "section",
    { className: "dashboard-section section-band", id: "dashboard" },
    h("div", { className: "shell" },
      h("div", { className: "dashboard-header", "data-reveal": true },
        h("div", null,
          h("span", { className: "eyebrow" }, "Live Dashboard"),
          h("h2", null, "Attendance"),
          h("p", null, `${formatFullDate(data?.date)} · ${metrics.totalStudents || 0} students · ${metrics.present || 0} present · ${metrics.absent || 0} absent · ${percentage}% attendance`),
        ),
        h("div", { className: "dashboard-actions" },
          h("button", { className: "btn btn-secondary", type: "button", onClick: onRefresh, disabled: loading }, loading ? "Refreshing" : "Refresh Data"),
          h("button", { className: "btn btn-primary", type: "button", onClick: simulateScan, disabled: scanLoading }, scanLoading ? "Scanning" : "Simulate RFID Scan"),
        ),
      ),
      h("div", { className: "dashboard-meta", "data-reveal": true },
        h("span", null, "Generated ", h("strong", null, formatDateTime(data?.generatedAt))),
        h("span", null, "API ", h(ApiPill, { online: apiOnline })),
        h("span", null, "Device timeout ", h("strong", null, `${device.timeoutSeconds || 45}s`)),
      ),
      h("div", { className: "metric-grid", "data-reveal": true },
        h(MetricCard, { label: "Total Students", value: metrics.totalStudents ?? 0, detail: "Registered cards", tone: "blue" }),
        h(MetricCard, { label: "Present Today", value: metrics.present ?? 0, detail: "Verified RFID scans", tone: "green" }),
        h(MetricCard, { label: "Absent Today", value: metrics.absent ?? 0, detail: "Awaiting scan", tone: "amber" }),
        h(MetricCard, { label: "Attendance Rate", value: `${percentage}%`, detail: "Live class average", tone: "violet" }),
        h(MetricCard, { label: "RFID Scans", value: device?.totalScans ?? 0, detail: "Hardware scan counter", tone: "cyan" }),
        h(MetricCard, { label: "Recent Activity", value: metrics.recentScans ?? 0, detail: "Latest feed events", tone: "green" }),
      ),
      h(ReadinessPanel, { data, apiOnline }),
      h("div", { className: "analytics-layout", "data-reveal": true },
        h("div", { className: "attendance-summary" },
          h("div", { className: "panel-heading" },
            h("div", null,
              h("span", { className: "eyebrow mini" }, "Today"),
              h("h3", null, "Attendance Completion"),
            ),
            h("strong", null, `${percentage}%`),
          ),
          h(ProgressBar, { value: percentage }),
          h("p", null, `${metrics.present || 0} of ${metrics.totalStudents || 0} students are marked present for ${data?.date || "today"}.`),
        ),
        h(AttendanceChart, { trend, total: metrics.totalStudents || 1 }),
        h(DevicePanel, { device, apiOnline, onHeartbeat: heartbeat, heartbeatLoading }),
      ),
      h("div", { className: "dashboard-lower", "data-reveal": true },
        h("div", { className: "table-panel" },
          h("div", { className: "panel-heading table-heading" },
            h("div", null,
              h("span", { className: "eyebrow mini" }, "Students"),
              h("h3", null, "Live Attendance Table"),
            ),
            h("label", { className: "search-box" },
              h("span", null, "Search"),
              h("input", {
                value: query,
                onInput: (event) => setQuery(event.target.value),
                placeholder: "Name, roll, UID, status",
              }),
            ),
          ),
          h(TodayTable, { students, query }),
        ),
        h(RecentScans, { scans: data?.recentScans || [] }),
      ),
      h("div", { className: "dashboard-secondary-grid", "data-reveal": true },
        h(StatusDistribution, { metrics }),
        h(StudentSignals, { students: directoryStudents || [] }),
      ),
    ),
  );
}
