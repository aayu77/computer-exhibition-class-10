import { Api } from "../api.js";

const { createElement: h, useState } = window.React;

export function AuthGate({ onAuthenticated, onToast, allowSignup = false }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ username: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  function update(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function submit(event) {
    event.preventDefault();
    const username = form.username.trim();
    const password = form.password;
    if (!username || !password) {
      onToast?.("Username and password are required", "error");
      return;
    }
    if (mode === "signup" && username.length < 3) {
      onToast?.("Username must be at least 3 characters", "error");
      return;
    }
    if (mode === "signup" && password.length < 5) {
      onToast?.("Password must be at least 5 characters", "error");
      return;
    }
    setLoading(true);
    try {
      const result = mode === "login" ? await Api.login({ username, password }) : await Api.signup({ username, password });
      onToast?.(mode === "login" ? "Login successful" : "Admin account created", "success");
      onAuthenticated(result.account || result.admin);
    } catch (error) {
      onToast?.(error.message || "Authentication failed", "error");
    } finally {
      setLoading(false);
    }
  }

  return h(
    "main",
    { className: "auth-page" },
    h("div", { className: "auth-orbit", "aria-hidden": true }),
    h("div", { className: "auth-float auth-float-a", "aria-hidden": true }, "RFID"),
    h("div", { className: "auth-float auth-float-b", "aria-hidden": true }, "ESP32"),
    h("div", { className: "auth-float auth-float-c", "aria-hidden": true }, "API"),
    h("section", { className: "auth-shell" },
      h("div", { className: "auth-story" },
        h("span", { className: "eyebrow" }, "Smart Campus Admin"),
        h("h1", null, "Control attendance like a real IoT platform."),
        h("p", null, "Secure access for the Smart RFID Attendance Management System. Manage students, verify ESP32 scans, mark attendance, and export reports from one polished command center."),
        h("div", { className: "auth-proof" },
          h("span", null, "RFID"),
          h("span", null, "ESP32"),
          h("span", null, "Flask API"),
          h("span", null, "SQLite"),
        ),
      ),
      h("form", { className: "auth-card", onSubmit: submit, autoComplete: "off" },
        h("span", { className: "eyebrow mini" }, mode === "login" ? "Admin Login" : "Create Admin"),
        h("h2", null, mode === "login" ? "Welcome back" : "Create secure access"),
        h("div", { className: "auth-field" },
          h("label", { htmlFor: "auth-username" }, "Username"),
          h("input", {
            id: "auth-username",
            value: form.username,
            "aria-label": "Username",
            autoComplete: "off",
            onInput: (event) => update("username", event.target.value),
            placeholder: "Enter username",
          }),
        ),
        h("div", { className: "auth-field" },
          h("label", { htmlFor: "auth-password" }, "Password"),
          h("div", { className: "password-field" },
            h("input", {
              id: "auth-password",
              value: form.password,
              "aria-label": "Password",
              type: showPassword ? "text" : "password",
              autoComplete: "off",
              onInput: (event) => update("password", event.target.value),
              placeholder: "Enter password",
            }),
            h("button", {
              type: "button",
              className: "password-toggle",
              onClick: () => setShowPassword((value) => !value),
              "aria-label": showPassword ? "Hide password" : "Show password",
            }, showPassword ? "Hide" : "Show"),
          ),
        ),
        h("button", { type: "submit", className: "btn btn-primary", disabled: loading }, loading ? "Checking" : mode === "login" ? "Open Dashboard" : "Create Account"),
        h("button", {
          type: "button",
          className: "auth-switch",
          disabled: loading || (!allowSignup && mode === "login"),
          onClick: () => {
            if (!allowSignup && mode === "login") return;
            setMode(mode === "login" ? "signup" : "login");
            setForm({ username: "", password: "" });
            setShowPassword(false);
          },
        }, mode === "login" ? (allowSignup ? "Create a new admin account" : "Admin signup locked") : "I already have an account"),
        h("p", { className: "auth-hint" }, mode === "login" ? (allowSignup ? "Create the first private admin account for exhibition setup." : "Use an existing configured admin account.") : "Use a private password for exhibition setup."),
      ),
    ),
  );
}
