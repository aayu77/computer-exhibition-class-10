import { Api } from "../api.js";
import { explainerCards, featureCards, learningBlocks } from "../data.js";
import { EmptyState, MetricCard, ProgressBar, SectionTitle, StatusPill } from "./ui.js";
import { Conclusion, Explainers, ProjectExplanation, Team, WorkflowTimeline } from "./Sections.js";

const { createElement: h, useEffect, useMemo, useRef, useState } = window.React;

function today() {
  return new Date().toISOString().slice(0, 10);
}

function normalizeUid(value) {
  const compact = String(value || "").trim().toUpperCase().replaceAll("-", ":").replaceAll(" ", "");
  if (compact.includes(":") || compact.length <= 2) return compact;
  return compact.match(/.{1,2}/g)?.join(":") || compact;
}

function isValidUid(value) {
  return /^[0-9A-F]{2}(:[0-9A-F]{2}){3,9}$/.test(normalizeUid(value));
}

function formatDateTime(value) {
  if (!value) return "No activity yet";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function useDebouncedValue(value, delay = 240) {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), delay);
    return () => window.clearTimeout(timer);
  }, [value, delay]);

  return debounced;
}

function formatNumber(value) {
  return Number(value || 0).toLocaleString();
}

function formatPercent(value) {
  return `${Number(value || 0).toFixed(Number(value || 0) % 1 ? 1 : 0)}%`;
}

export function AdminOverview({ data, students, clock, onRefresh, onToast }) {
  const [manualUid, setManualUid] = useState("");
  const metrics = data?.metrics || {};
  const device = data?.device || {};
  const latest = data?.recentScans?.[0];
  const now = clock || new Date();

  async function submitUid(event) {
    event.preventDefault();
    if (!manualUid.trim()) {
      onToast?.("Enter an RFID UID first", "error");
      return;
    }
    try {
      const result = await Api.rfidAttendance(manualUid);
      if (result.matched) {
        onToast?.(
          result.duplicate
            ? `${result.student.name} is already present`
            : result.updated
              ? `${result.student.name} is now marked Present`
              : `${result.student.name} marked Present by RFID`,
          result.duplicate ? "info" : "success",
        );
      } else {
        onToast?.("Unknown RFID Tag", "error");
      }
      setManualUid("");
      await onRefresh();
    } catch (error) {
      onToast?.(error.message || "RFID mark failed", "error");
    }
  }

  return h(
    "section",
    { className: "admin-page" },
      h("div", { className: "admin-hero-card" },
      h("div", null,
        h("span", { className: "eyebrow" }, "Admin Dashboard"),
        h("h1", null, "Attendance control center"),
        h("p", null, "Manage RFID scans, manual attendance, device health, reports, and student records from one premium command surface."),
      ),
      h("div", { className: "live-clock-card" },
        h("span", null, "Live time"),
        h("strong", null, now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })),
        h("small", null, now.toLocaleDateString([], { weekday: "short", year: "numeric", month: "short", day: "numeric" })),
        h("em", null, `${students.length} RFID tags · ${data?.visits?.total ?? 0} visits`),
      ),
    ),
    !device?.online
      ? h("div", { className: "offline-banner" },
          h("strong", null, "RFID device is offline."),
          h("span", null, "Manual attendance is still available."),
        )
      : null,
    h("div", { className: "admin-stat-grid" },
      h("article", null, h("span", null, "Total Students"), h("strong", null, metrics.totalStudents ?? 0), h("small", null, "registered")),
      h("article", null, h("span", null, "Present Today"), h("strong", null, metrics.present ?? 0), h("small", null, "on time")),
      h("article", null, h("span", null, "Late Today"), h("strong", null, metrics.late ?? 0), h("small", null, "late arrivals")),
      h("article", null, h("span", null, "Absent Today"), h("strong", null, metrics.absent ?? 0), h("small", null, "not marked")),
    ),
    h("div", { className: "admin-grid-2" },
      h("article", { className: "admin-panel" },
        h("div", { className: "panel-heading" },
          h("div", null, h("span", { className: "eyebrow mini" }, "Device/API"), h("h3", null, "Live Connection")),
          h(StatusPill, { online: device?.online, label: device?.label }),
        ),
        h("div", { className: "device-readout" },
          h("div", null, h("span", null, "API"), h("strong", null, device?.apiStatus || "Connected")),
          h("div", null, h("span", null, "Latest RFID"), h("strong", null, latest?.rfidUid || "Waiting")),
          h("div", null, h("span", null, "Latest scan"), h("strong", null, latest?.studentName || "No scan yet"), h("small", null, latest?.message || "No RFID activity yet")),
        ),
      ),
      h("form", { className: "admin-panel rfid-form", onSubmit: submitUid },
        h("span", { className: "eyebrow mini" }, "RFID Manual Input"),
        h("h3", null, "Mark using RFID tag"),
        h("p", null, "Paste or type a UID to simulate the ESP32 scan flow. Known cards mark Present automatically."),
        h("div", { className: "inline-form" },
          h("input", {
            value: manualUid,
            onInput: (event) => setManualUid(event.target.value),
            placeholder: "04:A7:2C:91",
          }),
          h("button", { className: "btn btn-primary" }, "Mark RFID"),
        ),
      ),
    ),
    h("article", { className: "admin-panel" },
      h("div", { className: "panel-heading" },
        h("div", null, h("span", { className: "eyebrow mini" }, "Recent Attendance"), h("h3", null, "Latest activity")),
        h("button", { className: "btn btn-compact", onClick: onRefresh }, "Refresh"),
      ),
      h(RecentAttendanceTable, { rows: data?.students || [] }),
    ),
  );
}

function RecentAttendanceTable({ rows }) {
  return rows?.length
    ? h("div", { className: "table-wrap" },
        h("table", { className: "attendance-table" },
          h("thead", null, h("tr", null, h("th", null, "Roll"), h("th", null, "Student"), h("th", null, "Status"), h("th", null, "Time"), h("th", null, "Source"))),
          h("tbody", null, rows.map((row) =>
            h("tr", { key: row.id },
              h("td", { "data-label": "Roll" }, row.rollNo),
              h("td", { "data-label": "Student" }, row.name),
              h("td", { "data-label": "Status" }, h("span", { className: `row-status ${row.status.toLowerCase()}` }, row.status)),
              h("td", { "data-label": "Time" }, row.checkInTime || "Not marked"),
              h("td", { "data-label": "Source" }, row.source || "System"),
            ),
          )),
        ),
      )
    : h(EmptyState, { title: "No students", copy: "Add students to start attendance tracking." });
}

export function StudentsPage({ students, data, device, onChanged, onToast }) {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebouncedValue(query);
  const [statusFilter, setStatusFilter] = useState("");
  const [sortBy, setSortBy] = useState("roll");
  const [form, setForm] = useState({ name: "", rollNo: "", rfidUid: "", className: "X-A" });
  const [manualUid, setManualUid] = useState("");
  const [rfidEnrollment, setRfidEnrollment] = useState({
    phase: "ready",
    uid: "",
    title: "RFID CARD",
    message: "Tap an RFID card on the connected reader.",
  });
  const [validatingUid, setValidatingUid] = useState(false);
  const [adding, setAdding] = useState(false);
  const [confirmStudent, setConfirmStudent] = useState(null);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [studentDetail, setStudentDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ name: "", rollNo: "", rfidUid: "", className: "", active: true });
  const [savingEdit, setSavingEdit] = useState(false);
  const [accountForm, setAccountForm] = useState({ username: "", password: "" });
  const [creatingAccount, setCreatingAccount] = useState(false);
  const [managingAccount, setManagingAccount] = useState(false);
  const scanTimerRef = useRef(0);
  const filtered = useMemo(() => {
    const term = debouncedQuery.trim().toLowerCase();
    const rows = students.filter((student) => {
      const matchesTerm = !term || [student.name, student.rollNo, student.rfidUid, student.className, student.todayStatus].some((value) => String(value || "").toLowerCase().includes(term));
      const rfidReady = Boolean(student.rfidUid);
      const matchesStatus =
        !statusFilter ||
        (statusFilter === "RFID Registered" && rfidReady) ||
        (statusFilter === "RFID Not Registered" && !rfidReady) ||
        (student.todayStatus || "Absent") === statusFilter;

      return matchesTerm && matchesStatus;
    });

    return [...rows].sort((a, b) => {
      if (sortBy === "name") return String(a.name).localeCompare(String(b.name));
      if (sortBy === "status") return String(a.todayStatus || "Absent").localeCompare(String(b.todayStatus || "Absent"));
      if (sortBy === "attendance") return Number(b.attendancePercentage || 0) - Number(a.attendancePercentage || 0);
      return String(a.rollNo).localeCompare(String(b.rollNo), undefined, { numeric: true });
    });
  }, [students, debouncedQuery, statusFilter, sortBy]);
  const todayCounts = useMemo(() => {
    return students.reduce(
      (counts, student) => {
        const currentStatus = student.todayStatus || "Absent";
        return {
          ...counts,
          [currentStatus]: (counts[currentStatus] || 0) + 1,
        };
      },
      { Present: 0, Late: 0, Absent: 0 },
    );
  }, [students]);
  const rfidRegistered = useMemo(
    () => students.filter((student) => Boolean(student.rfidUid)).length,
    [students],
  );
  const averageAttendance = useMemo(() => {
    if (!students.length) return 0;
    const total = students.reduce((sum, student) => sum + Number(student.attendancePercentage || 0), 0);
    return total / students.length;
  }, [students]);
  const registrationErrors = useMemo(() => {
    const errors = [];
    const normalizedUid = normalizeUid(form.rfidUid);
    if (!form.name.trim()) errors.push("Student name is required.");
    if (!form.rollNo.trim()) errors.push("Roll number is required.");
    if (!form.className.trim()) errors.push("Class is required.");
    if (!normalizedUid || rfidEnrollment.phase !== "assigned") errors.push("Assign a verified RFID card.");
    if (normalizedUid && !isValidUid(normalizedUid)) errors.push("RFID UID format is invalid.");
    if (students.some((student) => String(student.rollNo).trim().toLowerCase() === form.rollNo.trim().toLowerCase())) errors.push("This roll number is already registered.");
    if (normalizedUid && students.some((student) => normalizeUid(student.rfidUid) === normalizedUid)) errors.push("This RFID UID is already registered.");
    return errors;
  }, [form, rfidEnrollment.phase, students]);
  const canRegister = registrationErrors.length === 0 && !adding;

  useEffect(() => {
    let active = true;

    if (!selectedStudent) {
      setStudentDetail(null);
      return () => {
        active = false;
      };
    }

    setDetailLoading(true);
    Api.student(selectedStudent.id, { preset: "all" })
      .then((result) => {
        if (active) setStudentDetail(result);
      })
      .catch((error) => onToast?.(error.message || "Student details failed", "error"))
      .finally(() => {
        if (active) setDetailLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedStudent?.id]);

  useEffect(() => {
    if (!selectedStudent) {
      setEditing(false);
      return;
    }

    setEditForm({
      name: selectedStudent.name || "",
      rollNo: selectedStudent.rollNo || "",
      rfidUid: selectedStudent.rfidUid || "",
      className: selectedStudent.className || "",
      active: selectedStudent.active !== false,
    });
    setAccountForm({
      username: selectedStudent.rollNo || "",
      password: "",
    });
    setEditing(false);
  }, [selectedStudent?.id]);

  useEffect(() => {
    if (studentDetail?.account) {
      setAccountForm({
        username: studentDetail.account.username || "",
        password: "",
      });
    }
  }, [studentDetail?.account?.id]);

  useEffect(() => {
    function closeOnEscape(event) {
      if (event.key === "Escape" && selectedStudent) {
        setSelectedStudent(null);
      }
    }

    document.addEventListener("keydown", closeOnEscape);
    return () => document.removeEventListener("keydown", closeOnEscape);
  }, [selectedStudent]);

  useEffect(() => {
    return () => {
      window.clearInterval(scanTimerRef.current);
    };
  }, []);

  function stopScan() {
    window.clearInterval(scanTimerRef.current);
    scanTimerRef.current = 0;
  }

  function update(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  function resetRfidEnrollment() {
    stopScan();
    setManualUid("");
    setForm((current) => ({ ...current, rfidUid: "" }));
    setRfidEnrollment({
      phase: "ready",
      uid: "",
      title: "RFID CARD",
      message: "Tap an RFID card on the connected reader.",
    });
  }

  async function verifyRfidUid(rawUid, source = "manual", scan = null) {
    const uid = normalizeUid(rawUid);

    if (!uid) {
      setRfidEnrollment({
        phase: "invalid",
        uid: "",
        title: "INVALID UID",
        message: "Enter or scan an RFID UID first.",
      });
      return;
    }

    setValidatingUid(true);

    try {
      const result = await Api.validateRfidUid(uid);
      const normalized = result.uid || uid;

      setManualUid(normalized);
      setRfidEnrollment({
        phase: "detected",
        uid: normalized,
        title: "RFID CARD DETECTED",
        message: "RFID card is ready to be assigned.",
        scan,
      });

      if (source === "manual") {
        onToast?.("RFID UID verified by backend", "success");
      }
    } catch (error) {
      const duplicate = error?.status === 409;
      const student = error?.detail?.student;

      setRfidEnrollment({
        phase: duplicate ? "duplicate" : error?.code === "TIMEOUT" ? "timeout" : "invalid",
        uid,
        title: duplicate ? "RFID ALREADY REGISTERED" : "RFID UID NOT READY",
        message: duplicate && student
          ? `Already assigned to roll ${student.rollNo} · ${student.name}.`
          : error.message || "RFID UID could not be verified.",
        student,
      });

      onToast?.(error.message || "RFID validation failed", duplicate ? "warning" : "error");
    } finally {
      setValidatingUid(false);
    }
  }

  async function startRfidScan() {
    stopScan();

    if (device && device.online === false) {
      setRfidEnrollment({
        phase: "offline",
        uid: "",
        title: "RFID READER OFFLINE",
        message: "The reader hasn't reported a connection recently.",
      });
      onToast?.("RFID reader is offline", "error");
      return;
    }

    setRfidEnrollment({
      phase: "scanning",
      uid: "",
      title: "SCANNING",
      message: "Waiting for RFID card...",
    });

    let baselineId = null;

    try {
      const latest = await Api.latestScan();
      baselineId = latest.scan?.id ?? null;
    } catch (error) {
      setRfidEnrollment({
        phase: "api-error",
        uid: "",
        title: "RFID API UNAVAILABLE",
        message: error.message || "Unable to read latest RFID scans.",
      });
      onToast?.(error.message || "RFID scan could not start", "error");
      return;
    }

    const startedAt = Date.now();

    scanTimerRef.current = window.setInterval(async () => {
      if (Date.now() - startedAt > 20000) {
        stopScan();
        setRfidEnrollment({
          phase: "timeout",
          uid: "",
          title: "RFID SCAN TIMED OUT",
          message: "No new RFID card reached the backend. Check ESP32 power and Wi-Fi, then try again.",
        });
        onToast?.("RFID scan timed out", "warning");
        return;
      }

      try {
        const latest = await Api.latestScan();
        const scan = latest.scan;
        if (!scan || scan.id === baselineId) return;

        stopScan();
        await verifyRfidUid(scan.rfidUid, "scan", scan);
      } catch (error) {
        stopScan();
        setRfidEnrollment({
          phase: "api-error",
          uid: "",
          title: "RFID API FAILURE",
          message: error.message || "Unable to read RFID scan results.",
        });
        onToast?.(error.message || "RFID polling failed", "error");
      }
    }, 1200);
  }

  function assignDetectedRfid() {
    if (!rfidEnrollment.uid) {
      onToast?.("Scan or verify a UID first", "error");
      return;
    }

    setForm((current) => ({ ...current, rfidUid: rfidEnrollment.uid }));
    setRfidEnrollment((current) => ({
      ...current,
      phase: "assigned",
      title: "RFID READY",
      message: "The UID is attached to this registration form.",
    }));
    onToast?.("RFID attached to student form", "success");
  }

  async function addStudent(event) {
    event.preventDefault();
    if (!canRegister) {
      onToast?.(registrationErrors[0] || "Complete registration before saving", "error");
      return;
    }

    setAdding(true);

    try {
      const verified = await Api.validateRfidUid(form.rfidUid);
      const result = await Api.addStudent({ ...form, rfidUid: verified.uid || normalizeUid(form.rfidUid) });
      onToast?.(`${result.student.name} registered successfully`, "success");
      setForm({ name: "", rollNo: "", rfidUid: "", className: "X-A" });
      setManualUid("");
      setRfidEnrollment({
        phase: "registered",
        uid: result.student.rfidUid,
        title: "STUDENT REGISTERED",
        message: `${result.student.name} is available for RFID attendance.`,
      });
      await onChanged();
    } catch (error) {
      if (error?.status === 409 || error?.status === 422) {
        setRfidEnrollment({
          phase: error.status === 409 ? "duplicate" : "invalid",
          uid: normalizeUid(form.rfidUid),
          title: error.status === 409 ? "RFID ALREADY REGISTERED" : "RFID UID NOT READY",
          message: error.message || "RFID validation failed.",
          student: error?.detail?.student,
        });
      }
      onToast?.(error.message || "Student could not be added", "error");
    } finally {
      setAdding(false);
    }
  }

  async function deleteStudent() {
    if (!confirmStudent) return;
    setDeleting(true);
    try {
      await Api.deleteStudent(confirmStudent.id);
      onToast?.(`${confirmStudent.name} deleted`, "success");
      if (selectedStudent?.id === confirmStudent.id) {
        setSelectedStudent(null);
      }
      setConfirmStudent(null);
      await onChanged();
    } catch (error) {
      onToast?.(error.message || "Student could not be deleted", "error");
    } finally {
      setDeleting(false);
    }
  }

  async function saveStudentEdit(event) {
    event.preventDefault();

    if (!selectedStudent || savingEdit) return;

    const normalizedUid = normalizeUid(editForm.rfidUid);

    if (!editForm.name.trim() || !editForm.rollNo.trim() || !editForm.className.trim() || !normalizedUid) {
      onToast?.("Complete all student fields before saving", "error");
      return;
    }

    if (!isValidUid(normalizedUid)) {
      onToast?.("RFID UID format is invalid", "error");
      return;
    }

    setSavingEdit(true);

    try {
      const result = await Api.updateStudent(selectedStudent.id, {
        ...editForm,
        rfidUid: normalizedUid,
        active: Boolean(editForm.active),
      });

      onToast?.(result.message || "Student updated", "success");
      setSelectedStudent((current) => ({
        ...current,
        ...(result.student || {}),
      }));
      setEditing(false);
      await onChanged();
    } catch (error) {
      onToast?.(error.message || "Student update failed", "error");
    } finally {
      setSavingEdit(false);
    }
  }

  async function createAccount(event) {
    event.preventDefault();

    if (!selectedStudent || creatingAccount) return;

    setCreatingAccount(true);

    try {
      await Api.createStudentAccount({
        studentId: selectedStudent.id,
        username: accountForm.username,
        password: accountForm.password,
      });
      onToast?.("Student account created", "success");
      setAccountForm({ username: selectedStudent.rollNo || "", password: "" });
      const refreshed = await Api.student(selectedStudent.id, { preset: "all" });
      setStudentDetail(refreshed);
    } catch (error) {
      onToast?.(error.message || "Student account could not be created", "error");
    } finally {
      setCreatingAccount(false);
    }
  }

  async function updateAccount(payload) {
    if (!studentDetail?.account || managingAccount) return;

    setManagingAccount(true);

    try {
      await Api.updateStudentAccount(studentDetail.account.id, payload);
      onToast?.("Student account updated", "success");
      setAccountForm((current) => ({ ...current, password: "" }));
      const refreshed = await Api.student(selectedStudent.id, { preset: "all" });
      setStudentDetail(refreshed);
    } catch (error) {
      onToast?.(error.message || "Student account update failed", "error");
    } finally {
      setManagingAccount(false);
    }
  }

  return h(
    "section",
    { className: "admin-page" },
    h(SectionTitle, { eyebrow: "Students", title: "Registered RFID users", copy: "Search, add, and inspect real attendance profiles for every RFID card." }),
    h("div", { className: "student-intel-strip" },
      h("article", null, h("span", null, "Directory"), h("strong", null, students.length), h("small", null, "students")),
      h("article", null, h("span", null, "RFID registered"), h("strong", null, rfidRegistered), h("small", null, `${students.length - rfidRegistered} pending`)),
      h("article", null, h("span", null, "Present today"), h("strong", null, (data?.metrics?.present ?? todayCounts.Present) + (data?.metrics?.late ?? todayCounts.Late)), h("small", null, "including late")),
      h("article", null, h("span", null, "Absent today"), h("strong", null, data?.metrics?.absent ?? todayCounts.Absent), h("small", null, "current state")),
      h("article", null, h("span", null, "Average attendance"), h("strong", null, formatPercent(averageAttendance)), h("small", null, data ? "real records" : "loading")),
    ),
    h("div", { className: "admin-grid-2" },
      h("form", { className: "admin-panel form-panel registration-workflow", onSubmit: addStudent },
        h("div", { className: "panel-heading" },
          h("div", null, h("span", { className: "eyebrow mini" }, "Registration"), h("h3", null, "Add Student")),
          h("span", { className: `registration-state ${canRegister ? "ready" : "draft"}` }, canRegister ? "Ready" : "Draft"),
        ),
        h("section", { className: "workflow-section" },
          h("div", { className: "workflow-step" }, h("span", null, "1"), h("strong", null, "Student Information")),
          h("div", { className: "form-grid-2" },
            h("label", null, h("span", null, "Name *"), h("input", { value: form.name, required: true, onInput: (event) => update("name", event.target.value), placeholder: "Student name", "aria-invalid": !form.name.trim() })),
            h("label", null, h("span", null, "Roll Number *"), h("input", { value: form.rollNo, required: true, onInput: (event) => update("rollNo", event.target.value), placeholder: "13", "aria-invalid": registrationErrors.includes("This roll number is already registered.") })),
            h("label", null, h("span", null, "Class *"), h("input", { value: form.className, required: true, onInput: (event) => update("className", event.target.value), placeholder: "X-A" })),
          ),
        ),
        h("section", { className: "workflow-section" },
          h("div", { className: "workflow-step" }, h("span", null, "2"), h("strong", null, "RFID Enrollment")),
          h("div", { className: `rfid-enrollment-card ${rfidEnrollment.phase}`, role: ["duplicate", "invalid", "timeout", "offline", "api-error"].includes(rfidEnrollment.phase) ? "alert" : "status", "aria-live": "polite" },
            h("div", { className: "rfid-visual", "aria-hidden": true },
              h("span", null),
              h("i", null),
              h("b", null),
            ),
            h("div", { className: "rfid-enrollment-copy" },
              h("span", { className: "eyebrow mini" }, rfidEnrollment.phase === "assigned" ? "Assigned" : rfidEnrollment.phase === "detected" ? "Detected" : rfidEnrollment.phase === "scanning" ? "Scanning" : "RFID Card"),
              h("h4", null, rfidEnrollment.title),
              h("p", null, rfidEnrollment.message),
              rfidEnrollment.uid ? h("code", null, rfidEnrollment.uid) : null,
            ),
            h("div", { className: "rfid-enrollment-actions" },
              h("button", { className: "btn btn-primary", type: "button", disabled: rfidEnrollment.phase === "scanning" || validatingUid, onClick: startRfidScan }, rfidEnrollment.phase === "scanning" ? "Waiting..." : "Scan RFID"),
              rfidEnrollment.phase === "detected"
                ? h("button", { className: "btn btn-secondary", type: "button", onClick: assignDetectedRfid }, "Use RFID")
                : null,
              form.rfidUid || rfidEnrollment.phase !== "ready"
                ? h("button", { className: "btn btn-secondary", type: "button", onClick: resetRfidEnrollment }, "Reset RFID")
                : null,
            ),
          ),
          h("div", { className: "manual-rfid-box" },
            h("label", null, h("span", null, "Enter RFID UID manually"), h("input", { value: manualUid, onInput: (event) => setManualUid(event.target.value), placeholder: "53:25:15:2C:02:00:01", "aria-invalid": manualUid ? !isValidUid(manualUid) : undefined })),
            h("button", { className: "btn btn-secondary", type: "button", disabled: validatingUid || !manualUid.trim(), onClick: () => verifyRfidUid(manualUid, "manual") }, validatingUid ? "Checking..." : "Verify UID"),
          ),
        ),
        h("section", { className: "workflow-section registration-summary" },
          h("div", { className: "workflow-step" }, h("span", null, "3"), h("strong", null, "Registration Summary")),
          h("div", { className: "summary-grid" },
            h("div", null, h("span", null, "Student"), h("strong", null, form.name.trim() || "Not entered")),
            h("div", null, h("span", null, "Student ID / Roll"), h("strong", null, form.rollNo.trim() || "Not entered")),
            h("div", null, h("span", null, "Class"), h("strong", null, form.className.trim() || "Not entered")),
            h("div", null, h("span", null, "RFID status"), h("strong", null, rfidEnrollment.phase === "registered" ? "Registered" : rfidEnrollment.phase === "assigned" ? "Assigned" : rfidEnrollment.phase === "detected" ? "Detected" : "Not assigned")),
            h("div", null, h("span", null, "UID"), h("strong", null, form.rfidUid || rfidEnrollment.uid || "Waiting")),
            h("div", null, h("span", null, "Validation"), h("strong", null, registrationErrors.length ? "Needs attention" : "Passed")),
          ),
          registrationErrors.length
            ? h("div", { className: "inline-error compact", role: "alert" }, registrationErrors[0])
            : h("div", { className: "inline-success", role: "status" }, "Ready to register this student."),
        ),
        h("div", { className: "registration-actions" },
          h("button", { className: "btn btn-secondary", type: "button", disabled: adding, onClick: () => {
            setForm({ name: "", rollNo: "", rfidUid: "", className: "X-A" });
            resetRfidEnrollment();
          } }, "Cancel"),
          h("button", { className: "btn btn-primary", disabled: !canRegister }, adding ? "Registering..." : "Register Student"),
        ),
      ),
      h("article", { className: "admin-panel" },
        h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Directory"), h("h3", null, "All Students")), h("strong", null, filtered.length)),
        h("div", { className: "filter-grid student-filters" },
          h("label", { className: "search-box wide" }, h("span", null, "Search"), h("input", { value: query, onInput: (event) => setQuery(event.target.value), placeholder: "Name, roll, UID" })),
          h("label", null, h("span", null, "Status"), h("select", { value: statusFilter, onInput: (event) => setStatusFilter(event.target.value) },
            h("option", { value: "" }, "All"),
            ["RFID Registered", "RFID Not Registered", "Present", "Late", "Absent"].map((item) => h("option", { value: item, key: item }, item)),
          )),
          h("label", null, h("span", null, "Sort"), h("select", { value: sortBy, onInput: (event) => setSortBy(event.target.value) },
            h("option", { value: "roll" }, "Roll number"),
            h("option", { value: "name" }, "Name"),
            h("option", { value: "status" }, "Status"),
            h("option", { value: "attendance" }, "Attendance"),
          )),
        ),
        h("div", { className: "student-list" },
          filtered.map((student) =>
            h("article", { className: "student-row", key: student.id },
              h("button", { className: "student-row-main", type: "button", onClick: () => setSelectedStudent(student) },
                h("span", { className: "student-row-top" },
                  h("strong", null, student.name),
                  h("span", { className: `row-status ${(student.todayStatus || "Absent").toLowerCase()}` }, student.todayStatus || "Absent"),
                ),
                h("small", null, `Roll ${student.rollNo} · ${student.className} · UID ${student.rfidUid}`),
                h("span", { className: "student-row-meta" },
                  h("em", null, student.rfidUid ? "RFID registered" : "RFID pending"),
                  h("em", null, `${formatPercent(student.attendancePercentage)} attendance`),
                  h("em", null, student.lastAttendance ? `Last ${student.lastAttendance.status} · ${student.lastAttendance.date}` : "No attendance history"),
                ),
              ),
              h("button", { className: "danger-btn", type: "button", onClick: () => setConfirmStudent(student) }, "Delete"),
            ),
          ),
          !filtered.length
            ? h(EmptyState, { title: "No matching students", copy: "Search by name, roll number, class, or RFID UID." })
            : null,
        ),
      ),
    ),
    selectedStudent
      ? h("article", { className: "admin-panel student-detail-panel", role: "dialog", "aria-modal": "false", "aria-label": "Student profile" },
          h("div", { className: "panel-heading" },
            h("div", null, h("span", { className: "eyebrow mini" }, "Student Details"), h("h3", null, selectedStudent.name)),
            h("div", { className: "panel-actions" },
              h("button", { className: "btn btn-compact", type: "button", onClick: () => setEditing((value) => !value) }, editing ? "View" : "Edit"),
              h("button", { className: "btn btn-compact", type: "button", onClick: () => setSelectedStudent(null) }, "Close"),
            ),
          ),
          detailLoading
            ? h(EmptyState, { title: "Loading student history", copy: "Reading this student's attendance from SQLite." })
            : editing
              ? h("form", { className: "student-edit-form", onSubmit: saveStudentEdit },
                  h("label", null, h("span", null, "Name"), h("input", { value: editForm.name, required: true, onInput: (event) => setEditForm((current) => ({ ...current, name: event.target.value })) })),
                  h("label", null, h("span", null, "Student ID / Roll"), h("input", { value: editForm.rollNo, required: true, onInput: (event) => setEditForm((current) => ({ ...current, rollNo: event.target.value })) })),
                  h("label", null, h("span", null, "Class"), h("input", { value: editForm.className, required: true, onInput: (event) => setEditForm((current) => ({ ...current, className: event.target.value })) })),
                  h("label", null, h("span", null, "RFID UID"), h("input", { value: editForm.rfidUid, required: true, onInput: (event) => setEditForm((current) => ({ ...current, rfidUid: event.target.value })), "aria-invalid": editForm.rfidUid ? !isValidUid(editForm.rfidUid) : undefined })),
                  h("label", { className: "toggle-line" }, h("input", { type: "checkbox", checked: editForm.active, onChange: (event) => setEditForm((current) => ({ ...current, active: event.target.checked })) }), h("span", null, "Student active")),
                  h("div", { className: "registration-actions" },
                    h("button", { className: "btn btn-secondary", type: "button", disabled: savingEdit, onClick: () => setEditing(false) }, "Cancel"),
                    h("button", { className: "btn btn-primary", disabled: savingEdit }, savingEdit ? "Saving..." : "Save Student"),
                  ),
                )
              : h("div", { className: "student-detail-grid" },
                  h("div", null, h("span", null, "Roll"), h("strong", null, selectedStudent.rollNo)),
                  h("div", null, h("span", null, "Class"), h("strong", null, selectedStudent.className)),
                  h("div", null, h("span", null, "RFID"), h("strong", null, selectedStudent.rfidUid)),
                  h("div", null, h("span", null, "Student status"), h("strong", null, selectedStudent.active === false ? "Disabled" : "Active")),
                  h("div", null, h("span", null, "Account status"), h("strong", null, studentDetail?.account ? (studentDetail.account.active ? "Active" : "Disabled") : "No account")),
                  h("div", null, h("span", null, "Attendance"), h("strong", null, formatPercent(studentDetail?.summary?.attendancePercentage))),
                  h("div", null, h("span", null, "Total present"), h("strong", null, studentDetail?.summary?.presentDays ?? 0)),
                  h("div", null, h("span", null, "Total absent"), h("strong", null, studentDetail?.summary?.absentDays ?? 0)),
                  h("div", null, h("span", null, "Today"), h("strong", null, selectedStudent.todayStatus || "Absent")),
                  h("div", null, h("span", null, "Last mark"), h("strong", null, selectedStudent.lastAttendance ? `${selectedStudent.lastAttendance.status} · ${selectedStudent.lastAttendance.date}` : "No history")),
                ),
          !detailLoading && studentDetail?.history?.length
            ? h("div", { className: "history-list compact" },
                studentDetail.history.slice(0, 12).map((record) =>
                  h("article", { className: `history-item ${record.status.toLowerCase()}`, key: record.id },
                    h("span", null, record.status),
                    h("div", null,
                      h("strong", null, record.date),
                      h("small", null, `${record.time || "No time"} · ${record.source}`),
                    ),
                    h("code", null, record.rfidUid),
                  ),
                ),
              )
            : !detailLoading
              ? h(EmptyState, { title: "No attendance history", copy: "This student has no records in the current database yet." })
              : null,
          !detailLoading
            ? h("form", { className: "student-account-form", onSubmit: createAccount },
                h("div", { className: "panel-heading compact-heading" },
                  h("div", null, h("span", { className: "eyebrow mini" }, "Account"), h("h3", null, studentDetail?.account ? "Manage student login" : "Create student login")),
                ),
                h("div", { className: "form-grid-2" },
                  h("label", null, h("span", null, "Username"), h("input", { value: accountForm.username, onInput: (event) => setAccountForm((current) => ({ ...current, username: event.target.value })) })),
                  h("label", null, h("span", null, studentDetail?.account ? "New password" : "Temporary password"), h("input", { type: "password", value: accountForm.password, onInput: (event) => setAccountForm((current) => ({ ...current, password: event.target.value })) })),
                ),
                studentDetail?.account
                  ? h("div", { className: "manual-actions" },
                      h("button", { className: "btn btn-secondary", type: "button", disabled: managingAccount, onClick: () => updateAccount({ username: accountForm.username, password: accountForm.password }) }, managingAccount ? "Saving..." : "Save Account"),
                      h("button", { className: "btn btn-secondary", type: "button", disabled: managingAccount, onClick: () => updateAccount({ active: !studentDetail.account.active }) }, studentDetail.account.active ? "Disable Account" : "Enable Account"),
                    )
                  : h("button", { className: "btn btn-secondary", disabled: creatingAccount }, creatingAccount ? "Creating..." : "Create Account"),
              )
            : null,
          !detailLoading && studentDetail?.recentScans?.length
            ? h("div", { className: "history-list compact" },
                studentDetail.recentScans.slice(0, 6).map((scan) =>
                  h("article", { className: `history-item ${scan.status}`, key: scan.id },
                    h("span", null, scan.status),
                    h("div", null,
                      h("strong", null, scan.message || "RFID scan"),
                      h("small", null, `${scan.deviceId} · ${scan.createdAt}`),
                    ),
                    h("code", null, scan.rfidUid),
                  ),
                ),
              )
            : null,
          !detailLoading && studentDetail?.editRequests?.length
            ? h("div", { className: "history-list compact" },
                studentDetail.editRequests.slice(0, 6).map((request) =>
                  h("article", { className: `history-item ${request.status.toLowerCase()}`, key: request.id },
                    h("span", null, request.status),
                    h("div", null,
                      h("strong", null, request.fieldName),
                      h("small", null, `${request.currentValue || "-"} to ${request.requestedValue}`),
                    ),
                    h("code", null, request.createdAt),
                  ),
                ),
              )
            : null,
          !detailLoading
            ? h("div", { className: "report-actions compact-actions" },
                h("a", { className: "btn btn-secondary", href: Api.csvUrl({ studentId: selectedStudent.id }) }, "Download student report"),
                h("a", { className: "btn btn-secondary", href: Api.csvUrl({ studentId: selectedStudent.id, status: "Present" }) }, "Present report"),
                h("a", { className: "btn btn-secondary", href: Api.csvUrl({ studentId: selectedStudent.id, status: "Absent" }) }, "Absent report"),
              )
            : null,
        )
      : null,
    confirmStudent
      ? h(ConfirmDialog, {
          title: `Delete ${confirmStudent.name}?`,
          copy: `Roll ${confirmStudent.rollNo} will be removed only if there is no attendance history linked to this student.`,
          confirmLabel: deleting ? "Deleting..." : "Delete Student",
          busy: deleting,
          onCancel: () => (deleting ? null : setConfirmStudent(null)),
          onConfirm: deleteStudent,
        })
      : null,
  );
}

function ConfirmDialog({ title, copy, confirmLabel, busy, onCancel, onConfirm }) {
  window.React.useEffect(() => {
    function closeOnEscape(event) {
      if (event.key === "Escape") onCancel?.();
    }
    document.addEventListener("keydown", closeOnEscape);
    return () => document.removeEventListener("keydown", closeOnEscape);
  }, [onCancel]);

  return h(
    "div",
    {
      className: "confirm-backdrop",
      role: "presentation",
      onMouseDown: (event) => {
        if (event.target === event.currentTarget && !busy) onCancel?.();
      },
    },
    h("section", { className: "confirm-dialog", role: "dialog", "aria-modal": "true", "aria-labelledby": "confirm-title" },
      h("div", { className: "confirm-glyph", "aria-hidden": true }, "!"),
      h("div", null,
        h("span", { className: "eyebrow mini" }, "Confirmation"),
        h("h3", { id: "confirm-title" }, title),
        h("p", null, copy),
      ),
      h("div", { className: "confirm-actions" },
        h("button", { type: "button", className: "btn btn-secondary", disabled: busy, onClick: onCancel }, "Cancel"),
        h("button", { type: "button", className: "btn btn-danger", disabled: busy, onClick: onConfirm }, confirmLabel || "Confirm"),
      ),
    ),
  );
}

export function AttendancePage({ students, device, onChanged, onToast }) {
  const [date, setDate] = useState(today());
  const [status, setStatus] = useState("");
  const [source, setSource] = useState("");
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search);
  const [records, setRecords] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState("");
  const [manualStatus, setManualStatus] = useState("Present");
  const [marking, setMarking] = useState(false);
  const [loadingRecords, setLoadingRecords] = useState(true);
  const [recordsError, setRecordsError] = useState("");
  const selectedStudentData = useMemo(
    () => students.find((student) => String(student.id) === String(selectedStudent)),
    [students, selectedStudent],
  );
  const selectedAttendanceRecord = useMemo(
    () => records.find((record) => String(record.studentId) === String(selectedStudent)),
    [records, selectedStudent],
  );
  const selectableStudents = useMemo(() => {
    const term = debouncedSearch.trim().toLowerCase();
    if (!term) return students;
    return students.filter((student) =>
      [student.name, student.rollNo, student.rfidUid, student.className].some((value) =>
        String(value || "").toLowerCase().includes(term),
      ),
    );
  }, [students, debouncedSearch]);

  async function loadRecords() {
    setLoadingRecords(true);
    setRecordsError("");
    try {
      const result = await Api.attendanceRecords({ date, status, source, search: debouncedSearch, includeRoster: 1 });
      setRecords(result.records || []);
    } catch (error) {
      setRecordsError(error.message || "Attendance records failed");
      onToast?.(error.message || "Attendance records failed", "error");
    } finally {
      setLoadingRecords(false);
    }
  }

  window.React.useEffect(() => {
    loadRecords();
  }, [date, status, source, debouncedSearch]);

  async function mark(nextStatus = manualStatus) {
    if (marking) return;

    if (!selectedStudent) {
      onToast?.("Select a student first", "error");
      return;
    }

    setManualStatus(nextStatus);
    setMarking(true);

    try {
      const result = await Api.markAttendance({ studentId: selectedStudent, status: nextStatus, date });
      onToast?.(result.message, result.alreadyMarked ? "info" : "success");
      await loadRecords();
      await onChanged();
    } catch (error) {
      onToast?.(error.message || "Attendance mark failed", "error");
    } finally {
      setMarking(false);
    }
  }

  return h(
    "section",
    { className: "admin-page" },
    h(SectionTitle, { eyebrow: "Attendance", title: "Manual and RFID attendance", copy: "Mark Present, Absent, or Late while preserving duplicate-safe daily records." }),
    !device?.online
      ? h("div", { className: "offline-banner" },
          h("strong", null, "RFID device is offline."),
          h("span", null, "Manual attendance is still available."),
        )
      : null,
    h("div", { className: "admin-grid-2" },
      h("article", { className: "admin-panel form-panel" },
        h("h3", null, "Mark Attendance"),
        h("label", null, h("span", null, "Date"), h("input", { type: "date", value: date, onInput: (event) => setDate(event.target.value) })),
        h("label", null, h("span", null, "Student"), h("select", { value: selectedStudent, onInput: (event) => setSelectedStudent(event.target.value) },
          h("option", { value: "" }, "Select student"),
          selectableStudents.map((student) => h("option", { value: student.id, key: student.id }, `${student.rollNo} · ${student.name}`)),
        )),
        selectedStudentData
          ? h("div", { className: "selected-student-card" },
              h("span", null, "Selected"),
              h("strong", null, selectedStudentData.name),
              h("small", null, `Roll ${selectedStudentData.rollNo} · ${selectedStudentData.className} · ${selectedStudentData.rfidUid}`),
              h("div", { className: "current-attendance-state" },
                h("span", { className: `row-status ${(selectedAttendanceRecord?.status || "Absent").toLowerCase()}` }, selectedAttendanceRecord?.status || "Absent"),
                h("em", null, selectedAttendanceRecord?.time ? `${selectedAttendanceRecord.time} · ${selectedAttendanceRecord.source}` : "No mark saved for this date"),
              ),
            )
          : h(EmptyState, { title: "Select a student", copy: "Search below, then choose a student before marking attendance." }),
        h("div", { className: "status-toggle", role: "group", "aria-label": "Manual attendance status" },
          ["Present", "Absent", "Late"].map((item) =>
            h("button", {
              className: manualStatus === item ? "active" : "",
              type: "button",
              onClick: () => setManualStatus(item),
            }, item),
          ),
        ),
        h("div", { className: "manual-actions" },
          h("button", { className: "btn btn-primary", type: "button", disabled: marking || !selectedStudent, onClick: () => mark(manualStatus) }, marking ? "Saving..." : `Mark ${manualStatus}`),
        ),
      ),
      h("article", { className: "admin-panel" },
        h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Filters"), h("h3", null, "Attendance Records")), h("strong", null, records.length)),
        h("div", { className: "filter-grid" },
          h("label", null, h("span", null, "Status"), h("select", { value: status, onInput: (event) => setStatus(event.target.value) }, h("option", { value: "" }, "All"), ["Present", "Absent", "Late"].map((item) => h("option", { value: item, key: item }, item)))),
          h("label", null, h("span", null, "Source"), h("select", { value: source, onInput: (event) => setSource(event.target.value) }, h("option", { value: "" }, "All sources"), ["RFID", "Manual", "System"].map((item) => h("option", { value: item, key: item }, item)))),
          h("label", null, h("span", null, "Search"), h("input", { value: search, onInput: (event) => setSearch(event.target.value), placeholder: "Name, roll, class, or UID" })),
        ),
        recordsError
          ? h("div", { className: "inline-error", role: "alert" }, recordsError, h("button", { type: "button", onClick: loadRecords }, "Retry"))
          : loadingRecords
            ? h(EmptyState, { title: "Loading attendance", copy: "Reading the selected day from SQLite." })
            : records.length
              ? h("div", { className: "table-wrap" },
                  h("table", { className: "attendance-table" },
                    h("thead", null, h("tr", null, h("th", null, "Student"), h("th", null, "Status"), h("th", null, "Time"), h("th", null, "Source"), h("th", null, "Action"))),
                    h("tbody", null, records.map((record) =>
                      h("tr", { key: record.id },
                        h("td", { "data-label": "Student" }, `${record.rollNo} · ${record.studentName}`),
                        h("td", { "data-label": "Status" }, h("span", { className: `row-status ${record.status.toLowerCase()}` }, record.status)),
                        h("td", { "data-label": "Time" }, record.time || "Not marked"),
                        h("td", { "data-label": "Source" }, record.source),
                        h("td", { "data-label": "Action" },
                          h("button", { className: "mini-link", type: "button", onClick: () => setSelectedStudent(record.studentId) }, "Select"),
                        ),
                      ),
                    )),
                  ),
                )
              : h(EmptyState, { title: "No matching attendance", copy: "Try a different date, status, or search term." }),
      ),
    ),
  );
}

function AnalyticsLineChart({ rows, selectedDate, onSelectDate }) {
  const width = 640;
  const height = 220;
  const padding = 26;
  const max = Math.max(100, ...rows.map((row) => Number(row.percentage || 0)));
  const points = rows.map((row, index) => {
    const x = rows.length <= 1
      ? width / 2
      : padding + (index / (rows.length - 1)) * (width - padding * 2);
    const y = height - padding - (Number(row.percentage || 0) / max) * (height - padding * 2);
    return { ...row, x, y };
  });
  const path = points.map((point, index) => `${index ? "L" : "M"} ${point.x.toFixed(1)} ${point.y.toFixed(1)}`).join(" ");

  return rows.length
    ? h("div", { className: "analytics-chart line-chart" },
        h("svg", { viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": "Attendance percentage trend" },
          h("path", { className: "chart-grid-line", d: `M ${padding} ${height - padding} H ${width - padding}` }),
          h("path", { className: "line-fill", d: `${path} L ${points.at(-1).x.toFixed(1)} ${height - padding} L ${points[0].x.toFixed(1)} ${height - padding} Z` }),
          h("path", { className: "line-stroke", d: path }),
          points.map((point) =>
            h("g", {
              key: point.date,
              className: selectedDate === point.date ? "selected" : "",
              role: "button",
              tabIndex: 0,
              onClick: () => onSelectDate?.(point.date),
              onKeyDown: (event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onSelectDate?.(point.date);
                }
              },
            },
              h("circle", { cx: point.x, cy: point.y, r: selectedDate === point.date ? 6 : 4 },
                h("title", null, `${point.date}: ${formatPercent(point.percentage)} · ${point.present} attended`),
              ),
            ),
          ),
        ),
        h("div", { className: "chart-axis" }, rows.slice(0, 6).map((row) => h("span", { key: row.date }, row.date.slice(5)))),
      )
    : h(EmptyState, { title: "No trend data", copy: "There are no attendance records in this selected range." });
}

function AnalyticsBarChart({ rows }) {
  const max = Math.max(1, ...rows.map((row) => Number(row.present || row.records || 0)));

  return rows.length
    ? h("div", { className: "analytics-bars" },
        rows.map((row) => {
          const value = Number(row.present || row.records || 0);
          return h("article", { key: row.className },
            h("div", null,
              h("strong", null, row.className || "Unassigned"),
              h("small", null, `${formatNumber(row.records)} records`),
            ),
            h("div", { className: "horizontal-bar" }, h("span", { style: { width: `${Math.max(4, (value / max) * 100)}%` } })),
            h("em", null, formatNumber(value)),
          );
        }),
      )
    : h(EmptyState, { title: "No class comparison", copy: "Class totals will appear once records match the selected range." });
}

function AnalyticsDonut({ rows }) {
  const total = rows.reduce((sum, row) => sum + Number(row.count || 0), 0);
  const present = rows.find((row) => row.status === "Present")?.count || 0;
  const late = rows.find((row) => row.status === "Late")?.count || 0;
  const absent = rows.find((row) => row.status === "Absent")?.count || 0;
  const presentEnd = total ? (present / total) * 100 : 0;
  const lateEnd = total ? ((present + late) / total) * 100 : presentEnd;

  return total
    ? h("div", { className: "donut-wrap" },
        h("div", {
          className: "donut-chart",
          style: {
            background: `conic-gradient(var(--green) 0 ${presentEnd}%, var(--blue) ${presentEnd}% ${lateEnd}%, var(--amber) ${lateEnd}% 100%)`,
          },
        },
          h("strong", null, formatNumber(total)),
          h("span", null, "tracked marks"),
        ),
        h("div", { className: "donut-legend" },
          [["Present", present], ["Late", late], ["Absent", absent]].map(([label, value]) =>
            h("span", { key: label, className: label.toLowerCase() }, h("i", null), `${label}: ${formatNumber(value)}`),
          ),
        ),
      )
    : h(EmptyState, { title: "No breakdown yet", copy: "The donut chart needs real attendance records in the selected range." });
}

function AttendanceHeatmap({ rows }) {
  return rows.length
    ? h("div", { className: "heatmap-grid", role: "img", "aria-label": "Attendance heatmap by date" },
        rows.map((row) =>
          h("span", {
            key: row.date,
            style: { "--level": Math.max(0.08, Number(row.percentage || 0) / 100) },
            title: `${row.date}: ${formatPercent(row.percentage)} attendance`,
          }),
        ),
      )
    : h(EmptyState, { title: "No heatmap activity", copy: "Activity squares appear for dates with real attendance data." });
}

export function AnalyticsPage({ students, onToast }) {
  const [preset, setPreset] = useState("30d");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [studentId, setStudentId] = useState("");
  const [analytics, setAnalytics] = useState(null);
  const [loadingAnalytics, setLoadingAnalytics] = useState(true);
  const [analyticsError, setAnalyticsError] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const customRange = preset === "custom";

  async function loadAnalytics() {
    setLoadingAnalytics(true);
    setAnalyticsError("");
    try {
      const result = await Api.analytics({
        preset,
        startDate: customRange ? startDate : "",
        endDate: customRange ? endDate : "",
        studentId,
      });
      setAnalytics(result);
    } catch (error) {
      setAnalyticsError(error.message || "Analytics failed to load");
      onToast?.(error.message || "Analytics failed to load", "error");
    } finally {
      setLoadingAnalytics(false);
    }
  }

  useEffect(() => {
    loadAnalytics();
  }, [preset, startDate, endDate, studentId]);

  const metrics = analytics?.metrics || {};
  const trend = analytics?.trend || [];
  const selectedTrendDay = trend.find((row) => row.date === selectedDate) || trend.at(-1);
  const exportParams = {
    studentId,
    startDate: customRange ? startDate : analytics?.range?.startDate,
    endDate: customRange ? endDate : analytics?.range?.endDate,
  };

  return h(
    "section",
    { className: "admin-page analytics-page" },
    h(SectionTitle, { eyebrow: "Analytics", title: "Attendance intelligence", copy: "Real KPIs, trends, ranking, heatmap, and reports generated from the existing SQLite data." }),
    h("article", { className: "admin-panel analytics-controls" },
      h("div", { className: "status-toggle" },
        [["today", "Today"], ["7d", "7 Days"], ["30d", "30 Days"], ["3m", "3 Months"], ["all", "All"], ["custom", "Custom"]].map(([value, label]) =>
          h("button", { key: value, type: "button", className: preset === value ? "active" : "", onClick: () => setPreset(value) }, label),
        ),
      ),
      h("div", { className: "filter-grid" },
        customRange ? h("label", null, h("span", null, "Start"), h("input", { type: "date", value: startDate, onInput: (event) => setStartDate(event.target.value) })) : null,
        customRange ? h("label", null, h("span", null, "End"), h("input", { type: "date", value: endDate, onInput: (event) => setEndDate(event.target.value) })) : null,
        h("label", null, h("span", null, "Student"), h("select", { value: studentId, onInput: (event) => setStudentId(event.target.value) },
          h("option", { value: "" }, "All students"),
          students.map((student) => h("option", { value: student.id, key: student.id }, `${student.rollNo} · ${student.name}`)),
        )),
      ),
    ),
    analyticsError
      ? h("div", { className: "inline-error", role: "alert" }, analyticsError, h("button", { type: "button", onClick: loadAnalytics }, "Retry"))
      : null,
    loadingAnalytics && !analytics
      ? h(EmptyState, { title: "Loading analytics", copy: "Aggregating attendance directly from SQLite." })
      : h(window.React.Fragment, null,
          h("div", { className: "metric-grid analytics-kpis" },
            h(MetricCard, { label: "Total Students", value: metrics.totalStudents ?? 0, detail: "Registered RFID users", tone: "blue" }),
            h(MetricCard, { label: "Present Today", value: metrics.presentToday ?? 0, detail: "Current calendar day", tone: "green" }),
            h(MetricCard, { label: "Absent Today", value: metrics.absentToday ?? 0, detail: "Not marked today", tone: "amber" }),
            h(MetricCard, { label: "Overall Rate", value: formatPercent(metrics.overallAttendancePercentage), detail: `${metrics.activeDays || 0} active day basis`, tone: "violet" }),
            h(MetricCard, { label: "Records", value: metrics.totalAttendanceRecords ?? 0, detail: "Matching selected range", tone: "cyan" }),
            h(MetricCard, { label: "Active Students", value: metrics.activeStudents ?? 0, detail: "Have at least one mark", tone: "green" }),
          ),
          h("div", { className: "analytics-main-grid" },
            h("article", { className: "admin-panel chart-large" },
              h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Trend"), h("h3", null, "Attendance over time")), h("small", null, analytics?.range?.basis || "Real records")),
              h(AnalyticsLineChart, { rows: trend, selectedDate: selectedTrendDay?.date, onSelectDate: setSelectedDate }),
              selectedTrendDay
                ? h("div", { className: "chart-inspector" },
                    h("span", null, selectedTrendDay.date),
                    h("strong", null, formatPercent(selectedTrendDay.percentage)),
                    h("small", null, `${formatNumber(selectedTrendDay.present)} attended · ${formatNumber(selectedTrendDay.absent)} absent`),
                  )
                : null,
            ),
            h("article", { className: "admin-panel" },
              h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Breakdown"), h("h3", null, "Present vs absent"))),
              h(AnalyticsDonut, { rows: analytics?.statusBreakdown || [] }),
            ),
          ),
          h("div", { className: "analytics-main-grid" },
            h("article", { className: "admin-panel" },
              h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Bar Graph"), h("h3", null, "Class comparison"))),
              h(AnalyticsBarChart, { rows: analytics?.classSummary || [] }),
            ),
            h("article", { className: "admin-panel" },
              h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Heatmap"), h("h3", null, "Daily activity"))),
              h(AttendanceHeatmap, { rows: analytics?.heatmap || [] }),
            ),
          ),
          studentId
            ? h("article", { className: "admin-panel student-analytics-panel" },
                h("div", { className: "panel-heading" },
                  h("div", null, h("span", { className: "eyebrow mini" }, "Student Analytics"), h("h3", null, analytics?.student?.name || "Selected student")),
                  h("strong", null, formatPercent(metrics.overallAttendancePercentage)),
                ),
                h("div", { className: "student-detail-grid" },
                  h("div", null, h("span", null, "Present days"), h("strong", null, analytics?.ranking?.[0]?.presentDays ?? 0)),
                  h("div", null, h("span", null, "Absent days"), h("strong", null, analytics?.ranking?.[0]?.absentDays ?? 0)),
                  h("div", null, h("span", null, "Records"), h("strong", null, metrics.totalAttendanceRecords ?? 0)),
                  h("div", null, h("span", null, "Active days"), h("strong", null, metrics.activeDays ?? 0)),
                ),
                (analytics?.sourceBreakdown || []).length
                  ? h("div", { className: "source-breakdown" },
                      analytics.sourceBreakdown.map((item) =>
                        h("span", { key: item.source }, h("strong", null, item.count), ` ${item.source}`),
                      ),
                    )
                  : h(EmptyState, { title: "No source data", copy: "RFID/manual distribution appears when this filter has records." }),
                (analytics?.history || []).length
                  ? h("div", { className: "history-list compact" },
                      analytics.history.slice(0, 6).map((record) =>
                        h("article", { className: `history-item ${record.status.toLowerCase()}`, key: record.id },
                          h("span", null, record.status),
                          h("div", null,
                            h("strong", null, record.date),
                            h("small", null, `${record.time || "No time"} · ${record.source}`),
                          ),
                          h("code", null, record.rfidUid),
                        ),
                      ),
                    )
                  : null,
              )
            : null,
          h("article", { className: "admin-panel" },
            h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Ranking"), h("h3", null, "Student attendance ranking")), h("strong", null, analytics?.ranking?.length || 0)),
            analytics?.ranking?.length
              ? h("div", { className: "table-wrap" },
                  h("table", { className: "attendance-table ranking-table" },
                    h("thead", null, h("tr", null, h("th", null, "Rank"), h("th", null, "Student"), h("th", null, "Present"), h("th", null, "Absent"), h("th", null, "Attendance"), h("th", null, "CSV"))),
                    h("tbody", null, analytics.ranking.map((student) =>
                      h("tr", { key: student.studentId, className: String(studentId) === String(student.studentId) ? "selected-row" : "", onClick: () => setStudentId(String(student.studentId)) },
                        h("td", { "data-label": "Rank" }, `#${student.rank}`),
                        h("td", { "data-label": "Student" }, `${student.rollNo} · ${student.studentName}`),
                        h("td", { "data-label": "Present" }, student.presentDays),
                        h("td", { "data-label": "Absent" }, student.absentDays),
                        h("td", { "data-label": "Attendance" }, h(ProgressBar, { value: student.attendancePercentage })),
                        h("td", { "data-label": "CSV" }, h("a", { className: "mini-link", href: Api.csvUrl({ ...exportParams, studentId: student.studentId }), onClick: () => onToast?.(`${student.studentName} CSV export started`, "info") }, "Download")),
                      ),
                    )),
                  ),
                )
              : h(EmptyState, { title: "No ranking data", copy: "Ranking appears when there are students or attendance records in range." }),
          ),
          h("article", { className: "admin-panel reports-panel" },
            h("div", null,
              h("span", { className: "eyebrow mini" }, "Reports"),
              h("h3", null, "CSV exports"),
              h("p", null, "Exports use the active student and date filters where they apply."),
            ),
            h("div", { className: "report-actions" },
              h("a", { className: "btn btn-primary", href: Api.csvUrl(exportParams), onClick: () => onToast?.("Filtered CSV export started", "success") }, "Download Filtered CSV"),
              h("a", { className: "btn btn-secondary", href: Api.csvUrl({}), onClick: () => onToast?.("All-students CSV export started", "info") }, "Download All Students CSV"),
              h("a", { className: "btn btn-secondary", href: Api.csvUrl({ ...exportParams, status: "Present" }), onClick: () => onToast?.("Present CSV export started", "info") }, "Present CSV"),
              h("a", { className: "btn btn-secondary", href: Api.csvUrl({ ...exportParams, status: "Absent" }), onClick: () => onToast?.("Absent CSV export started", "info") }, "Absent CSV"),
              studentId ? h("a", { className: "btn btn-secondary", href: Api.csvUrl({ studentId }), onClick: () => onToast?.("Student CSV export started", "info") }, "Download Student CSV") : null,
            ),
          ),
        ),
  );
}

export function ReportsPage({ data, students, onToast }) {
  const [preset, setPreset] = useState("today");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [status, setStatus] = useState("");
  const [source, setSource] = useState("");
  const [studentId, setStudentId] = useState("");
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search);
  const [preview, setPreview] = useState([]);
  const [loadingPreview, setLoadingPreview] = useState(true);
  const [previewError, setPreviewError] = useState("");
  const [exportState, setExportState] = useState("Ready");
  const customRange = preset === "custom";
  const currentDate = data?.date || today();
  const currentMonth = currentDate.slice(0, 7);

  const rangeParams = useMemo(() => {
    const now = new Date(`${currentDate}T00:00:00`);
    const isoDate = (offset) => {
      const copy = new Date(now);
      copy.setDate(copy.getDate() - offset);
      return copy.toISOString().slice(0, 10);
    };

    if (preset === "today") return { date: currentDate };
    if (preset === "7d") return { startDate: isoDate(6), endDate: currentDate };
    if (preset === "30d") return { startDate: isoDate(29), endDate: currentDate };
    if (preset === "3m") return { startDate: isoDate(89), endDate: currentDate };
    if (customRange) return { startDate, endDate };
    return {};
  }, [preset, currentDate, customRange, startDate, endDate]);

  const reportParams = {
    ...rangeParams,
    status,
    source,
    studentId,
    search: debouncedSearch,
  };
  const previewSummary = useMemo(() => {
    const present = preview.filter((record) => ["Present", "Late"].includes(record.status)).length;
    const absent = preview.filter((record) => record.status === "Absent").length;
    const total = preview.length;
    return {
      total,
      present,
      absent,
      percentage: total ? (present / total) * 100 : 0,
    };
  }, [preview]);
  const activeFilters = useMemo(() => {
    const items = [];
    if (preset !== "today") items.push(`Range: ${preset === "custom" ? `${startDate || "start"} to ${endDate || "end"}` : preset}`);
    if (status) items.push(`Status: ${status}`);
    if (source) items.push(`Source: ${source}`);
    if (studentId) items.push(`Student: ${(students || []).find((student) => String(student.id) === String(studentId))?.name || studentId}`);
    if (debouncedSearch) items.push(`Search: ${debouncedSearch}`);
    return items;
  }, [preset, startDate, endDate, status, source, studentId, debouncedSearch, students]);

  function resetReportFilters() {
    setPreset("today");
    setStartDate("");
    setEndDate("");
    setStatus("");
    setSource("");
    setStudentId("");
    setSearch("");
  }

  useEffect(() => {
    let active = true;

    setLoadingPreview(true);
    setPreviewError("");

    Api.attendanceRecords({
      ...reportParams,
      includeRoster: preset === "today" || Boolean(reportParams.date) ? 1 : 0,
    })
      .then((result) => {
        if (active) setPreview(result.records || []);
      })
      .catch((error) => {
        if (active) {
          setPreviewError(error.message || "Report preview could not be loaded");
          onToast?.(error.message || "Report preview could not be loaded", "error");
        }
      })
      .finally(() => {
        if (active) setLoadingPreview(false);
      });

    return () => {
      active = false;
    };
  }, [preset, startDate, endDate, status, source, studentId, debouncedSearch, currentDate]);

  async function downloadCsv(params, label = "attendance-report") {
    setExportState("Preparing");

    try {
      const response = await fetch(Api.csvUrl(params), {
        credentials: "same-origin",
      });

      if (!response.ok) {
        throw new Error(`CSV export failed with status ${response.status}`);
      }

      setExportState("Generating");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const disposition = response.headers.get("Content-Disposition") || "";
      const match = disposition.match(/filename="?([^"]+)"?/i);

      link.href = url;
      link.download = match?.[1] || `${label}.csv`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);

      setExportState("Downloaded");
      onToast?.("CSV report downloaded", "success");
      window.setTimeout(() => setExportState("Ready"), 1800);
    } catch (error) {
      setExportState("Export failed");
      onToast?.(error.message || "CSV export failed", "error");
    }
  }

  return h(
    "section",
    { className: "admin-page" },
    h("div", { className: "reports-layout" },
      h("div", null,
        h("span", { className: "eyebrow" }, "Reports"),
        h("h1", null, "Filtered CSV and student analytics"),
        h("p", null, "Download date-wise, range-wise, month-wise, and student-wise reports with clean attendance details from SQLite."),
        h("div", { className: "active-filter-strip", "aria-label": "Active report filters" },
          activeFilters.length
            ? activeFilters.map((item) => h("span", { key: item }, item))
            : h("span", null, `Date: ${currentDate}`),
        ),
        h("div", { className: "report-actions" },
          h("button", { className: "btn btn-primary", type: "button", onClick: () => downloadCsv(reportParams, "filtered-attendance") }, "Download Filtered CSV"),
          h("button", { className: "btn btn-secondary", type: "button", onClick: () => downloadCsv({ date: currentDate }, "today-attendance") }, "Today CSV"),
          h("button", { className: "btn btn-secondary", type: "button", onClick: () => downloadCsv({ month: currentMonth }, "monthly-attendance") }, "Monthly CSV"),
          h("button", { className: "btn btn-secondary", type: "button", onClick: () => downloadCsv({}, "all-attendance") }, "All History"),
        ),
      ),
      h("aside", { className: "report-profile" },
        h("span", { className: "eyebrow mini" }, "Attendance Rate"),
        h("h3", null, `${data?.metrics?.attendancePercentage || 0}%`),
        h(ProgressBar, { value: data?.metrics?.attendancePercentage || 0 }),
        h("p", null, "CSV includes student name, roll number, RFID UID, status, date, time, and source."),
        h("div", { className: "export-state", role: "status", "aria-live": "polite" }, exportState),
      ),
    ),
    h("div", { className: "report-kpi-grid" },
      h("article", null, h("span", null, "Total Students"), h("strong", null, students?.length || 0), h("small", null, "registered")),
      h("article", null, h("span", null, "Present"), h("strong", null, previewSummary.present), h("small", null, "present or late")),
      h("article", null, h("span", null, "Absent"), h("strong", null, previewSummary.absent), h("small", null, "matching filters")),
      h("article", null, h("span", null, "Attendance"), h("strong", null, formatPercent(previewSummary.percentage)), h("small", null, "preview rate")),
      h("article", null, h("span", null, "Total Records"), h("strong", null, previewSummary.total), h("small", null, "preview rows")),
    ),
    h("article", { className: "admin-panel analytics-controls" },
      h("div", { className: "status-toggle", role: "group", "aria-label": "Report date range" },
        [["today", "Today"], ["7d", "7 Days"], ["30d", "30 Days"], ["3m", "3 Months"], ["all", "All"], ["custom", "Custom"]].map(([value, label]) =>
          h("button", { key: value, type: "button", className: preset === value ? "active" : "", onClick: () => setPreset(value) }, label),
        ),
      ),
      h("div", { className: "filter-grid" },
        customRange ? h("label", null, h("span", null, "Start"), h("input", { type: "date", value: startDate, onInput: (event) => setStartDate(event.target.value) })) : null,
        customRange ? h("label", null, h("span", null, "End"), h("input", { type: "date", value: endDate, onInput: (event) => setEndDate(event.target.value) })) : null,
        h("label", null, h("span", null, "Status"), h("select", { value: status, onInput: (event) => setStatus(event.target.value) },
          h("option", { value: "" }, "All statuses"),
          ["Present", "Absent", "Late"].map((item) => h("option", { value: item, key: item }, item)),
        )),
        h("label", null, h("span", null, "Source"), h("select", { value: source, onInput: (event) => setSource(event.target.value) },
          h("option", { value: "" }, "All sources"),
          ["RFID", "Manual", "System"].map((item) => h("option", { value: item, key: item }, item)),
        )),
        h("label", null, h("span", null, "Student"), h("select", { value: studentId, onInput: (event) => setStudentId(event.target.value) },
          h("option", { value: "" }, "All students"),
          (students || []).map((student) => h("option", { value: student.id, key: student.id }, `${student.rollNo} · ${student.name}`)),
        )),
        h("label", null, h("span", null, "Search"), h("input", { value: search, onInput: (event) => setSearch(event.target.value), placeholder: "Name, roll, class, or UID" })),
      ),
      h("div", { className: "filter-footer" },
        h("span", null, loadingPreview ? "Loading preview..." : `${previewSummary.total} rows match the current filters`),
        h("button", { className: "btn btn-compact", type: "button", onClick: resetReportFilters }, "Reset Filters"),
      ),
    ),
    h("article", { className: "admin-panel report-visual-summary" },
      h("div", null,
        h("span", { className: "eyebrow mini" }, "Visual Summary"),
        h("h3", null, "Present vs absent"),
        h("p", null, "Summary is calculated from the current real preview rows."),
      ),
      h("div", { className: "report-summary-bars" },
        [["Present", previewSummary.present, "present"], ["Absent", previewSummary.absent, "absent"]].map(([label, value, tone]) =>
          h("article", { key: label },
            h("div", null, h("strong", null, label), h("span", null, formatNumber(value))),
            h("div", { className: `summary-meter ${tone}` }, h("span", { style: { width: `${previewSummary.total ? Math.max(4, (value / previewSummary.total) * 100) : 0}%` } })),
          ),
        ),
      ),
    ),
    h("div", { className: "student-report-grid" },
      (students || []).map((student) =>
        h("article", { className: "student-report", key: student.id },
          h("div", null, h("strong", null, student.name), h("small", null, `UID ${student.rfidUid}`)),
          h("span", null, student.rollNo),
          h(ProgressBar, { value: student.attendancePercentage || 0 }),
          h("button", { className: "mini-link", type: "button", onClick: () => downloadCsv({ ...rangeParams, status, source, search: debouncedSearch, studentId: student.id }, `${student.name}-attendance`) }, "Download student report"),
        ),
      ),
    ),
    h("article", { className: "admin-panel report-preview-panel" },
      h("div", { className: "panel-heading" },
        h("div", null, h("span", { className: "eyebrow mini" }, "Report Preview"), h("h3", null, "Filtered attendance records")),
        h("strong", null, loadingPreview ? "..." : preview.length),
      ),
      previewError
        ? h("div", { className: "inline-error", role: "alert" }, previewError)
        : loadingPreview
          ? h(EmptyState, { title: "Loading report preview", copy: "Reading matching records from SQLite." })
          : preview.length
            ? h("div", { className: "table-wrap report-preview-table" },
                h("table", { className: "attendance-table" },
                  h("thead", null, h("tr", null, h("th", null, "Student"), h("th", null, "Identifier"), h("th", null, "Date"), h("th", null, "Status"), h("th", null, "Time"), h("th", null, "Source"))),
                  h("tbody", null, preview.slice(0, 120).map((record) =>
                    h("tr", { key: record.id },
                      h("td", { "data-label": "Student" }, `${record.rollNo} · ${record.studentName}`),
                      h("td", { "data-label": "Identifier" }, h("code", null, record.rfidUid)),
                      h("td", { "data-label": "Date" }, record.date),
                      h("td", { "data-label": "Status" }, h("span", { className: `row-status ${record.status.toLowerCase()}` }, record.status)),
                      h("td", { "data-label": "Time" }, record.time || "Not marked"),
                      h("td", { "data-label": "Source" }, record.source || "System"),
                    ),
                  )),
                ),
              )
            : h(EmptyState, { title: "No matching report rows", copy: "Adjust the date, status, student, or search filters." }),
    ),
  );
}

export function ProfilePage({ onToast }) {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  window.React.useEffect(() => {
    let active = true;
    Api.profile()
      .then((result) => {
        if (active) setProfile(result);
      })
      .catch((error) => onToast?.(error.message || "Profile could not be loaded", "error"))
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const history = profile?.loginHistory || [];
  return h(
    "section",
    { className: "admin-page profile-page" },
    h(Team),
    h(SectionTitle, {
      eyebrow: "Profile / Team",
      title: "Team roles and admin activity",
      copy: "Review the exhibition team, signed-in admin identity, total website visits, and recent authentication events.",
    }),
    h("div", { className: "profile-grid" },
      h("article", { className: "admin-panel profile-card" },
        h("span", { className: "eyebrow mini" }, "Signed in as"),
        h("h3", null, profile?.admin?.username || "Admin"),
        h("p", null, `Account created ${formatDateTime(profile?.admin?.created_at || profile?.admin?.createdAt)}`),
      ),
      h("article", { className: "admin-panel profile-metric" },
        h("span", null, "Website visits"),
        h("strong", null, profile?.visits?.total ?? 0),
        h("small", null, "tracked page opens"),
      ),
      h("article", { className: "admin-panel profile-metric" },
        h("span", null, "Successful logins"),
        h("strong", null, profile?.stats?.totalLogins ?? 0),
        h("small", null, "including signup"),
      ),
      h("article", { className: "admin-panel profile-metric" },
        h("span", null, "Failed attempts"),
        h("strong", null, profile?.stats?.failedAttempts ?? 0),
        h("small", null, "for this username"),
      ),
    ),
    h("article", { className: "admin-panel" },
      h("div", { className: "panel-heading" },
        h("div", null,
          h("span", { className: "eyebrow mini" }, "Security"),
          h("h3", null, "Recent login history"),
        ),
        h("strong", null, loading ? "..." : history.length),
      ),
      loading
        ? h(EmptyState, { title: "Loading profile", copy: "Reading account activity from SQLite." })
        : history.length
          ? h("div", { className: "history-list" },
              history.map((event, index) =>
                h("article", { className: `history-item ${event.status}`, key: `${event.createdAt}-${index}` },
                  h("span", null, event.status),
                  h("div", null,
                    h("strong", null, event.username),
                    h("small", null, `${formatDateTime(event.createdAt)} · ${event.sourceIp || "local"}`),
                  ),
                  h("code", null, event.userAgent?.split(" ").slice(0, 3).join(" ") || "Browser"),
                ),
              ),
            )
          : h(EmptyState, { title: "No login history yet", copy: "Successful and failed login attempts will appear here." }),
    ),
  );
}

function ComponentsSection() {
  const components = [
    ["ESP32", "Wi-Fi microcontroller that sends RFID scans to Flask APIs."],
    ["RFID RC522", "Contactless scanner that reads each student card UID."],
    ["RFID Tags/Cards", "Unique student identities used for fast attendance."],
    ["Wi-Fi Network", "Connects the ESP32 device to the backend server."],
    ["Flask Backend", "Validates scans, manages APIs, and writes attendance records."],
    ["SQLite Database", "Stores students, admins, scan events, and attendance history."],
    ["React Frontend", "Premium dashboard for admin control and real-time monitoring."],
    ["REST API", "Stable communication layer between hardware and software."],
  ];
  return h(
    "section",
    { className: "section-band" },
    h(SectionTitle, { eyebrow: "Components", title: "Hardware and software stack", copy: "Each layer works together to create a complete smart-campus attendance system." }),
    h("div", { className: "component-grid" },
      components.map((item, index) => h("article", { className: "component-card", key: item[0] }, h("span", null, `0${index + 1}`), h("h3", null, item[0]), h("p", null, item[1]))),
    ),
  );
}

function LearningSection() {
  return h(
    "section",
    { className: "section-band" },
    h(Explainers),
    h("div", { className: "component-grid learn-grid" },
      learningBlocks.map((item) => h("article", { className: "component-card", key: item }, h("h3", null, item), h("p", null, "We learned how this concept connects to real-world automation, reliable software design, and teamwork."))),
    ),
  );
}

function ExhibitionPurpose() {
  return h(
    "section",
    { className: "section-band" },
    h(SectionTitle, {
      eyebrow: "Exhibition Purpose",
      title: "A working model for smart attendance",
      copy: "The project demonstrates how RFID hardware, Wi-Fi communication, backend APIs, database storage, analytics, and reports can work together as one reliable school attendance system.",
    }),
    h("div", { className: "component-grid" },
      [
        ["What the system does", "Registers students with RFID cards, records attendance, and reflects the result across dashboard, analytics, and CSV reports."],
        ["How it helps", "It reduces repetitive manual work while giving teachers a clear view of who is present, absent, or late."],
        ["Demo value", "It lets judges follow the full path from RFID UID input to validated database record and polished live UI."],
      ].map((item, index) => h("article", { className: "component-card", key: item[0] }, h("span", null, `0${index + 1}`), h("h3", null, item[0]), h("p", null, item[1]))),
    ),
  );
}

export function AboutPage() {
  return h(
    "section",
    { className: "admin-page info-page about-page" },
    h(ProjectExplanation),
    h(WorkflowTimeline),
    h(ComponentsSection),
    h(LearningSection),
    h(ExhibitionPurpose),
    h(Conclusion),
  );
}

export function SettingsPage({ onToast }) {
  const [checks, setChecks] = useState(null);
  const [integration, setIntegration] = useState(null);
  const [requests, setRequests] = useState([]);
  const [requestStatus, setRequestStatus] = useState("Pending");
  const [reviewNotes, setReviewNotes] = useState({});
  const [reviewing, setReviewing] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadSettings() {
    setLoading(true);
    setError("");
    try {
      const [systemChecks, deviceIntegration, editRequests] = await Promise.all([
        Api.systemChecks(),
        Api.deviceIntegration(),
        Api.adminEditRequests({ status: requestStatus }),
      ]);
      setChecks(systemChecks);
      setIntegration(deviceIntegration);
      setRequests(editRequests.requests || []);
    } catch (loadError) {
      setError(loadError.message || "Settings could not be loaded");
      onToast?.(loadError.message || "Settings could not be loaded", "error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadSettings();
  }, [requestStatus]);

  async function reviewRequest(requestId, decision) {
    setReviewing(`${requestId}-${decision}`);
    try {
      await Api.reviewEditRequest(requestId, {
        decision,
        note: reviewNotes[requestId] || "",
      });
      onToast?.(`Request ${decision === "approve" ? "approved" : "rejected"}`, "success");
      await loadSettings();
    } catch (reviewError) {
      onToast?.(reviewError.message || "Request review failed", "error");
    } finally {
      setReviewing("");
    }
  }

  return h(
    "section",
    { className: "admin-page settings-page" },
    h(SectionTitle, {
      eyebrow: "Settings",
      title: "System readiness and device setup",
      copy: "Check API, SQLite, attendance data, ESP32 status, and the routes used by the RFID hardware.",
    }),
    error ? h("div", { className: "inline-error", role: "alert" }, error, h("button", { type: "button", onClick: loadSettings }, "Retry")) : null,
    h("div", { className: "admin-grid-2" },
      h("article", { className: "admin-panel" },
        h("div", { className: "panel-heading" },
          h("div", null, h("span", { className: "eyebrow mini" }, "Diagnostics"), h("h3", null, "Readiness checks")),
          h("button", { className: "btn btn-compact", type: "button", disabled: loading, onClick: loadSettings }, loading ? "Checking" : "Refresh"),
        ),
        loading && !checks
          ? h(EmptyState, { title: "Loading checks", copy: "Reading system diagnostics from the Flask API." })
          : h("div", { className: "settings-check-list" },
              (checks?.checks || []).map((item) =>
                h("article", { className: `readiness-item ${item.ok ? "ok" : "watch"}`, key: item.name },
                  h("span", null),
                  h("div", null, h("strong", null, item.name), h("small", null, item.detail)),
                ),
              ),
              h("div", { className: "summary-grid settings-counts" },
                h("div", null, h("span", null, "Students"), h("strong", null, checks?.counts?.students ?? 0)),
                h("div", null, h("span", null, "Attendance"), h("strong", null, checks?.counts?.attendanceRecords ?? 0)),
                h("div", null, h("span", null, "Scan events"), h("strong", null, checks?.counts?.scanEvents ?? 0)),
                h("div", null, h("span", null, "Overall"), h("strong", null, checks?.healthy ? "Ready" : "Needs attention")),
              ),
            ),
      ),
      h("article", { className: "admin-panel" },
        h("div", { className: "panel-heading" },
          h("div", null, h("span", { className: "eyebrow mini" }, "ESP32 / RC522"), h("h3", null, "Integration routes")),
          h(StatusPill, { online: checks?.device?.online, label: checks?.device?.label }),
        ),
        h("div", { className: "device-readout" },
          h("div", null, h("span", null, "Device ID"), h("strong", null, integration?.deviceId || "ESP32-RFID-01")),
          h("div", null, h("span", null, "Attendance endpoint"), h("strong", null, integration?.routes?.attendance?.url || "/api/attendance")),
          h("div", null, h("span", null, "Heartbeat endpoint"), h("strong", null, integration?.routes?.heartbeat?.url || "/api/device/heartbeat")),
        ),
        h("div", { className: "inline-success", role: "status" }, "Secrets and Gmail credentials are read from environment configuration, not frontend JavaScript."),
      ),
    ),
    h("article", { className: "admin-panel request-review-panel" },
      h("div", { className: "panel-heading" },
        h("div", null, h("span", { className: "eyebrow mini" }, "Student Requests"), h("h3", null, "Review requests and complaints")),
        h("div", { className: "status-toggle compact-toggle", role: "group", "aria-label": "Request status filter" },
          ["Pending", "Approved", "Rejected", ""].map((item) =>
            h("button", { key: item || "all", type: "button", className: requestStatus === item ? "active" : "", onClick: () => setRequestStatus(item) }, item || "All"),
          ),
        ),
      ),
      requests.length
        ? h("div", { className: "request-review-list" },
            requests.map((item) =>
              h("article", { className: `request-review-card ${item.status.toLowerCase()}`, key: item.id },
                h("div", { className: "request-review-main" },
                  h("span", { className: `row-status ${item.status.toLowerCase()}` }, item.status),
                  h("h4", null, `${item.studentName || "Student"} · ${item.rollNo || "No roll"}`),
                  h("p", null, item.reason || "No reason provided."),
                  h("div", { className: "student-detail-grid" },
                    h("div", null, h("span", null, "Field"), h("strong", null, item.fieldName)),
                    h("div", null, h("span", null, "Current"), h("strong", null, item.currentValue || "-")),
                    h("div", null, h("span", null, "Requested"), h("strong", null, item.requestedValue || "-")),
                    h("div", null, h("span", null, "Reviewed"), h("strong", null, item.reviewedAt || "Pending")),
                  ),
                  item.reviewNote ? h("div", { className: "inline-success" }, `Admin response: ${item.reviewNote}`) : null,
                ),
                item.status === "Pending"
                  ? h("form", { className: "request-review-actions", onSubmit: (event) => event.preventDefault() },
                      h("label", null, h("span", null, "Admin response"), h("input", { value: reviewNotes[item.id] || "", onInput: (event) => setReviewNotes((current) => ({ ...current, [item.id]: event.target.value })), placeholder: "Optional note for student" })),
                      h("div", { className: "manual-actions" },
                        h("button", { className: "btn btn-primary", type: "button", disabled: reviewing === `${item.id}-approve`, onClick: () => reviewRequest(item.id, "approve") }, reviewing === `${item.id}-approve` ? "Approving..." : "Approve"),
                        h("button", { className: "btn btn-danger", type: "button", disabled: reviewing === `${item.id}-reject`, onClick: () => reviewRequest(item.id, "reject") }, reviewing === `${item.id}-reject` ? "Rejecting..." : "Reject"),
                      ),
                    )
                  : null,
              ),
            ),
          )
        : h(EmptyState, { title: "No requests found", copy: "Student requests and complaints matching this status will appear here." }),
    ),
  );
}

export function StudentPortalPage({ account, onToast }) {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [requestForm, setRequestForm] = useState({ fieldName: "name", requestedValue: "", reason: "" });
  const [submitting, setSubmitting] = useState(false);

  async function loadProfile() {
    setLoading(true);
    setError("");
    try {
      const result = await Api.studentMe();
      setProfile(result);
    } catch (loadError) {
      setError(loadError.message || "Student portal could not be loaded");
      onToast?.(loadError.message || "Student portal could not be loaded", "error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadProfile();
  }, []);

  async function submitRequest(event) {
    event.preventDefault();
    if (!requestForm.requestedValue.trim()) {
      onToast?.("Enter the requested value", "error");
      return;
    }
    setSubmitting(true);
    try {
      await Api.createStudentEditRequest(requestForm);
      onToast?.("Edit request submitted", "success");
      setRequestForm({ fieldName: "name", requestedValue: "", reason: "" });
      await loadProfile();
    } catch (requestError) {
      onToast?.(requestError.message || "Edit request failed", "error");
    } finally {
      setSubmitting(false);
    }
  }

  const student = profile?.student || account?.student || {};
  const summary = profile?.summary || {};

  return h(
    "section",
    { className: "admin-page student-portal-page" },
    h(SectionTitle, {
      eyebrow: "Student Portal",
      title: student.name ? `Welcome, ${student.name}` : "Student dashboard",
      copy: "Your profile, attendance, reports, and edit requests are loaded from your authenticated student account.",
    }),
    error ? h("div", { className: "inline-error", role: "alert" }, error, h("button", { type: "button", onClick: loadProfile }, "Retry")) : null,
    loading && !profile
      ? h(EmptyState, { title: "Loading student portal", copy: "Reading your attendance and profile securely." })
      : h(window.React.Fragment, null,
          h("div", { className: "metric-grid analytics-kpis" },
            h(MetricCard, { label: "Attendance", value: formatPercent(summary.attendancePercentage), detail: `${summary.activeDays || 0} active days`, tone: "green" }),
            h(MetricCard, { label: "Present", value: summary.presentDays || 0, detail: "present or late marks", tone: "blue" }),
            h(MetricCard, { label: "Absent", value: summary.absentDays || 0, detail: "explicit absence marks", tone: "amber" }),
            h(MetricCard, { label: "Records", value: summary.records || 0, detail: "attendance records", tone: "cyan" }),
          ),
          h("div", { className: "admin-grid-2" },
            h("article", { className: "admin-panel" },
              h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Profile"), h("h3", null, student.name || "Student"))),
              h("div", { className: "student-detail-grid" },
                h("div", null, h("span", null, "Roll"), h("strong", null, student.rollNo || "-")),
                h("div", null, h("span", null, "Class"), h("strong", null, student.className || "-")),
                h("div", null, h("span", null, "RFID"), h("strong", null, student.rfidUid || "Unassigned")),
                h("div", null, h("span", null, "Account"), h("strong", null, profile?.account?.active ? "Active" : "Inactive")),
              ),
            ),
            h("form", { className: "admin-panel form-panel", onSubmit: submitRequest },
              h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Request Edit"), h("h3", null, "Ask admin to update profile"))),
              h("label", null, h("span", null, "Field"), h("select", { value: requestForm.fieldName, onInput: (event) => setRequestForm((current) => ({ ...current, fieldName: event.target.value })) },
                h("option", { value: "name" }, "Name"),
                h("option", { value: "rollNo" }, "Roll / Student ID"),
                h("option", { value: "className" }, "Class"),
                h("option", { value: "rfidUid" }, "RFID UID"),
              )),
              h("label", null, h("span", null, "Requested value"), h("input", { value: requestForm.requestedValue, onInput: (event) => setRequestForm((current) => ({ ...current, requestedValue: event.target.value })) })),
              h("label", null, h("span", null, "Reason"), h("input", { value: requestForm.reason, onInput: (event) => setRequestForm((current) => ({ ...current, reason: event.target.value })) })),
              h("button", { className: "btn btn-primary", disabled: submitting }, submitting ? "Submitting..." : "Submit Request"),
            ),
          ),
          h("article", { className: "admin-panel" },
            h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Attendance"), h("h3", null, "Recent history")), h("strong", null, profile?.history?.length || 0)),
            profile?.history?.length
              ? h("div", { className: "table-wrap" },
                  h("table", { className: "attendance-table" },
                    h("thead", null, h("tr", null, h("th", null, "Date"), h("th", null, "Status"), h("th", null, "Time"), h("th", null, "Source"))),
                    h("tbody", null, profile.history.slice(0, 80).map((record) =>
                      h("tr", { key: record.id },
                        h("td", { "data-label": "Date" }, record.date),
                        h("td", { "data-label": "Status" }, h("span", { className: `row-status ${record.status.toLowerCase()}` }, record.status)),
                        h("td", { "data-label": "Time" }, record.time || "Not marked"),
                        h("td", { "data-label": "Source" }, record.source),
                      ),
                    )),
                  ),
                )
              : h(EmptyState, { title: "No attendance history", copy: "Your attendance records will appear here after they are marked." }),
          ),
          h("article", { className: "admin-panel" },
            h("div", { className: "panel-heading" }, h("div", null, h("span", { className: "eyebrow mini" }, "Edit Requests"), h("h3", null, "Request history")), h("strong", null, profile?.editRequests?.length || 0)),
            profile?.editRequests?.length
              ? h("div", { className: "history-list compact" },
                  profile.editRequests.map((item) =>
                    h("article", { className: `history-item ${item.status.toLowerCase()}`, key: item.id },
                      h("span", null, item.status),
                      h("div", null,
                        h("strong", null, item.fieldName),
                        h("small", null, `${item.currentValue || "-"} to ${item.requestedValue}`),
                      ),
                      h("code", null, item.createdAt),
                    ),
                  ),
                )
              : h(EmptyState, { title: "No edit requests", copy: "Requests you submit will appear here with review status." }),
          ),
        ),
  );
}
