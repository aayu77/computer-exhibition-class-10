import { Badge, StatusPill } from "./ui.js";

const { createElement: h } = window.React;

export function Hero({ device, onOpenDashboard }) {
  const floatingCards = [
    "RFID Scan Detected",
    "API Connected",
    "Database Synced",
    device?.online ? "Device Online" : "Device Offline",
    "Attendance Recorded",
  ];

  return h(
    "section",
    { className: "hero section-band", id: "top" },
    h("div", { className: "hero-grid shell" },
      h("div", { className: "hero-copy", "data-reveal": true },
        h("div", { className: "hero-badges" },
          h(Badge, null, "ESP32 + RFID RC522"),
          h(StatusPill, { online: device?.online, label: device?.label }),
        ),
        h("h1", null, "SMART RFID ATTENDANCE SYSTEM"),
        h("p", { className: "hero-subtitle" }, "Automated attendance tracking using RFID, ESP32, Flask APIs, and SQLite."),
        h("div", { className: "hero-actions" },
          h("button", { className: "btn btn-primary", onClick: onOpenDashboard }, "Open Dashboard"),
          h("a", { className: "btn btn-secondary", href: "#technology" }, "Explore Technology"),
        ),
        h("div", { className: "hero-proof" },
          h("span", null, "REST APIs"),
          h("span", null, "SQLite Storage"),
          h("span", null, "Live Analytics"),
        ),
      ),
      h("div", { className: "hero-visual-wrap", "data-reveal": true },
        h("div", { className: "hero-visual" },
          h("img", {
            src: "/static/assets/rfid-command-center.png",
            alt: "Premium smart attendance dashboard with RFID reader and student card",
          }),
          h("div", { className: "scan-beam", "aria-hidden": true }),
        ),
        h("div", { className: "floating-card card-a" }, h("span", null), floatingCards[0]),
        h("div", { className: "floating-card card-b" }, h("span", null), floatingCards[1]),
        h("div", { className: "floating-card card-c" }, h("span", null), floatingCards[2]),
        h("div", { className: `floating-card card-d ${device?.online ? "online" : "offline"}` }, h("span", null), floatingCards[3]),
        h("div", { className: "floating-card card-e" }, h("span", null), floatingCards[4]),
      ),
    ),
  );
}
